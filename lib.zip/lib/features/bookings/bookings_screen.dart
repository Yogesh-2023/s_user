import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import '../parcels/delivery_booked_screen.dart';
import '../main_navigation_screen.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  int _selectedFilterIndex = 0;
  String _selectedStatus = 'All';

  final List<String> _filters = ['All', 'Ride', 'Parcel', 'Truck'];

  bool _isLoadingTruckBookings = false;
  List<dynamic> _truckBookings = [];
  String? _truckError;

  bool _isLoadingRideBookings = false;
  List<dynamic> _rideBookings = [];
  String? _rideError;

  @override
  void initState() {
    super.initState();
    _fetchTruckBookings();
    _fetchRideBookings();
  }

  Future<void> _fetchTruckBookings() async {
    setState(() {
      _isLoadingTruckBookings = true;
      _truckError = null;
    });

    try {
      final response = await ApiService.to.get(ApiEndpoints.goodsBookings);
      if (!mounted) return;
      if (response.data != null) {
        setState(() {
          _truckBookings = response.data['data'] ?? [];
          _isLoadingTruckBookings = false;
        });
      } else {
        setState(() {
          _truckError = response.message;
          _isLoadingTruckBookings = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _truckError = e.toString().replaceAll('ApiException:', '').trim();
        _isLoadingTruckBookings = false;
      });
    }
  }

  List<dynamic> _getFilteredTruckBookings() {
    if (_selectedStatus == 'All') return _truckBookings;
    return _truckBookings.where((booking) {
      final status = booking['status'] as String? ?? 'PENDING_DRIVER_ASSIGNMENT';
      if (_selectedStatus == 'Active') {
        return status != 'DELIVERED' && status != 'CANCELLED';
      }
      if (_selectedStatus == 'Booked') {
        return ['PENDING_DRIVER_ASSIGNMENT', 'DRIVER_ASSIGNED', 'ARRIVED_PICKUP'].contains(status);
      }
      if (_selectedStatus == 'Completed') {
        return status == 'DELIVERED';
      }
      if (_selectedStatus == 'Cancelled') {
        return status == 'CANCELLED';
      }
      return true;
    }).toList();
  }

  Future<void> _fetchRideBookings() async {
    setState(() {
      _isLoadingRideBookings = true;
      _rideError = null;
    });

    try {
      final response = await ApiService.to.get(ApiEndpoints.userRideHistory);
      if (!mounted) return;
      if (response.statusCode == 200 && response.data != null) {
        setState(() {
          _rideBookings = response.data['data'] ?? [];
          _isLoadingRideBookings = false;
        });
      } else {
        setState(() {
          _rideError = response.message;
          _isLoadingRideBookings = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _rideError = e.toString().replaceAll('ApiException:', '').trim();
        _isLoadingRideBookings = false;
      });
    }
  }

  List<dynamic> _getFilteredRideBookings() {
    if (_selectedStatus == 'All') return _rideBookings;
    return _rideBookings.where((booking) {
      final status = booking['status'] as String? ?? 'PENDING';
      if (_selectedStatus == 'Active') {
        return status != 'COMPLETED' && status != 'CANCELLED';
      }
      if (_selectedStatus == 'Booked') {
        return ['PENDING', 'DRIVER_ASSIGNED', 'ARRIVED'].contains(status);
      }
      if (_selectedStatus == 'Completed') {
        return status == 'COMPLETED';
      }
      if (_selectedStatus == 'Cancelled') {
        return status == 'CANCELLED';
      }
      return true;
    }).toList();
  }

  String _getDisplayStatus(String status) {
    switch (status) {
      case 'PENDING_DRIVER_ASSIGNMENT':
        return 'Finding Driver';
      case 'DRIVER_ASSIGNED':
        return 'Driver Assigned';
      case 'ARRIVED_PICKUP':
        return 'Driver at Pickup';
      case 'GOODS_PICKED_UP':
        return 'Goods Picked Up';
      case 'IN_TRANSIT':
        return 'In Transit';
      case 'ARRIVED_DESTINATION':
        return 'Arrived at Destination';
      case 'DELIVERED':
        return 'Delivered';
      case 'CANCELLED':
        return 'Cancelled';
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: const Color(0xFFEDF0F4), // Match driver app background
        body: SafeArea(
          top: false,
          child: Column(
            children: [
              _buildHeader(context),
              SizedBox(height: 16.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Container(
                  height: 34.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: TabBar(
                    indicatorSize: TabBarIndicatorSize.tab,
                    dividerColor: Colors.transparent,
                    indicator: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF00A2E8).withOpacity(0.8),
                          const Color(0xFF00A2E8),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(8.r),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF00A2E8).withOpacity(0.2),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    labelColor: Colors.white,
                    unselectedLabelColor: const Color(0xFF2C3E50).withOpacity(0.5),
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12.sp,
                    ),
                    unselectedLabelStyle: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12.sp,
                    ),
                    tabs: const [
                      Tab(text: "All"),
                      Tab(text: "Ride"),
                      Tab(text: "Parcel"),
                      Tab(text: "Truck"),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 18.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: _buildSectionHeader(
                  'Bookings',
                  trailing: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedStatus,
                      icon: Icon(Icons.keyboard_arrow_down, size: 16.sp, color: const Color(0xFF00A2E8)),
                      style: AppFonts.captionDark.copyWith(
                        color: const Color(0xFF00A2E8),
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w700,
                      ),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          setState(() {
                            _selectedStatus = newValue;
                          });
                        }
                      },
                      items: <String>['All', 'Active', 'Booked', 'Completed', 'Cancelled']
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10.h),
              Expanded(
                child: TabBarView(
                  children: [
                    _buildAllTab(),
                    _buildRideTab(),
                    _buildParcelTab(),
                    _buildTruckTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAllTab() {
    return ListView(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 18.h),
      children: [
        if (_selectedStatus == 'All' || _selectedStatus == 'Active' || _selectedStatus == 'Booked') ...[
          _buildActiveBookingCard(
            accentColor: const Color(0xFF0D6EFD),
            backgroundColor: const Color(0xFFF2F7FF),
            type: 'Ride',
            status: 'Driver Arriving',
            title: 'DLF Mall of India, Noida',
            route: 'Sector 62, Noida',
            destination: 'Ramesh Kumar  4.8',
            etaLabel: 'ETA',
            eta: '3 min',
            trackLabel: 'Track Ride',
            driverName: 'Ramesh Kumar',
            rating: '4.8',
            imagePath: 'assets/images/car1.png',
          ),
          SizedBox(height: 10.h),
          _buildActiveBookingCard(
            accentColor: const Color(0xFF22C55E),
            backgroundColor: const Color(0xFFF1FBF4),
            type: 'Parcel',
            status: 'In Transit',
            title: 'Document Parcel',
            route: 'Noida Sector 18',
            destination: 'Gurgaon Sector 44',
            etaLabel: 'Expected Delivery',
            eta: 'Today, 7:00 PM',
            trackLabel: 'Track Parcel',
          ),
          SizedBox(height: 10.h),
          _buildActiveBookingCard(
            accentColor: const Color(0xFFF97316),
            backgroundColor: const Color(0xFFFFF6ED),
            type: 'Truck',
            status: 'Driver Assigned',
            title: '1.5 Ton Mini Truck',
            route: 'Noida Sector 62',
            destination: 'Ghaziabad',
            etaLabel: 'ETA',
            eta: '10 min',
            trackLabel: 'Track Truck',
            driverName: 'Vikash Yadav',
            rating: '4.7',
            imagePath: 'assets/images/truck.png',
          ),
          if (_selectedStatus == 'All') SizedBox(height: 10.h),
        ],
        
        if (_selectedStatus == 'All' || _selectedStatus == 'Completed') ...[
          _buildActiveBookingCard(
            accentColor: const Color(0xFF4CAF50),
            backgroundColor: const Color(0xFFE8F5E9),
            type: 'Ride',
            status: 'Completed',
            title: 'Ride to Sector 15, Noida',
            route: 'Sector 62, Noida',
            destination: 'Sector 15, Noida',
            etaLabel: 'Completed On',
            eta: '12 Jun 2026',
            trackLabel: 'View Details',
            driverName: 'Amit Singh',
            rating: '4.9',
            imagePath: 'assets/images/car1.png',
          ),
          SizedBox(height: 10.h),
          _buildActiveBookingCard(
            accentColor: const Color(0xFF22C55E),
            backgroundColor: const Color(0xFFF1FBF4),
            type: 'Parcel',
            status: 'Delivered',
            title: 'Electronics Parcel',
            route: 'New Delhi',
            destination: 'Gurgaon Sector 21',
            etaLabel: 'Delivered On',
            eta: '11 Jun 2026',
            trackLabel: 'View Details',
          ),
          if (_selectedStatus == 'All') SizedBox(height: 10.h),
        ],

        if (_selectedStatus == 'All' || _selectedStatus == 'Cancelled') ...[
          _buildActiveBookingCard(
            accentColor: const Color(0xFFE53935),
            backgroundColor: const Color(0xFFFFEBEE),
            type: 'Truck',
            status: 'Cancelled',
            title: '1.5 Ton Mini Truck',
            route: 'Noida Sector 62',
            destination: 'Ghaziabad',
            etaLabel: 'Cancelled On',
            eta: '10 Jun 2026',
            trackLabel: 'Rebook',
            imagePath: 'assets/images/truck.png',
          ),
        ],
      ],
    );
  }

  Widget _buildRideTab() {
    return ListView(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 18.h),
      children: [
        if (_isLoadingRideBookings)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: CircularProgressIndicator(color: Color(0xFF00A2E8)),
            ),
          )
        else if (_rideError != null)
          Center(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text(_rideError!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                  SizedBox(height: 10.h),
                  ElevatedButton(onPressed: _fetchRideBookings, child: const Text('Retry')),
                ],
              ),
            ),
          )
        else if (_getFilteredRideBookings().isEmpty)
          Center(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 40.h),
              child: Text('No ride bookings found.', style: TextStyle(color: Colors.grey, fontSize: 13.sp)),
            ),
          )
        else
          ..._getFilteredRideBookings().map((booking) {
            final pickupAddr = booking['pickup']?['address'] as String? ?? 'Pickup address';
            final dropAddr = booking['drop']?['address'] as String? ?? 'Drop address';
            String? carName = booking['pickup']?['carName'] as String?;
            if (carName?.toUpperCase() == 'AUTO') carName = 'AUTO';
            final title = carName != null ? '$carName Ride' : 'Ride';
            final status = booking['status'] as String? ?? 'PENDING';
            final double totalFare = (booking['fare']?['totalFare'] as num?)?.toDouble() ?? 0.0;
            final driver = booking['driver'];
            final driverName = driver != null ? driver['name'] as String? : null;

            return Padding(
              padding: EdgeInsets.only(bottom: 10.h),
              child: _buildActiveBookingCard(
                accentColor: status == 'CANCELLED'
                    ? Colors.red
                    : status == 'COMPLETED'
                        ? const Color(0xFF22C55E)
                        : const Color(0xFF0D6EFD),
                backgroundColor: status == 'CANCELLED'
                    ? const Color(0xFFFFEBEE)
                    : status == 'COMPLETED'
                        ? const Color(0xFFF1FBF4)
                        : const Color(0xFFF2F7FF),
                type: 'Ride',
                status: status,
                title: title,
                route: pickupAddr,
                destination: dropAddr,
                etaLabel: 'Total Fare',
                eta: '₹${totalFare.toStringAsFixed(0)}',
                trackLabel: status == 'COMPLETED'
                    ? 'View Details'
                    : status == 'CANCELLED'
                        ? 'Cancelled'
                        : 'Track Ride',
                driverName: driverName,
                rating: driverName != null ? '4.8' : null,
                imagePath: 'assets/images/car1.png',
              ),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildParcelTab() {
    return ListView(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 18.h),
      children: [
        if (_selectedStatus == 'All' || _selectedStatus == 'Active' || _selectedStatus == 'Booked') ...[
          _buildActiveBookingCard(
            accentColor: const Color(0xFF22C55E),
            backgroundColor: const Color(0xFFF1FBF4),
            type: 'Parcel',
            status: 'In Transit',
            title: 'Document Parcel',
            route: 'Noida Sector 18',
            destination: 'Gurgaon Sector 44',
            etaLabel: 'Expected Delivery',
            eta: 'Today, 7:00 PM',
            trackLabel: 'Track Parcel',
          ),
          if (_selectedStatus == 'All') SizedBox(height: 10.h),
        ],
        if (_selectedStatus == 'All' || _selectedStatus == 'Completed') ...[
          _buildActiveBookingCard(
            accentColor: const Color(0xFF22C55E),
            backgroundColor: const Color(0xFFF1FBF4),
            type: 'Parcel',
            status: 'Delivered',
            title: 'Electronics Parcel',
            route: 'New Delhi',
            destination: 'Gurgaon Sector 21',
            etaLabel: 'Delivered On',
            eta: '11 Jun 2026',
            trackLabel: 'View Details',
          ),
        ],
      ],
    );
  }

  Widget _buildTruckTab() {
    return ListView(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 18.h),
      children: [
        if (_isLoadingTruckBookings)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: CircularProgressIndicator(color: Color(0xFF00A2E8)),
            ),
          )
        else if (_truckError != null)
          Center(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text(_truckError!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                  SizedBox(height: 10.h),
                  ElevatedButton(onPressed: _fetchTruckBookings, child: const Text('Retry')),
                ],
              ),
            ),
          )
        else if (_getFilteredTruckBookings().isEmpty)
          Center(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 40.h),
              child: Text('No truck bookings found.', style: TextStyle(color: Colors.grey, fontSize: 13.sp)),
            ),
          )
        else
          ..._getFilteredTruckBookings().map((booking) {
            final vehicleType = booking['vehicleType'] as String? ?? 'TRUCK_SMALL';
            final title = vehicleType == 'TRUCK_SMALL'
                ? 'Tata Ace'
                : vehicleType == 'TRUCK_MEDIUM'
                    ? 'Pickup'
                    : vehicleType == 'TRUCK_LARGE'
                        ? 'Mini Truck'
                        : 'Large Truck';
            final status = booking['status'] as String? ?? 'PENDING_DRIVER_ASSIGNMENT';
            final displayStatus = _getDisplayStatus(status);
            final double totalFare = (booking['totalFare'] as num?)?.toDouble() ?? 0.0;
            final pickupAddr = booking['pickupLocation']?['address'] as String? ?? 'Pickup address';
            final dropAddr = booking['dropLocation']?['address'] as String? ?? 'Drop address';
            final driver = booking['driver'] ?? {};
            final driverName = driver['name'] as String?;

            return Padding(
              padding: EdgeInsets.only(bottom: 10.h),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => DeliveryBookedScreen(bookingId: booking['id'])),
                  ).then((_) => _fetchTruckBookings());
                },
                child: _buildActiveBookingCard(
                  accentColor: status == 'CANCELLED'
                      ? Colors.red
                      : status == 'DELIVERED'
                          ? const Color(0xFF22C55E)
                          : const Color(0xFFF97316),
                  backgroundColor: status == 'CANCELLED'
                      ? const Color(0xFFFFEBEE)
                      : status == 'DELIVERED'
                          ? const Color(0xFFF1FBF4)
                          : const Color(0xFFFFF6ED),
                  type: 'Truck',
                  status: displayStatus,
                  title: title,
                  route: pickupAddr,
                  destination: dropAddr,
                  etaLabel: 'Total Fare',
                  eta: '₹${totalFare.toStringAsFixed(0)}',
                  trackLabel: status == 'DELIVERED'
                      ? 'View Details'
                      : status == 'CANCELLED'
                          ? 'Cancelled'
                          : 'Track Truck',
                  driverName: driverName,
                  rating: driverName != null ? '4.8' : null,
                  imagePath: 'assets/images/truck.png',
                ),
              ),
            );
          }).toList(),
      ],
    );
  }


  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 16.h,
        left: 16.w,
        right: 16.w,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context);
              } else {
                final mainNav = context.findAncestorStateOfType<MainNavigationScreenState>();
                if (mainNav != null) {
                  mainNav.setIndex(0);
                } else {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const MainNavigationScreen(initialIndex: 0)),
                    (route) => false,
                  );
                }
              }
            },
            child: Container(
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                Icons.arrow_back_rounded,
                size: 18.sp,
                color: AppColors.textPrimary ?? Colors.black, // Fallback if textPrimary not available in context
              ),
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Text(
              'My Bookings',
              style: AppFonts.h1.copyWith(
                color: AppColors.black,
                fontSize: 20.sp,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Container(
            width: 38.w,
            height: 38.w,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.grey.shade200),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(Icons.search, color: AppColors.black, size: 20.sp),
          ),
        ],
      ),
    );
  }

  // _buildFilters has been replaced by TabBar

  Widget _buildSectionHeader(String title, {Widget? trailing}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: AppFonts.h2.copyWith(
            color: AppColors.black,
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
        if (trailing != null) trailing,
      ],
    );
  }

  Widget _buildActiveBookingCard({
    required Color accentColor,
    required Color backgroundColor,
    required String type,
    required String status,
    required String title,
    required String route,
    required String destination,
    required String etaLabel,
    required String eta,
    required String trackLabel,
    String? imagePath,
    String? driverName,
    String? rating,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.w),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: accentColor.withOpacity(0.20)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildServiceImage(type: type, imagePath: imagePath),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildBadge(
                      type,
                      accentColor,
                      accentColor.withOpacity(0.10),
                    ),
                    const Spacer(),
                    Flexible(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: _buildBadge(
                          status,
                          accentColor,
                          accentColor.withOpacity(0.08),
                        ),
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Icon(
                      Icons.more_vert,
                      color: Colors.grey.shade600,
                      size: 18.sp,
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Row(
                  children: [
                    Container(
                      width: 6.w,
                      height: 6.w,
                      decoration: BoxDecoration(
                        color: accentColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Expanded(
                      child: Text(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppFonts.bodyText.copyWith(
                          color: AppColors.black,
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 2.w, top: 3.h),
                      child: Column(
                        children: [
                          Container(
                            width: 1.w,
                            height: 16.h,
                            color: accentColor.withOpacity(0.35),
                          ),
                          Container(
                            width: 6.w,
                            height: 6.w,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: accentColor,
                                width: 1.5.w,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 9.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            route,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppFonts.captionDark.copyWith(
                              color: AppColors.textSecondary,
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 3.h),
                          Row(
                            children: [
                              Icon(
                                Icons.arrow_right_alt,
                                size: 14.sp,
                                color: Colors.grey.shade600,
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: Text(
                                  destination,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppFonts.captionDark.copyWith(
                                    color: AppColors.textSecondary,
                                    fontSize: 10.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 8.w),
                    _buildEtaBlock(
                      accentColor: accentColor,
                      etaLabel: etaLabel,
                      eta: eta,
                    ),
                  ],
                ),
                if (driverName != null) ...[
                  SizedBox(height: 6.h),
                  Row(
                    children: [
                      Container(
                        width: 28.w,
                        height: 28.w,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.person,
                          color: Colors.grey.shade700,
                          size: 18.sp,
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          driverName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppFonts.captionDark.copyWith(
                            color: AppColors.black,
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Icon(
                        Icons.star,
                        color: const Color(0xFFFFB300),
                        size: 14.sp,
                      ),
                      SizedBox(width: 3.w),
                      Text(
                        rating ?? '',
                        style: AppFonts.captionDark.copyWith(
                          color: AppColors.black,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
                SizedBox(height: 6.h),
                Align(
                  alignment: Alignment.centerRight,
                  child: _buildTrackButton(accentColor, trackLabel),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceImage({required String type, String? imagePath}) {
    return Container(
      width: 58.w,
      height: 58.w,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.86),
        borderRadius: BorderRadius.circular(18.r),
      ),
      padding: EdgeInsets.all(type == 'Parcel' ? 10.w : 6.w),
      child: type == 'Parcel'
          ? _buildParcelIcon()
          : Image.asset(imagePath!, fit: BoxFit.contain),
    );
  }

  Widget _buildParcelIcon() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFE9FBEF),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Icon(
        Icons.inventory_2,
        color: const Color(0xFF58C56F),
        size: 30.sp,
      ),
    );
  }

  Widget _buildEtaBlock({
    required Color accentColor,
    required String etaLabel,
    required String eta,
  }) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: 82.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            etaLabel,
            textAlign: TextAlign.right,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.captionDark.copyWith(
              color: AppColors.textSecondary,
              fontSize: 9.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            eta,
            textAlign: TextAlign.right,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.bodyText.copyWith(
              color: accentColor,
              fontSize: 14.sp,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBadge(String text, Color color, Color backgroundColor) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(6.r),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: AppFonts.captionDark.copyWith(
          color: color,
          fontSize: 9.sp,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _buildTrackButton(Color color, String label) {
    return Container(
      height: 30.h,
      padding: EdgeInsets.symmetric(horizontal: 12.w),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.72),
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: color.withOpacity(0.20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: AppFonts.captionDark.copyWith(
              color: color,
              fontSize: 10.sp,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(width: 4.w),
          Icon(Icons.chevron_right, color: color, size: 14.sp),
        ],
      ),
    );
  }

  Widget _buildSmallBookingTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String amount,
    required String status,
  }) {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: Colors.grey.shade100),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 34.w,
            height: 34.w,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.10),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 18.sp),
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppFonts.bodyText.copyWith(
                    color: AppColors.black,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 3.h),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppFonts.captionDark.copyWith(
                    color: AppColors.textSecondary,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 8.w),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                amount,
                style: AppFonts.bodyText.copyWith(
                  color: AppColors.black,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 4.h),
              _buildBadge(
                status,
                const Color(0xFF22C55E),
                const Color(0xFFEAF8EF),
              ),
            ],
          ),
          SizedBox(width: 6.w),
          Icon(Icons.chevron_right, color: Colors.grey.shade400, size: 18.sp),
        ],
      ),
    );
  }

  Widget _buildCancelledTile() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Row(
        children: [
          Container(
            width: 24.w,
            height: 24.w,
            decoration: const BoxDecoration(
              color: Color(0xFFFFEBEE),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.close,
              color: const Color(0xFFE53935),
              size: 14.sp,
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              '1 Cancelled Booking',
              style: AppFonts.bodyText.copyWith(
                color: AppColors.black,
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Icon(Icons.keyboard_arrow_down, color: Colors.grey.shade500),
        ],
      ),
    );
  }
}
