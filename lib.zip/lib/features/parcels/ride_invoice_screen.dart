import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../constants/app_fonts.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import '../rides/looking_for_ride_screen.dart';

class RideInvoiceScreen extends StatefulWidget {
  final String pickupAddress;
  final String pickupContactName;
  final String pickupContactPhone;
  final LatLng pickupLatLng;
  final String dropAddress;
  final String dropContactName;
  final String dropContactPhone;
  final LatLng dropLatLng;
  final Map<String, dynamic> selectedParcel;
  final String goodsType;
  final String helperRequired;

  const RideInvoiceScreen({
    super.key,
    required this.pickupAddress,
    required this.pickupContactName,
    required this.pickupContactPhone,
    required this.pickupLatLng,
    required this.dropAddress,
    required this.dropContactName,
    required this.dropContactPhone,
    required this.dropLatLng,
    required this.selectedParcel,
    required this.goodsType,
    required this.helperRequired,
  });

  @override
  State<RideInvoiceScreen> createState() => _RideInvoiceScreenState();
}

class _RideInvoiceScreenState extends State<RideInvoiceScreen> {
  bool _isBooking = false;
  String? _errorMessage;

  double _getPriceValue() {
    final priceStr = widget.selectedParcel['price'] as String? ?? '0';
    final cleaned = priceStr.replaceAll(RegExp(r'[^\d]'), '');
    return double.tryParse(cleaned) ?? 0.0;
  }

  bool get _helperRequired {
    return widget.helperRequired.trim().toLowerCase().startsWith('yes');
  }

  int get _helperCount {
    final match = RegExp(r'\d+').firstMatch(widget.helperRequired);
    final count = int.tryParse(match?.group(0) ?? '');
    return count != null && count > 0 ? count : 1;
  }

  Future<void> _createBooking() async {
    if (_isBooking) return;

    setState(() {
      _isBooking = true;
      _errorMessage = null;
    });

    try {
      final body = <String, dynamic>{
        'pickupLocation': {
          'address': widget.pickupAddress,
          'latitude': widget.pickupLatLng.latitude,
          'longitude': widget.pickupLatLng.longitude,
        },
        'dropLocation': {
          'address': widget.dropAddress,
          'latitude': widget.dropLatLng.latitude,
          'longitude': widget.dropLatLng.longitude,
        },
        'vehicleType': widget.selectedParcel['vehicleType'] ?? 'TRUCK_MEDIUM',
        'carName': widget.selectedParcel['title'] ?? 'Truck',
        'goodsType': widget.goodsType,
        'weight': 120,
        'quantity': 1,
        'description': 'Office goods and delivery',
        'paymentType': 'CASH',
        'senderName': widget.pickupContactName,
        'senderPhone': widget.pickupContactPhone,
        'senderAddress': widget.pickupAddress,
        'senderLat': widget.pickupLatLng.latitude,
        'senderLng': widget.pickupLatLng.longitude,
        'receiverName': widget.dropContactName,
        'receiverPhone': widget.dropContactPhone,
        'receiverAddress': widget.dropAddress,
        'receiverLat': widget.dropLatLng.latitude,
        'receiverLng': widget.dropLatLng.longitude,
        'isSenderReceiverSame': false,
        'helperRequired': _helperRequired,
        if (_helperRequired) 'helperCount': _helperCount,
      };

      final response = await ApiService.to.post(
        ApiEndpoints.goodsBookings,
        body: body,
      );

      final responseBody = response.data;
      final data = responseBody is Map ? responseBody['data'] : null;
      final bookingId = data is Map
          ? (data['id'] ?? data['bookingId'] ?? data['goodsBookingId'])
                ?.toString()
          : null;

      if (bookingId == null || bookingId.isEmpty) {
        throw Exception('Booking created but booking id was not returned.');
      }

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => LookingForRideScreen(tripId: bookingId),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _errorMessage = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          _isBooking = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final priceValue = _getPriceValue();
    final advanceValue = priceValue * 0.5;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Container(
              color: const Color(0xFFE6F7FD),
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 16.h,
                bottom: 16.h,
                left: 20.w,
                right: 20.w,
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 36.w,
                      height: 36.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.arrow_back_rounded,
                        size: 18.sp,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  SizedBox(width: 16.w),
                  Expanded(
                    child: Text(
                      'Ride Invoice',
                      style: AppFonts.h1.copyWith(
                        fontSize: 26.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            if (_errorMessage != null)
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
                padding: EdgeInsets.all(12.w),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: Colors.red[200]!),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        _errorMessage!,
                        style: TextStyle(
                          color: Colors.red[900],
                          fontSize: 13.sp,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            // Invoice Content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
                child: Column(
                  children: [
                    // Location Details Card
                    Container(
                      padding: EdgeInsets.only(
                        top: 14.h,
                        right: 14.w,
                        bottom: 14.h,
                        left: 14.w,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12.r),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                        border: Border.all(
                          color: Colors.black.withOpacity(0.10),
                          width: 0.5,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Location Details',
                            style: AppFonts.h2.copyWith(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 16.h),
                          IntrinsicHeight(
                            child: Row(
                              children: [
                                // Timeline Dots and Line
                                Column(
                                  children: [
                                    SizedBox(height: 8.h),
                                    // Green Dot
                                    Container(
                                      width: 20.w,
                                      height: 20.w,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF439A72).withOpacity(0.3),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Center(
                                        child: Container(
                                          width: 12.w,
                                          height: 12.w,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: const Color(0xFF439A72),
                                              width: 2.5.w,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    // Line
                                    Expanded(
                                      child: Container(
                                        width: 1.5.w,
                                        color: Colors.grey.shade300,
                                        margin: EdgeInsets.symmetric(vertical: 2.h),
                                      ),
                                    ),
                                    // Red Location Pin
                                    Icon(
                                      Icons.location_on,
                                      color: const Color(0xFF9E1000),
                                      size: 22.sp,
                                    ),
                                    SizedBox(height: 8.h),
                                  ],
                                ),
                                SizedBox(width: 8.w),
                                // Texts and Boxes
                                Expanded(
                                  child: Column(
                                    children: [
                                      // Top Box (Pickup)
                                      Container(
                                        width: double.infinity,
                                        padding: EdgeInsets.only(
                                          top: 8.h,
                                          right: 12.w,
                                          bottom: 8.h,
                                          left: 12.w,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(10.r),
                                          border: Border.all(
                                            color: const Color(0xFFF0F0F0),
                                            width: 1,
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '${widget.pickupContactName} | ${widget.pickupContactPhone}',
                                              style: AppFonts.captionDark.copyWith(
                                                color: Colors.grey.shade500,
                                                fontSize: 12.sp,
                                              ),
                                            ),
                                            SizedBox(height: 3.h),
                                            Text(
                                              widget.pickupAddress,
                                              style: AppFonts.bodyText.copyWith(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w800,
                                                fontSize: 13.sp,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 8.h),
                                      // Bottom Box (Delivery)
                                      Container(
                                        width: double.infinity,
                                        padding: EdgeInsets.only(
                                          top: 8.h,
                                          right: 12.w,
                                          bottom: 8.h,
                                          left: 12.w,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(10.r),
                                          border: Border.all(
                                            color: const Color(0xFFF0F0F0),
                                            width: 1,
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '${widget.dropContactName} | ${widget.dropContactPhone}',
                                              style: AppFonts.captionDark.copyWith(
                                                color: Colors.grey.shade500,
                                                fontSize: 12.sp,
                                              ),
                                            ),
                                            SizedBox(height: 3.h),
                                            Text(
                                              widget.dropAddress,
                                              style: AppFonts.bodyText.copyWith(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w800,
                                                fontSize: 13.sp,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h),

                    // Booking Summary Card
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(16.w),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.r),
                        border: Border.all(
                          color: const Color(0xFF00ABE4).withOpacity(0.2),
                          width: 1.w,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.02),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Booking Summary',
                            style: AppFonts.h2.copyWith(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 16.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Vehicle Type',
                                style: AppFonts.captionDark.copyWith(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                widget.selectedParcel['title'] ?? 'Truck',
                                style: AppFonts.bodyText.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Goods Type',
                                style: AppFonts.captionDark.copyWith(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                widget.goodsType,
                                style: AppFonts.bodyText.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Helper Service',
                                style: AppFonts.captionDark.copyWith(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                widget.helperRequired,
                                style: AppFonts.bodyText.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Estimate ETA',
                                style: AppFonts.captionDark.copyWith(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                widget.selectedParcel['time'] ?? 'ETA 8 mins',
                                style: AppFonts.bodyText.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 12.h),
                            child: Divider(color: Colors.grey.shade200),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Total Fare',
                                style: AppFonts.bodyText.copyWith(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                '₹${priceValue.toStringAsFixed(2)}',
                                style: AppFonts.h1.copyWith(
                                  fontSize: 16.sp,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h),

                    // Advance Payment Info Box
                    Container(
                      padding: EdgeInsets.all(12.w),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF4E5),
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(
                          color: const Color(0xFFFFCC80),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: const Color(0xFFF57C00),
                            size: 24.sp,
                          ),
                          SizedBox(width: 12.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Advance Payment Required',
                                  style: AppFonts.bodyText.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFFE65100),
                                    fontSize: 13.sp,
                                  ),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  'You need to pay 50% of the total fare in advance to confirm your booking. The rest can be paid upon delivery.',
                                  style: AppFonts.bodyText.copyWith(
                                    color: const Color(
                                      0xFFE65100,
                                    ).withOpacity(0.8),
                                    fontSize: 11.sp,
                                    height: 1.3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Bottom Payment Action
            Container(
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Amount to Pay Now (50%)',
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.grey.shade500,
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        '₹${advanceValue.toStringAsFixed(2)}',
                        style: AppFonts.h1.copyWith(
                          fontSize: 22.sp,
                          color: const Color(0xFF00ABE4),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16.h),
                  SizedBox(
                    width: double.infinity,
                    height: 48.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF00ABE4),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                      ),
                      onPressed: _isBooking ? null : _createBooking,
                      child: _isBooking
                          ? const CircularProgressIndicator(color: Colors.white)
                          : Text(
                              'Pay Advance & Book Truck',
                              style: AppFonts.buttonText.copyWith(
                                color: Colors.white,
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
