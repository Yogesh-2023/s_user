import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/services.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../core/utils.dart';
import 'receiver_details_screen.dart';

class AddAddressScreen extends StatefulWidget {
  final String? selectedAddress;
  
  const AddAddressScreen({
    super.key,
    this.selectedAddress,
  });

  @override
  State<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  // Form controllers
  final TextEditingController _contactNameController = TextEditingController();
  final TextEditingController _mobileNumberController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _addressLine1Controller = TextEditingController();
  final TextEditingController _helperCountController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  // Selections
  String _selectedAddressType = 'Other'; // Default selected in image
  String _selectedMovingType = 'Other'; // Default selected in image
  String _helperRequired =
      'No'; // Default "No I don't need helper" selected in image
  bool _saveForFuture = true;

  @override
  void initState() {
    super.initState();
    if (widget.selectedAddress != null) {
      _addressController.text = widget.selectedAddress!;
      _addressLine1Controller.text = widget.selectedAddress!;
    }
  }

  @override
  void dispose() {
    _contactNameController.dispose();
    _mobileNumberController.dispose();
    _addressController.dispose();
    _addressLine1Controller.dispose();
    _helperCountController.dispose();
    super.dispose();
  }

  // Address Type Config
  final List<Map<String, dynamic>> _addressTypes = [
    {
      'title': 'Home',
      'icon': Icons.home_outlined,
      'color': const Color(0xFF4CAF50),
      'bgColor': const Color(0xFFE8F5E9),
    },
    {
      'title': 'Office',
      'icon': Icons.work_outline,
      'color': const Color(0xFF2196F3),
      'bgColor': const Color(0xFFE3F2FD),
    },
    {
      'title': 'Shop',
      'icon': Icons.storefront_outlined,
      'color': const Color(0xFF9C27B0),
      'bgColor': const Color(0xFFF3E5F5),
    },
    {
      'title': 'Other',
      'icon': Icons.star_outline,
      'color': const Color(0xFFFFB300),
      'bgColor': const Color(0xFFFFF8E1),
    },
  ];

  // Moving Goods Type Config
  final List<Map<String, dynamic>> _movingTypes = [
    {
      'title': 'Furniture',
      'icon': Icons.weekend_outlined,
      'color': const Color(0xFF4CAF50),
      'bgColor': const Color(0xFFE8F5E9),
    },
    {
      'title': 'Home Items',
      'icon': Icons.inventory_2_outlined,
      'color': const Color(0xFF2196F3),
      'bgColor': const Color(0xFFE3F2FD),
    },
    {
      'title': 'Office Goods',
      'icon': Icons.business_center_outlined,
      'color': const Color(0xFF9C27B0),
      'bgColor': const Color(0xFFF3E5F5),
    },
    {
      'title': 'Other',
      'icon': Icons.star_outline,
      'color': const Color(0xFFFFB300),
      'bgColor': const Color(0xFFFFF8E1),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      behavior: HitTestBehavior.opaque,
      child: Scaffold(
      backgroundColor: const Color(
        0xFFEBF7FD,
      ), // Soft light blue header background
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Custom Header / AppBar
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: EdgeInsets.all(8.w),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.arrow_back,
                        color: Colors.black,
                        size: 20.sp,
                      ),
                    ),
                  ),
                  SizedBox(width: 16.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Add New Address',
                        style: AppFonts.h2.copyWith(
                          fontSize: 18.sp,
                          color: Colors.black,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'Enter the pickup location details',
                        style: AppFonts.bodyText.copyWith(
                          fontSize: 12.sp,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Form container taking full width and bottom rounded corners
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(24.r),
                  ),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Expanded(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.fromLTRB(20.w, 24.h, 20.w, 20.h),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Address Field
                              _buildFieldLabel('Address'),
                              SizedBox(height: 8.h),
                              _buildAddressTextField(
                                controller: _addressController,
                                hintText: 'Enter address',
                                validator: (value) {
                                  if (value == null || value.trim().isEmpty) {
                                    return 'Please enter address';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 20.h),

                              // Address Type Title
                              Text(
                                'Address type',
                                style: AppFonts.bodyText.copyWith(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13.sp,
                                ),
                              ),
                              SizedBox(height: 12.h),

                              // Address Type Cards Row
                              Row(
                                children: _addressTypes.map((type) {
                                  final isSelected =
                                      _selectedAddressType == type['title'];
                                  return Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _selectedAddressType = type['title'];
                                        });
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                          horizontal: 4.w,
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          vertical: 8.h,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            12.r,
                                          ),
                                          border: Border.all(
                                            color: isSelected
                                                ? const Color(0xFF00ABE4)
                                                : Colors.grey.shade200,
                                            width: isSelected ? 1.5.w : 1.w,
                                          ),
                                        ),
                                        child: Column(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.all(6.w),
                                              decoration: BoxDecoration(
                                                color: type['bgColor'],
                                                shape: BoxShape.circle,
                                              ),
                                              child: Icon(
                                                type['icon'],
                                                color: type['color'],
                                                size: 18.sp,
                                              ),
                                            ),
                                            SizedBox(height: 6.h),
                                            Text(
                                              type['title'],
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: AppFonts.bodyText.copyWith(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 11.sp,
                                              ),
                                            ),
                                            SizedBox(height: 6.h),
                                            // Radio Button UI
                                            Container(
                                              width: 12.w,
                                              height: 12.w,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: isSelected
                                                      ? const Color(0xFF00ABE4)
                                                      : Colors.grey.shade300,
                                                  width: 1.5.w,
                                                ),
                                              ),
                                              child: isSelected
                                                  ? Center(
                                                      child: Container(
                                                        width: 6.w,
                                                        height: 6.w,
                                                        decoration:
                                                            const BoxDecoration(
                                                              color: Color(
                                                                0xFF00ABE4,
                                                              ),
                                                              shape: BoxShape
                                                                  .circle,
                                                            ),
                                                      ),
                                                    )
                                                  : null,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                              SizedBox(height: 20.h),

                              // Contact Person Field
                              _buildFieldLabel('Contact Person'),
                              SizedBox(height: 8.h),
                              _buildTextField(
                                controller: _contactNameController,
                                hintText: 'Enter contact name',
                                prefixIcon: Icons.person_outline_outlined,
                                textCapitalization: TextCapitalization.words,
                                inputFormatters: [
                                  _CapitalizeFirstLetterFormatter(),
                                ],
                                validator: (value) {
                                  if (value == null || value.trim().isEmpty) {
                                    return 'Please enter contact name';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 16.h),

                              // Mobile Number Field
                              _buildFieldLabel('Mobile Number'),
                              SizedBox(height: 8.h),
                              _buildTextField(
                                controller: _mobileNumberController,
                                hintText: 'Enter Mobile number',
                                prefixIcon: Icons.phone_outlined,
                                keyboardType: TextInputType.phone,
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(10),
                                ],
                                validator: (value) {
                                  if (value == null || value.trim().isEmpty) {
                                    return 'Please enter mobile number';
                                  }
                                  if (value.length != 10) {
                                    return 'Please enter a valid mobile number';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 16.h),

                              // Address Line 1 Field
                              _buildFieldLabel(
                                'Address Line 1 (House no, Building, Street) (optional)',
                              ),
                              SizedBox(height: 8.h),
                              _buildTextField(
                                controller: _addressLine1Controller,
                                hintText: 'Enter address line 1',
                                prefixIcon: Icons.map_outlined,
                              ),
                              SizedBox(height: 20.h),

                              // What are you moving? Section
                              Text(
                                'What are you moving?',
                                style: AppFonts.bodyText.copyWith(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13.sp,
                                ),
                              ),
                              SizedBox(height: 12.h),

                              // Moving Goods Row
                              Row(
                                children: _movingTypes.map((type) {
                                  final isSelected =
                                      _selectedMovingType == type['title'];
                                  return Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _selectedMovingType = type['title'];
                                        });
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                          horizontal: 4.w,
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          vertical: 8.h,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            12.r,
                                          ),
                                          border: Border.all(
                                            color: isSelected
                                                ? const Color(0xFF00ABE4)
                                                : Colors.grey.shade200,
                                            width: isSelected ? 1.5.w : 1.w,
                                          ),
                                        ),
                                        child: Column(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.all(6.w),
                                              decoration: BoxDecoration(
                                                color: type['bgColor'],
                                                shape: BoxShape.circle,
                                              ),
                                              child: Icon(
                                                type['icon'],
                                                color: type['color'],
                                                size: 18.sp,
                                              ),
                                            ),
                                            SizedBox(height: 6.h),
                                            Text(
                                              type['title'],
                                              textAlign: TextAlign.center,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: AppFonts.bodyText.copyWith(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 11.sp,
                                              ),
                                            ),
                                            SizedBox(height: 6.h),
                                            // Radio Button UI
                                            Container(
                                              width: 12.w,
                                              height: 12.w,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: isSelected
                                                      ? const Color(0xFF00ABE4)
                                                      : Colors.grey.shade300,
                                                  width: 1.5.w,
                                                ),
                                              ),
                                              child: isSelected
                                                  ? Center(
                                                      child: Container(
                                                        width: 6.w,
                                                        height: 6.w,
                                                        decoration:
                                                            const BoxDecoration(
                                                              color: Color(
                                                                0xFF00ABE4,
                                                              ),
                                                              shape: BoxShape
                                                                  .circle,
                                                            ),
                                                      ),
                                                    )
                                                  : null,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                              SizedBox(height: 20.h),

                              // Helper Required? Section
                              Text(
                                'Helper Required?',
                                style: AppFonts.bodyText.copyWith(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13.sp,
                                ),
                              ),
                              SizedBox(height: 12.h),

                              // Helper Selection Row
                              Row(
                                children: [
                                  _buildHelperCard(
                                    title: 'Yes I need a helper',
                                    isSelected: _helperRequired == 'Yes',
                                    onTap: () =>
                                        setState(() => _helperRequired = 'Yes'),
                                  ),
                                  SizedBox(width: 12.w),
                                  _buildHelperCard(
                                    title: "No I don't need helper",
                                    isSelected: _helperRequired == 'No',
                                    onTap: () =>
                                        setState(() => _helperRequired = 'No'),
                                  ),
                                ],
                              ),
                              if (_helperRequired == 'Yes') ...[
                                SizedBox(height: 16.h),
                                _buildFieldLabel('How many helpers/drivers do you need?'),
                                SizedBox(height: 8.h),
                                _buildTextField(
                                  controller: _helperCountController,
                                  hintText: 'Enter number of helpers/drivers',
                                  prefixIcon: Icons.group_outlined,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                  ],
                                  validator: (value) {
                                    if (_helperRequired == 'Yes') {
                                      if (value == null || value.trim().isEmpty) {
                                        return 'Please enter number of helpers';
                                      }
                                      if (int.tryParse(value) == null || int.parse(value) <= 0) {
                                        return 'Please enter a valid number';
                                      }
                                    }
                                    return null;
                                  },
                                ),
                              ],
                              SizedBox(height: 24.h),

                              // Save this address for future
                              Row(
                                children: [
                                  Container(
                                    width: 36.w,
                                    height: 36.w,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFEDE7F6),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Center(
                                      child: Icon(
                                        Icons.bookmark_outline,
                                        color: Color(0xFF673AB7),
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 12.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Save this address for future',
                                          style: AppFonts.bodyText.copyWith(
                                            color: Colors.black,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 13.sp,
                                            height: 1.2,
                                          ),
                                        ),
                                        SizedBox(height: 2.h),
                                        Text(
                                          'Easily reuse for next delivery',
                                          style: AppFonts.bodyText.copyWith(
                                            color: Colors.grey.shade500,
                                            fontSize: 11.sp,
                                            height: 1.2,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Custom Animated Switch Toggle
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        _saveForFuture = !_saveForFuture;
                                      });
                                    },
                                    child: AnimatedContainer(
                                      duration: const Duration(
                                        milliseconds: 200,
                                      ),
                                      width: 44.w,
                                      height: 24.h,
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 2.w,
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                          12.r,
                                        ),
                                        color: _saveForFuture
                                            ? Colors.white
                                            : Colors.white,
                                        border: Border.all(
                                          color: _saveForFuture
                                              ? const Color(0xFF00ABE4)
                                              : Colors.grey.shade300,
                                          width: 1.5.w,
                                        ),
                                      ),
                                      alignment: _saveForFuture
                                          ? Alignment.centerRight
                                          : Alignment.centerLeft,
                                      child: Container(
                                        width: 16.w,
                                        height: 16.w,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: _saveForFuture
                                              ? const Color(0xFF00ABE4)
                                              : Colors.grey.shade400,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Fixed Save Address button at the bottom of the container
                      Container(
                        padding: EdgeInsets.only(
                          left: 20.w,
                          right: 20.w,
                          top: 12.h,
                          bottom: MediaQuery.of(context).padding.bottom > 0
                              ? MediaQuery.of(context).padding.bottom + 10.h
                              : 16.h,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border(
                            top: BorderSide(
                              color: Colors.grey.shade100,
                              width: 1,
                            ),
                          ),
                        ),
                        child: SizedBox(
                          width: double.infinity,
                          height: 44.h,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00ABE4),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.r),
                              ),
                            ),
                            onPressed: _onSaveAddressPressed,
                            child: Text(
                              'Next',
                              style: AppFonts.buttonText.copyWith(
                                color: Colors.white,
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

  Widget _buildFieldLabel(String label) {
    return Text(
      label,
      style: AppFonts.bodyText.copyWith(
        color: Colors.grey.shade700,
        fontWeight: FontWeight.w600,
        fontSize: 12.sp,
      ),
    );
  }

  Widget _buildAddressTextField({
    required TextEditingController controller,
    required String hintText,
    String? Function(String?)? validator,
  }) {
    return FormField<String>(
      initialValue: controller.text,
      validator: validator,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      builder: (field) {
        final hasError = field.hasError;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F8FD),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: hasError
                      ? Colors.redAccent
                      : Colors.blue.shade100,
                  width: 1.w,
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.location_on,
                    color: const Color(0xFF00ABE4),
                    size: 24.sp,
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      keyboardType: TextInputType.multiline,
                      maxLines: null,
                      onChanged: field.didChange,
                      style: AppFonts.bodyText.copyWith(
                        color: Colors.black87,
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w700,
                      ),
                      decoration: InputDecoration(
                        isDense: true,
                        border: InputBorder.none,
                        hintText: hintText,
                        hintStyle: AppFonts.bodyText.copyWith(
                          color: Colors.grey.shade400,
                          fontSize: 13.sp,
                          fontWeight: FontWeight.normal,
                        ),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (hasError) ...[
              SizedBox(height: 4.h),
              Padding(
                padding: EdgeInsets.only(left: 4.w),
                child: Text(
                  field.errorText ?? '',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 10.sp,
                    height: 1.2,
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    required IconData prefixIcon,
    TextInputType keyboardType = TextInputType.text,
    TextCapitalization textCapitalization = TextCapitalization.none,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
  }) {
    return FormField<String>(
      initialValue: controller.text,
      validator: validator,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      builder: (field) {
        final hasError = field.hasError;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 44.h,
              decoration: BoxDecoration(
                color: AppColors.textFieldBackground,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: hasError
                      ? Colors.redAccent
                      : AppColors.authButtonBorder,
                  width: 1.w,
                ),
              ),
              child: TextField(
                controller: controller,
                keyboardType: keyboardType,
                textCapitalization: textCapitalization,
                inputFormatters: inputFormatters,
                onChanged: field.didChange,
                style: AppFonts.bodyText.copyWith(
                  color: Colors.black,
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  hintText: hintText,
                  hintStyle: AppFonts.bodyText.copyWith(
                    color: Colors.grey.shade400,
                    fontSize: 13.sp,
                    fontWeight: FontWeight.normal,
                  ),
                  prefixIcon: Icon(
                    prefixIcon,
                    color: Colors.grey.shade400,
                    size: 18.sp,
                  ),
                  prefixIconConstraints: BoxConstraints(minWidth: 42.w),
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 11.h,
                    horizontal: 12.w,
                  ),
                ),
              ),
            ),
            if (hasError) ...[
              SizedBox(height: 4.h),
              Padding(
                padding: EdgeInsets.only(left: 4.w),
                child: Text(
                  field.errorText ?? '',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 10.sp,
                    height: 1.2,
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _buildHelperCard({
    required String title,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 12.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8.r),
            border: Border.all(
              color: isSelected
                  ? const Color(0xFF00ABE4)
                  : Colors.grey.shade200,
              width: 1.w,
            ),
          ),
          child: Row(
            children: [
              // Radio indicator
              Container(
                width: 14.w,
                height: 14.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isSelected
                        ? const Color(0xFF00ABE4)
                        : Colors.grey.shade300,
                    width: 1.5.w,
                  ),
                ),
                child: isSelected
                    ? Center(
                        child: Container(
                          width: 8.w,
                          height: 8.w,
                          decoration: const BoxDecoration(
                            color: Color(0xFF00ABE4),
                            shape: BoxShape.circle,
                          ),
                        ),
                      )
                    : null,
              ),
              SizedBox(width: 6.w),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.black87,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                    fontSize: 10.sp,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onSaveAddressPressed() {
    if (_formKey.currentState!.validate()) {
      String helperInfo = _helperRequired;
      if (_helperRequired == 'Yes') {
        helperInfo = 'Yes, ${_helperCountController.text} Helpers';
      }
      
      String fullAddress = _addressController.text.trim();
      String line1 = _addressLine1Controller.text.trim();
      if (line1.isNotEmpty && line1 != fullAddress) {
        fullAddress = '$fullAddress, $line1';
      }
      
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ReceiverDetailsScreen(
            pickupAddress: fullAddress,
            pickupContactName: _contactNameController.text,
            pickupContactPhone: _mobileNumberController.text,
            goodsType: _selectedMovingType,
            helperRequired: helperInfo,
          ),
        ),
      );
    } else {
      AppUtils.showSnackBar(
        context,
        'Please fill all required fields',
        isError: true,
      );
    }
  }
}

class _CapitalizeFirstLetterFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;
    if (text.isEmpty) {
      return newValue;
    }

    final words = text.split(' ');
    final capitalizedWords = words.map((word) {
      if (word.isEmpty) return '';
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    }).toList();

    final capitalizedText = capitalizedWords.join(' ');
    
    int selectionIndex = newValue.selection.end;
    if (selectionIndex < 0) {
      selectionIndex = 0;
    }
    if (selectionIndex > capitalizedText.length) {
      selectionIndex = capitalizedText.length;
    }

    return TextEditingValue(
      text: capitalizedText,
      selection: TextSelection.collapsed(offset: selectionIndex),
    );
  }
}
