import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/api_keys.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../core/utils.dart';
import '../../core/api/api_service.dart';
import '../../widgets/custom_text_field.dart';
import 'choose_parcel_screen.dart';

class ReceiverDetailsScreen extends StatefulWidget {
  final String? pickupAddress;
  final String? pickupContactName;
  final String? pickupContactPhone;
  final String? goodsType;
  final String? helperRequired;

  const ReceiverDetailsScreen({
    super.key,
    this.pickupAddress,
    this.pickupContactName,
    this.pickupContactPhone,
    this.goodsType,
    this.helperRequired,
  });

  @override
  State<ReceiverDetailsScreen> createState() => _ReceiverDetailsScreenState();
}

class _ReceiverDetailsScreenState extends State<ReceiverDetailsScreen> {
  GoogleMapController? _mapController;
  bool _isLocationConfirmed = false;
  late final TextEditingController _searchController;
  late final TextEditingController _receiverNameController;
  late final TextEditingController _receiverMobileController;
  late final TextEditingController _receiverAddressLine1Controller;
  List<dynamic> _placeSuggestions = [];
  bool _useMyInfo = false;

  LatLng _cameraCenter = const LatLng(28.7041, 77.1025);
  bool _isReversingGeocode = false;
  final _formKey = GlobalKey<FormState>();

  final List<Map<String, dynamic>> _savedAddresses = [];

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _receiverNameController = TextEditingController();
    _receiverMobileController = TextEditingController();
    _receiverAddressLine1Controller = TextEditingController();
    _fetchRecentAddresses();
  }

  Future<void> _fetchRecentAddresses() async {
    try {
      print('APP LOG: Recent Addresses API call started in Receiver Details Screen');
      final response = await ApiService.to.get('/api/goods/bookings/recent-addresses?limit=5');
      print('APP LOG: Recent Addresses API Success in Receiver Details Screen -> ${response.data}');
      if (response.data != null && response.data['success'] == true) {
        final List<dynamic> recentList = response.data['data'] ?? [];
        final List<Map<String, dynamic>> parsedAddresses = [];
        final Set<String> existingSubtitles = _savedAddresses.map((e) => e['subtitle'] as String).toSet();

        for (var item in recentList) {
          String? address;
          String title = 'Recent Location';
          
          if (item is String) {
            address = item;
          } else if (item is Map<String, dynamic>) {
            title = item['title'] ?? item['name'] ?? 'Recent Location';
            address = item['address'] ?? 
                      item['pickupAddress'] ?? 
                      item['dropAddress'] ?? 
                      item['subtitle'] ?? 
                      item['formattedAddress'];
          }
          
          if (address != null && address.trim().isNotEmpty) {
            final trimmed = address.trim();
            if (!existingSubtitles.contains(trimmed)) {
              existingSubtitles.add(trimmed);
              parsedAddresses.add({
                'icon': Icons.history,
                'color': const Color(0xFFE0F7FA),
                'iconColor': const Color(0xFF00B8D4),
                'title': title,
                'subtitle': trimmed,
              });
            }
          }
        }
        
        if (parsedAddresses.isNotEmpty) {
          setState(() {
            _savedAddresses.addAll(parsedAddresses);
          });
        }
      }
    } catch (e) {
      print('APP LOG: Recent Addresses API Error in Receiver Details Screen -> $e');
    }
  }

  Future<void> _getPlaceSuggestions(String input) async {
    if (input.isEmpty) {
      setState(() {
        _placeSuggestions = [];
      });
      return;
    }

    final String url =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=${ApiKeys.googleMapsKey}&components=country:in';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK') {
          setState(() {
            _placeSuggestions = data['predictions'];
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching places: $e');
    }
  }

  Future<void> _reverseGeocode(LatLng latLng) async {
    if (_isReversingGeocode) return;
    setState(() {
      _isReversingGeocode = true;
    });

    final String url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${latLng.latitude},${latLng.longitude}&key=${ApiKeys.googleMapsKey}';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK' && data['results'] != null && data['results'].isNotEmpty) {
          final formattedAddress = data['results'][0]['formatted_address'] as String;
          final cleanedAddress = AppUtils.cleanGeocodedAddress(formattedAddress);
          setState(() {
            _searchController.text = cleanedAddress;
          });
        }
      }
    } catch (e) {
      debugPrint('Error reverse geocoding: $e');
    } finally {
      setState(() {
        _isReversingGeocode = false;
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _receiverNameController.dispose();
    _receiverMobileController.dispose();
    _receiverAddressLine1Controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      behavior: HitTestBehavior.opaque,
      child: Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            children: [
          // Background Map
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            bottom: MediaQuery.of(context).size.height * 0.45,
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: _cameraCenter,
                zoom: 15,
              ),
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              onMapCreated: (controller) {
                _mapController = controller;
              },
              onCameraMove: (position) {
                _cameraCenter = position.target;
              },
              onCameraIdle: () {
                _reverseGeocode(_cameraCenter);
              },
            ),
          ),

          // Custom Map Marker in Center
          Positioned(
            top: MediaQuery.of(context).size.height * 0.27,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                width: 50.w,
                height: 50.w,
                decoration: BoxDecoration(
                  color: const Color(0xFF13A9FF).withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Container(
                    width: 20.w,
                    height: 20.w,
                    decoration: const BoxDecoration(
                      color: Color(0xFF13A9FF),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.navigation,
                      color: Colors.white,
                      size: 12.sp,
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Top Header and Search Bar (Reused)
          Positioned(
            top: MediaQuery.of(context).padding.top + 10.h,
            left: 20.w,
            right: 20.w,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.all(8.w),
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Text(
                      'Receiver Details',
                      style: AppFonts.h1.copyWith(
                        fontSize: 18.sp,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16.h),
                ClipRRect(
                  borderRadius: BorderRadius.circular(47.r),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                    child: Container(
                      height: 45.h,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.90),
                        borderRadius: BorderRadius.circular(47.r),
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      child: TextField(
                        controller: _searchController,
                        onChanged: _getPlaceSuggestions,
                        style: AppFonts.bodyText.copyWith(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                          height: 1.2,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Search for area, street or landmark',
                          hintStyle: AppFonts.bodyText.copyWith(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey.shade400,
                            height: 1.2,
                          ),
                          prefixIcon: Padding(
                            padding: EdgeInsets.only(
                              left: 15.w,
                              right: 8.w,
                              top: 2.h,
                            ),
                            child: Icon(
                              Icons.search,
                              color: const Color(0xFF00ABE4),
                              size: 18.sp,
                            ),
                          ),
                          suffixIcon: ValueListenableBuilder<TextEditingValue>(
                            valueListenable: _searchController,
                            builder: (context, value, child) {
                              if (value.text.isNotEmpty) {
                                return GestureDetector(
                                  onTap: () {
                                    _searchController.clear();
                                    _getPlaceSuggestions('');
                                  },
                                  child: Icon(Icons.close, color: Colors.grey, size: 20.sp),
                                );
                              }
                              return const SizedBox.shrink();
                            },
                          ),
                          prefixIconConstraints: BoxConstraints(minWidth: 40.w),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(
                            top: 14.h,
                            bottom: 14.h,
                            right: 15.w,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Bottom Sheet Content
          Align(
            alignment: Alignment.bottomCenter,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              height: isKeyboardOpen 
                  ? constraints.maxHeight - (MediaQuery.of(context).padding.top + 140.h)
                  : MediaQuery.of(context).size.height * 0.68,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Drag Handle
                  SizedBox(height: 12.h),
                  Container(
                    width: 40.w,
                    height: 4.h,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2.r),
                    ),
                  ),
                  SizedBox(height: 16.h),

                  if (_placeSuggestions.isNotEmpty)
                    Expanded(
                      child: ListView.builder(
                        padding: EdgeInsets.only(
                          left: 20.w, 
                          right: 20.w, 
                          bottom: 20.h,
                        ),
                        itemCount: _placeSuggestions.length,
                        itemBuilder: (context, index) {
                          final place = _placeSuggestions[index];
                          final structuredFormatting = place['structured_formatting'] as Map<String, dynamic>?;
                          final mainText = structuredFormatting?['main_text'] ?? place['description'] ?? '';
                          final secondaryText = structuredFormatting?['secondary_text'] ?? '';

                          return InkWell(
                            onTap: () {
                              _searchController.text = mainText;
                              setState(() {
                                _placeSuggestions = [];
                                _isLocationConfirmed = true; // Auto-confirm on selection
                              });
                              FocusScope.of(context).unfocus();
                            },
                            child: Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12.r),
                                border: Border.all(
                                  color: const Color(0xFF00ABE4).withOpacity(0.20),
                                  width: 1.2.w,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF00ABE4).withOpacity(0.04),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 38.w,
                                    height: 38.w,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFE6F7FD),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.location_on_rounded,
                                      color: const Color(0xFF00ABE4),
                                      size: 20.sp,
                                    ),
                                  ),
                                  SizedBox(width: 14.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          mainText,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontFamily: AppFonts.fontFamily,
                                            fontSize: 15.sp,
                                            fontWeight: FontWeight.w700,
                                            color: const Color(0xFF1E293B),
                                            decoration: TextDecoration.none,
                                          ),
                                        ),
                                        if (secondaryText.isNotEmpty) ...[
                                          SizedBox(height: 4.h),
                                          Text(
                                            secondaryText,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontFamily: AppFonts.fontFamily,
                                              fontSize: 12.sp,
                                              fontWeight: FontWeight.w500,
                                              color: const Color(0xFF64748B),
                                              decoration: TextDecoration.none,
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: 8.w),
                                  Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    color: const Color(0xFF00ABE4).withOpacity(0.7),
                                    size: 14.sp,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  else if (_isLocationConfirmed)
                    Expanded(
                      child: Form(
                        key: _formKey,
                        child: SingleChildScrollView(
                          padding: EdgeInsets.only(
                            left: 20.w, 
                            right: 20.w, 
                            bottom: 20.h,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Location Timeline Card (Exactly like Figma)
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.only(
                              top: 15.h,
                              right: 15.w,
                              bottom: 15.h,
                              left: 20.w,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.textFieldBackground,
                              borderRadius: BorderRadius.circular(14.r),
                              border: Border.all(
                                color: AppColors.authButtonBorder,
                                width: 1,
                              ),
                            ),
                            child: IntrinsicHeight(
                              child: Row(
                                children: [
                                  // Timeline Dots and Line
                                  Column(
                                    children: [
                                      SizedBox(
                                        height: 12.h,
                                      ), // Align with first box center
                                      // Green Dot
                                      Container(
                                        width: 24.w,
                                        height: 24.w,
                                        decoration: BoxDecoration(
                                          color: const Color(
                                            0xFF439A72,
                                          ).withOpacity(0.3),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                          child: Container(
                                            width: 14.w,
                                            height: 14.w,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: const Color(0xFF439A72),
                                                width: 3.5.w,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      // Line
                                      Expanded(
                                        child: Container(
                                          width: 2.w,
                                          color: Colors.grey.shade300,
                                          margin: EdgeInsets.symmetric(
                                            vertical: 4.h,
                                          ),
                                        ),
                                      ),
                                      // Red Location Pin
                                      Icon(
                                        Icons.location_on,
                                        color: const Color(
                                          0xFF9E1000,
                                        ), // Dark Red
                                        size: 26.sp,
                                      ),
                                      SizedBox(
                                        height: 12.h,
                                      ), // Align with bottom box
                                    ],
                                  ),
                                  SizedBox(width: 10.w),
                                  // Texts and Boxes
                                  Expanded(
                                    child: Column(
                                      children: [
                                        // Top Box (Pickup)
                                        Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.only(
                                            top: 10.h,
                                            right: 14.w,
                                            bottom: 10.h,
                                            left: 14.w,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.circular(10.r),
                                            border: Border.all(
                                              color: Colors.grey.shade200,
                                              width: 1,
                                            ),
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Pick-up Location',
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  fontFamily: AppFonts.fontFamily,
                                                  color: Colors.grey.shade500,
                                                  fontSize: 12.sp,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              SizedBox(height: 2.h),
                                              Text(
                                                widget.pickupAddress ?? 'BSI Business Park H161 Noida Sector 63',
                                                style: TextStyle(
                                                  fontFamily: AppFonts.fontFamily,
                                                  color: Colors.black87,
                                                  fontSize: 14.sp,
                                                  fontWeight: FontWeight.w800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 12.h),
                                        // Bottom Box (Delivery)
                                        Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.only(
                                            top: 10.h,
                                            right: 14.w,
                                            bottom: 10.h,
                                            left: 14.w,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.circular(10.r),
                                            border: Border.all(
                                              color: Colors.grey.shade200,
                                              width: 1,
                                            ),
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Your Destination',
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  fontFamily: AppFonts.fontFamily,
                                                  color: Colors.grey.shade500,
                                                  fontSize: 12.sp,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              SizedBox(height: 2.h),
                                              Text(
                                                _searchController.text.isNotEmpty 
                                                    ? _searchController.text 
                                                    : 'Add Receiver address',
                                                style: TextStyle(
                                                  fontFamily: AppFonts.fontFamily,
                                                  color: Colors.black87,
                                                  fontSize: 14.sp,
                                                  fontWeight: FontWeight.w800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 20.h),

                          // Receiver Information Title
                          Text(
                            'Receiver Information',
                            style: AppFonts.h2.copyWith(
                              fontSize: 16.sp,
                              color: Colors.black,
                            ),
                          ),
                          SizedBox(height: 12.h),

                          // Form Fields
                          Text(
                            'Receiver Name',
                            style: AppFonts.captionDark.copyWith(
                              color: Colors.grey.shade600,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          _buildTextField(
                            controller: _receiverNameController,
                            hintText: 'Enter Receiver name',
                            prefixIcon: Icon(
                              Icons.person_outline,
                              color: Colors.grey.shade400,
                              size: 20.sp,
                            ),
                            textCapitalization: TextCapitalization.words,
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                            ],
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Please enter receiver name';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16.h),

                          Text(
                            'Mobile Number',
                            style: AppFonts.captionDark.copyWith(
                              color: Colors.grey.shade600,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          _buildTextField(
                            controller: _receiverMobileController,
                            hintText: 'Enter Mobile number',
                            prefixIcon: Icon(
                              Icons.phone_outlined,
                              color: Colors.grey.shade400,
                              size: 20.sp,
                            ),
                            keyboardType: TextInputType.phone,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Please enter mobile number';
                              }
                              if (value.trim().length < 10) {
                                return 'Please enter a valid 10-digit mobile number';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16.h),

                          Text(
                            'Address Line 1 (House no., Building, Street) (optional)',
                            style: AppFonts.captionDark.copyWith(
                              color: Colors.grey.shade600,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          _buildTextField(
                            controller: _receiverAddressLine1Controller,
                            hintText: 'Enter address line 1',
                            prefixIcon: Icon(
                              Icons.map_outlined,
                              color: Colors.grey.shade400,
                              size: 20.sp,
                            ),
                          ),
                          SizedBox(height: 16.h),
                          Row(
                            children: [
                              SizedBox(
                                width: 24.w,
                                height: 24.w,
                                child: Checkbox(
                                  value: _useMyInfo,
                                  onChanged: (val) async {
                                    setState(() {
                                      _useMyInfo = val ?? false;
                                    });
                                    if (_useMyInfo) {
                                      final prefs = await SharedPreferences.getInstance();
                                      final phone = prefs.getString('user_phone') ?? '9090909090';
                                      _receiverNameController.text = 'Guest User';
                                      _receiverMobileController.text = phone;
                                    } else {
                                      _receiverNameController.clear();
                                      _receiverMobileController.clear();
                                    }
                                  },
                                  activeColor: const Color(0xFF00ABE4),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(4.r),
                                  ),
                                ),
                              ),
                              SizedBox(width: 8.w),
                              Text(
                                'Use my Information',
                                style: AppFonts.bodyText.copyWith(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 24.h),
                        ],
                      ),
                    ),
                  ),
                )
                  else
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Recent & Saved Addresses',
                              style: AppFonts.h2.copyWith(
                                fontSize: 16.sp,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 16.h),
                            ..._savedAddresses.map(
                              (address) => _buildAddressTile(address),
                            ),
                            SizedBox(height: 24.h),
                          ],
                        ),
                      ),
                    ),

                  // Fixed Bottom Button
                  SafeArea(
                    top: false,
                    child: Container(
                      padding: EdgeInsets.only(
                        left: 20.w,
                        right: 20.w,
                        top: 16.h,
                        bottom: 20.h,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 10,
                            offset: const Offset(0, -5),
                          ),
                        ],
                      ),
                      child: SizedBox(
                        height: 40.h,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00ABE4),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.r),
                            ),
                          ),
                          onPressed: () {
                            if (!_isLocationConfirmed) {
                              if (_searchController.text.trim().isEmpty) {
                                AppUtils.showSnackBar(
                                  context,
                                  'Please enter or select a drop location first',
                                  isError: true,
                                );
                                return;
                              }
                              setState(() {
                                _isLocationConfirmed = true;
                              });
                            } else {
                              if (!_formKey.currentState!.validate()) {
                                AppUtils.showSnackBar(
                                  context,
                                  'Please fill all required fields',
                                  isError: true,
                                );
                                return;
                              }
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ChooseParcelScreen(
                                    pickupAddress: widget.pickupAddress ?? 'Sector 62, Noida',
                                    pickupContactName: widget.pickupContactName ?? 'Anuj Kumar',
                                    pickupContactPhone: widget.pickupContactPhone ?? '9090909090',
                                    goodsType: widget.goodsType ?? 'Furniture',
                                    helperRequired: widget.helperRequired ?? 'No',
                                    dropAddress: _searchController.text.trim(),
                                    dropContactName: _receiverNameController.text.trim(),
                                    dropContactPhone: _receiverMobileController.text.trim(),
                                  ),
                                ),
                              );
                            }
                          },
                          child: Text(
                            _isLocationConfirmed ? 'Confirm Receiver Details' : 'Confirm Drop Location',
                            textAlign: TextAlign.center,
                            style: AppFonts.buttonText.copyWith(
                              color: Colors.white,
                              fontSize: 13.sp,
                              fontWeight: FontWeight.w600,
                              height: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
            ],
          );
        },
      ),
    ),
    );
  }

  Widget _buildAddressTile(Map<String, dynamic> address) {
    return InkWell(
      onTap: () {
        final addrText = address['subtitle'] ?? address['title'] ?? '';
        setState(() {
          _searchController.text = addrText;
          _isLocationConfirmed = true;
        });
      },
      child: Column(
        children: [
          ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 23, sigmaY: 23),
            child: Container(
              height: 50.h,
              padding: EdgeInsets.only(top: 10.h, bottom: 10.h, right: 5.w),
              child: Row(
                children: [
                  Container(
                    width: 30.w,
                    height: 30.w,
                    decoration: BoxDecoration(
                      color: address['color'],
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(
                        address['icon'],
                        color: address['iconColor'],
                        size: 16.sp,
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          address['title'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppFonts.h2.copyWith(
                            fontSize: 14.sp,
                            color: Colors.black,
                            height: 1.0,
                          ),
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          address['subtitle'],
                          style: AppFonts.captionDark.copyWith(
                            color: Colors.grey.shade600,
                            fontSize: 11.sp,
                            height: 1.0,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.more_vert, color: Colors.grey),
                    onPressed: () {},
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(vertical: 12.h),
          child: Divider(color: Colors.grey.shade100, height: 1, thickness: 1),
        ),
      ],
    ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    required Widget prefixIcon,
    TextInputType keyboardType = TextInputType.text,
    TextCapitalization textCapitalization = TextCapitalization.none,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
  }) {
    return FormField<String>(
      initialValue: controller.text,
      validator: validator,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      builder: (field) {
        final hasError = field.hasError;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 50.h,
              decoration: BoxDecoration(
                color: AppColors.textFieldBackground,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: hasError
                      ? Colors.redAccent
                      : AppColors.authButtonBorder,
                  width: 1.w,
                ),
              ),
              child: Row(
                children: [
                  SizedBox(width: 12.w),
                  prefixIcon,
                  SizedBox(width: 12.w),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      keyboardType: keyboardType,
                      textCapitalization: textCapitalization,
                      onChanged: field.didChange,
                      inputFormatters: inputFormatters ?? (keyboardType == TextInputType.phone
                          ? [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(10),
                            ]
                          : null),
                      style: AppFonts.bodyText.copyWith(
                        color: Colors.black,
                        fontWeight: FontWeight.w700,
                      ),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: hintText,
                        hintStyle: AppFonts.bodyText.copyWith(
                          color: Colors.grey.shade400,
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 14.h),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (hasError) ...[
              SizedBox(height: 4.h),
              Padding(
                padding: EdgeInsets.only(left: 4.w),
                child: Text(
                  field.errorText ?? '',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 10.sp,
                    height: 1.2,
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}
