import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import 'rate_ride_screen.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedPaymentMethod = 'Cash';

  final List<Map<String, dynamic>> _paymentMethods = [
    {
      'id': 'Cash',
      'title': 'Cash',
      'subtitle': 'Pay in cash to driver',
      'icon': Icons.money,
      'color': const Color(0xFF00ABE4),
    },
    {
      'id': 'Wallet',
      'title': 'Wallet',
      'subtitle': 'Available Balance: ₹254.00',
      'icon': Icons.account_balance_wallet,
      'color': Colors.blue.shade700,
    },
    {
      'id': 'UPI',
      'title': 'UPI',
      'subtitle': 'Pay using any UPI app',
      'icon': Icons.mobile_screen_share,
      'color': Colors.purple.shade300,
    },
    {
      'id': 'Card',
      'title': 'Debit / Credit Card',
      'subtitle': 'Visa, MasterCard, Rupay',
      'icon': Icons.credit_card,
      'color': Colors.deepPurple.shade300,
    },
    {
      'id': 'NetBanking',
      'title': 'Net Banking',
      'subtitle': 'Pay using your bank',
      'icon': Icons.account_balance,
      'color': Colors.orange.shade300,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // Header Area with light blue background
          Container(
            color: AppColors.lightBlueBackground,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20.h,
              bottom: 20.h,
              left: 20.w,
              right: 20.w,
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 20.r,
                    child: const Icon(Icons.arrow_back, color: Colors.black),
                  ),
                ),
                SizedBox(width: 16.w),
                Text(
                  'Payment',
                  style: AppFonts.h1.copyWith(
                    fontSize: 20.sp,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),

          // Main White Container
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
              ),
              child: Stack(
                children: [
                  SingleChildScrollView(
                    padding: EdgeInsets.only(
                      top: 24.h,
                      left: 20.w,
                      right: 20.w,
                      bottom: 200.h,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Ride Completed Box
                        Container(
                          padding: EdgeInsets.only(
                            top: 10.h,
                            right: 14.w,
                            bottom: 10.h,
                            left: 10.w,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: const Color(0xFFF0F0F0),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(15.r),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.green,
                                radius: 14.r,
                                child: Icon(
                                  Icons.check,
                                  color: Colors.white,
                                  size: 18.sp,
                                ),
                              ),
                              SizedBox(width: 10.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Ride Completed',
                                      style: AppFonts.bodyText.copyWith(
                                        color: Colors.green.shade700,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(height: 4.h),
                                    Text(
                                      'B-52 Business Park, Sector 62\n→ Sector 62 Metro Station, Noida',
                                      style: AppFonts.captionDark.copyWith(
                                        color: Colors.grey.shade700,
                                        height: 1.4,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    'Total Fare',
                                    style: AppFonts.captionDark.copyWith(
                                      color: Colors.grey.shade500,
                                    ),
                                  ),
                                  Text(
                                    '₹425.00',
                                    style: AppFonts.h2.copyWith(
                                      fontSize: 16.sp,
                                      color: Colors.black,
                                    ),
                                  ),
                                  SizedBox(height: 8.h),
                                  Text(
                                    'View Details',
                                    style: AppFonts.captionDark.copyWith(
                                      color: const Color(0xFF00ABE4),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 24.h),

                        // Payment Methods
                        Text(
                          'Choose Payment Method',
                          style: AppFonts.bodyText.copyWith(
                            color: Colors.black,
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 16.h),

                        ..._paymentMethods
                            .map((method) => _buildPaymentOption(method))
                            .toList(),

                        SizedBox(height: 24.h),

                        // Secured Banner
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(
                            top: 14.h,
                            right: 12.w,
                            bottom: 14.h,
                            left: 12.w,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F8F3),
                            border: Border.all(
                              color: const Color(0xFFE3F6FC),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(4.r),
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.green.shade100
                                    .withOpacity(0.5),
                                radius: 14.r,
                                child: Icon(
                                  Icons.verified,
                                  color: Colors.green,
                                  size: 18.sp,
                                ),
                              ),
                              SizedBox(width: 8.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Your payment is secured with 256-bit encryption',
                                      style: AppFonts.bodyText.copyWith(
                                        color: Colors.green.shade700,
                                        fontSize: 13.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    Text(
                                      'We never store your card or UPI details',
                                      style: AppFonts.captionDark.copyWith(
                                        color: Colors.grey.shade500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Fixed Bottom Bar
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).padding.bottom > 0
                            ? MediaQuery.of(context).padding.bottom
                            : 20.h,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 17,
                            offset: const Offset(0, -13),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: EdgeInsets.only(
                              top: 14.h,
                              right: 22.w,
                              bottom: 14.h,
                              left: 14.w,
                            ),
                            decoration: const BoxDecoration(
                              color: Color(0xFFF7FDFF),
                              border: Border(
                                top: BorderSide(
                                  color: Color(0xFFE3F6FC),
                                  width: 1,
                                ),
                                bottom: BorderSide(
                                  color: Color(0xFFE3F6FC),
                                  width: 1,
                                ),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Total Payable',
                                      style: AppFonts.captionDark.copyWith(
                                        color: Colors.grey.shade500,
                                      ),
                                    ),
                                    Text(
                                      '₹425.00',
                                      style: AppFonts.h1.copyWith(
                                        fontSize: 18.sp,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.local_offer_outlined,
                                      color: const Color(0xFF00ABE4),
                                      size: 16.sp,
                                    ),
                                    SizedBox(width: 4.w),
                                    Text(
                                      'Apply Coupon',
                                      style: AppFonts.bodyText.copyWith(
                                        color: const Color(0xFF00ABE4),
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 16.h),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            child: SizedBox(
                              width: double.infinity,
                              height: 40.h,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.only(
                                    top: 12.h,
                                    right: 10.w,
                                    bottom: 12.h,
                                    left: 10.w,
                                  ),
                                  backgroundColor: const Color(0xFF00ABE4),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.r),
                                  ),
                                  elevation: 0,
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const RateRideScreen(),
                                    ),
                                  );
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.lock_outline,
                                      color: Colors.white,
                                      size: 18.sp,
                                    ),
                                    SizedBox(width: 8.w),
                                    Text('Pay Now', style: AppFonts.buttonText),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentOption(Map<String, dynamic> method) {
    bool isSelected = _selectedPaymentMethod == method['id'];

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedPaymentMethod = method['id'];
        });
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 12.h),
        padding: EdgeInsets.only(
          top: 10.h,
          right: 19.w,
          bottom: 10.h,
          left: 10.w,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: isSelected ? const Color(0xFF00ABE4) : Colors.grey.shade200,
            width: 1,
          ),
          borderRadius: BorderRadius.circular(15.r),
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: isSelected
                  ? const Color(0xFFE6F7FD)
                  : Colors.grey.shade50,
              radius: 18.r,
              child: Icon(method['icon'], color: method['color'], size: 18.sp),
            ),
            SizedBox(width: 10.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    method['title'],
                    style: AppFonts.bodyText.copyWith(
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    method['subtitle'],
                    style: AppFonts.captionDark.copyWith(
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 10.w),
            Icon(
              isSelected
                  ? Icons.radio_button_checked
                  : Icons.radio_button_unchecked,
              color: isSelected
                  ? const Color(0xFF00ABE4)
                  : Colors.grey.shade300,
              size: 24.sp,
            ),
          ],
        ),
      ),
    );
  }
}
