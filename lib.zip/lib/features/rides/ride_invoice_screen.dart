import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../constants/app_assets.dart';
import 'rate_ride_screen.dart';
import '../home/home_screen.dart';

class RideInvoiceScreen extends StatelessWidget {
  const RideInvoiceScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCompletedStatusBanner(),
                  SizedBox(height: 20.h),
                  _buildTripDetailsCard(),
                  SizedBox(height: 16.h),
                  _buildStatsRow(),
                  SizedBox(height: 20.h),
                  _buildDriverVehicleDetailsCard(),
                  SizedBox(height: 20.h),
                  _buildFareBreakdownCard(),
                  SizedBox(height: 20.h),
                  _buildPaymentDetailsCard(),
                  SizedBox(height: 20.h),
                  _buildSystemGeneratedNotice(),
                  SizedBox(height: 24.h),
                ],
              ),
            ),
          ),
          _buildBottomActionButtons(context),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 16.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                Icons.arrow_back_rounded,
                size: 18.sp,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Ride Invoice',
                  style: AppFonts.h2.copyWith(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  'Invoice ID: INV-LR125497863',
                  style: AppFonts.captionDark.copyWith(
                    fontSize: 12.sp,
                    color: Colors.grey.shade500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompletedStatusBanner() {
    return Container(
      height: 58.h,
      padding: EdgeInsets.only(
        top: 10.h,
        right: 14.w,
        bottom: 10.h,
        left: 10.w,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15.r),
        border: Border.all(color: const Color(0xFF14A03F).withOpacity(0.25), width: 1.w),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 24.w,
            height: 24.w,
            decoration: const BoxDecoration(
              color: Color(0xFF14A03F),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.check,
              color: Colors.white,
              size: 14.sp,
            ),
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Ride Completed',
                  style: AppFonts.bodyText.copyWith(
                    color: const Color(0xFF14A03F),
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5.sp,
                    height: 1.15,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Thanks for riding with us',
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: 10.5.sp,
                    height: 1.15,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '12 jun 2026, 11:42 AM',
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: 10.5.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTripDetailsCard() {
    return Container(
      height: 201.h,
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.25), width: 1.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Trip Details',
                style: AppFonts.bodyText.copyWith(
                  color: const Color(0xFF1A1A1A),
                  fontWeight: FontWeight.w800,
                  fontSize: 14.sp,
                ),
              ),
              Text(
                'Ride ID: LR125497863',
                style: AppFonts.captionDark.copyWith(
                  color: Colors.grey.shade500,
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  flex: 11,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(
                        width: 20.w,
                        child: Column(
                          children: [
                            SizedBox(height: 30.h),
                            Container(
                              width: 16.w,
                              height: 16.w,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF14A03F).withOpacity(0.2),
                                border: Border.all(color: const Color(0xFF14A03F), width: 1.5.w),
                              ),
                              child: Center(
                                child: Container(
                                  width: 6.w,
                                  height: 6.w,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF14A03F),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: 1.5.w,
                              height: 65.h,
                              color: Colors.grey.shade300,
                            ),
                            Icon(
                              Icons.location_on_rounded,
                              color: const Color(0xFF9E1000),
                              size: 18.sp,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 6.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildAddressCard(
                              title: 'Pick-up Location',
                              address: 'BSI Business Park H161 Noida Sector 63',
                              time: '8:55 AM',
                            ),
                            SizedBox(height: 8.h),
                            Expanded(
                              child: _buildAddressCard(
                                title: 'Your Destination',
                                address: 'A-3, District Centre, Saket, New Delhi, 110017',
                                time: '9:15 AM',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 10.w),
                Expanded(
                  flex: 8,
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0F6FC),
                      borderRadius: BorderRadius.circular(10.r),
                      border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2), width: 1.w),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10.r),
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: CustomPaint(
                              painter: MockMapPainter(),
                            ),
                          ),
                          Positioned(
                            bottom: 20.h,
                            left: 15.w,
                            child: Container(
                              width: 18.w,
                              height: 18.w,
                              decoration: const BoxDecoration(
                                color: Color(0xFF00ABE4),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.near_me_rounded,
                                color: Colors.white,
                                size: 10.sp,
                              ),
                            ),
                          ),
                          Positioned(
                            top: 20.h,
                            right: 20.w,
                            child: Icon(
                              Icons.location_on_rounded,
                              color: const Color(0xFF00ABE4),
                              size: 20.sp,
                            ),
                          ),
                          Positioned(
                            top: 55.h,
                            right: 32.w,
                            child: Transform.rotate(
                              angle: -0.6,
                              child: Image.asset(
                                AppAssets.carImage,
                                width: 28.w,
                                height: 16.h,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddressCard({
    required String title,
    required String address,
    required String time,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.18), width: 1.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: 9.5.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            address,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.bodyText.copyWith(
              color: const Color(0xFF1A1A1A),
              fontSize: 10.5.sp,
              fontWeight: FontWeight.bold,
              height: 1.15,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            time,
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: 9.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Container(
      height: 61.h,
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FDFF),
        borderRadius: BorderRadius.circular(4.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.25), width: 1.w),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildStatItemInline(
            icon: Icons.access_time_filled_rounded,
            iconColor: const Color(0xFF0284C7),
            bgColor: const Color(0xFFE0F2FE),
            label: 'Time Left',
            value: '15 min',
          ),
          _buildStatItemInline(
            icon: Icons.route_rounded,
            iconColor: const Color(0xFF16A34A),
            bgColor: const Color(0xFFDCFCE7),
            label: 'Distance Left',
            value: '12.5 km',
          ),
          _buildStatItemInline(
            icon: Icons.more_time_rounded,
            iconColor: const Color(0xFF7C3AED),
            bgColor: const Color(0xFFF3E8FF),
            label: 'ETA',
            value: '9:15 AM',
          ),
        ],
      ),
    );
  }

  Widget _buildStatItemInline({
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required String label,
    required String value,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 24.w,
          height: 24.w,
          decoration: BoxDecoration(
            color: bgColor,
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: iconColor, size: 12.sp),
        ),
        SizedBox(width: 6.w),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              style: AppFonts.captionDark.copyWith(
                color: Colors.grey.shade500,
                fontSize: 9.5.sp,
                fontWeight: FontWeight.w600,
                height: 1.1,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              value,
              style: AppFonts.bodyText.copyWith(
                color: const Color(0xFF212529),
                fontSize: 11.sp,
                fontWeight: FontWeight.bold,
                height: 1.1,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDriverVehicleDetailsCard() {
    return Container(
      padding: EdgeInsets.only(
        top: 10.h,
        right: 14.w,
        bottom: 10.h,
        left: 10.w,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.25), width: 1.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Driver & Vehicle Details',
            style: AppFonts.bodyText.copyWith(
              color: const Color(0xFF1A1A1A),
              fontWeight: FontWeight.w800,
              fontSize: 13.sp,
            ),
          ),
          SizedBox(height: 8.h),
          Row(
            children: [
               Container(
                width: 55.w,
                height: 55.h,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      const Color(0xFF00ABE4).withOpacity(0.10),
                      const Color(0xFF00ABE4).withOpacity(0.00),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(6.65.r),
                  border: Border.all(
                    color: const Color(0xFF00ABE4).withOpacity(0.20),
                    width: 0.46.w,
                  ),
                ),
                child: Center(
                  child: ClipOval(
                    child: Image.asset(
                      AppAssets.profileImage,
                      width: 44.w,
                      height: 44.h,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Raj Kumar',
                          style: AppFonts.bodyText.copyWith(
                            color: const Color(0xFF1A1A1A),
                            fontSize: 14.5.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 8.w),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 1.5.h),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFFBEB),
                            borderRadius: BorderRadius.circular(6.r),
                            border: Border.all(color: const Color(0xFFFEF3C7), width: 0.8.w),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.star_rounded, color: const Color(0xFFF59E0B), size: 10.sp),
                              SizedBox(width: 1.w),
                              Text(
                                '3.8',
                                style: AppFonts.bodyText.copyWith(
                                  color: const Color(0xFFB45309),
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      '1250 Trips',
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade500,
                        fontSize: 10.5.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'DL 01 AB 123',
                      style: AppFonts.bodyText.copyWith(
                        color: const Color(0xFF1A1A1A),
                        fontSize: 10.5.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'SUV White',
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade500,
                        fontSize: 10.5.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Image.asset(
                AppAssets.carImage,
                width: 85.w,
                height: 86.h,
                fit: BoxFit.contain,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFareBreakdownCard() {
    return Container(
      padding: EdgeInsets.only(
        top: 10.h,
        right: 16.w,
        bottom: 10.h,
        left: 16.w,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15.r),
        border: Border.all(color: const Color(0xFF14A03F).withOpacity(0.25), width: 1.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Fare Breakdown',
            style: AppFonts.bodyText.copyWith(
              color: const Color(0xFF1A1A1A),
              fontWeight: FontWeight.w800,
              fontSize: 13.sp,
            ),
          ),
          SizedBox(height: 10.h),
          _buildFareRow('Base Fare', '₹60.00'),
          _buildFareRow('Distance Fare (12.5 km)', '₹55.00'),
          _buildFareRow('Time Fare (45 min)', '₹18.00'),
          _buildFareRow('Taxes & Fees', '₹13.00'),
          _buildFareRow('Discount (WELCOME20)', '-₹20.00', isDiscount: true),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.h),
            child: Row(
              children: List.generate(40, (index) {
                return Expanded(
                  child: Container(
                    height: 1.h,
                    color: index % 2 == 0 ? Colors.transparent : const Color(0xFFE2E8F0),
                  ),
                );
              }),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Paid',
                style: AppFonts.bodyText.copyWith(
                  color: const Color(0xFF1A1A1A),
                  fontWeight: FontWeight.w800,
                  fontSize: 13.sp,
                ),
              ),
              Text(
                '₹147.00',
                style: AppFonts.bodyText.copyWith(
                  color: const Color(0xFF1A1A1A),
                  fontWeight: FontWeight.w900,
                  fontSize: 14.sp,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFareRow(String label, String value, {bool isDiscount = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: isDiscount
                ? AppFonts.bodyText.copyWith(
                    color: const Color(0xFF14A03F),
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w700,
                  )
                : AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w600,
                  ),
          ),
          Text(
            value,
            style: AppFonts.bodyText.copyWith(
              color: isDiscount ? const Color(0xFF14A03F) : const Color(0xFF1A1A1A),
              fontSize: 11.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentDetailsCard() {
    return Container(
      padding: EdgeInsets.only(
        top: 10.h,
        right: 16.w,
        bottom: 10.h,
        left: 16.w,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15.r),
        border: Border.all(color: const Color(0xFF14A03F).withOpacity(0.25), width: 1.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Payment Details',
            style: AppFonts.bodyText.copyWith(
              color: const Color(0xFF1A1A1A),
              fontWeight: FontWeight.w800,
              fontSize: 13.sp,
            ),
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Paid by Cash',
                    style: AppFonts.bodyText.copyWith(
                      color: const Color(0xFF1A1A1A),
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    '12 Jun 2026, 11:42 AM',
                    style: AppFonts.captionDark.copyWith(
                      color: Colors.grey.shade500,
                      fontSize: 10.5.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: const Color(0xFF14A03F).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(color: const Color(0xFF14A03F).withOpacity(0.3), width: 0.8.w),
                    ),
                    child: Text(
                      'Paid',
                      style: AppFonts.bodyText.copyWith(
                        color: const Color(0xFF14A03F),
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w800,
                        height: 1.1,
                      ),
                    ),
                  ),
                  SizedBox(height: 3.h),
                  Text(
                    '₹147.00',
                    style: AppFonts.bodyText.copyWith(
                      color: const Color(0xFF1A1A1A),
                      fontSize: 13.5.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSystemGeneratedNotice() {
    return Container(
      height: 59.h,
      padding: EdgeInsets.only(
        top: 14.h,
        right: 12.w,
        bottom: 14.h,
        left: 12.w,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F7FC),
        borderRadius: BorderRadius.circular(4.r),
        border: Border.all(color: const Color(0xFFE3F6FC), width: 1.w),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 24.w,
            height: 24.w,
            decoration: const BoxDecoration(
              color: Color(0xFFD0ECF7),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                Icons.verified_rounded,
                color: const Color(0xFF00ABE4),
                size: 14.sp,
              ),
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'This is a system generated invoice.',
                  style: AppFonts.bodyText.copyWith(
                    color: const Color(0xFF1A1A1A),
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    height: 1.1,
                  ),
                ),
                SizedBox(height: 2.h),
                RichText(
                  text: TextSpan(
                    style: AppFonts.captionDark.copyWith(
                      fontSize: 10.sp,
                      color: Colors.grey.shade500,
                      height: 1.1,
                    ),
                    children: [
                      const TextSpan(text: 'for any queries, visit '),
                      TextSpan(
                        text: 'Help & Support.',
                        style: AppFonts.bodyText.copyWith(
                          fontSize: 10.sp,
                          color: const Color(0xFF00ABE4),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomActionButtons(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
        left: 20.w,
        right: 20.w,
        top: 14.h,
        bottom: MediaQuery.of(context).padding.bottom > 0
            ? MediaQuery.of(context).padding.bottom + 10.h
            : 16.h,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            height: 48.h,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00ABE4),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.r),
                ),
              ),
              onPressed: () {
                // TODO: Implement PDF download
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.file_download_outlined, size: 18.sp),
                  SizedBox(width: 6.w),
                  Text(
                    'Download PDF',
                    style: AppFonts.buttonText.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 12.h),
          GestureDetector(
            onTap: () {
              // Share Invoice action
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.share_outlined, color: Colors.grey.shade500, size: 14.sp),
                SizedBox(width: 4.w),
                Text(
                  'Share Invoice',
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontWeight: FontWeight.w700,
                    fontSize: 12.sp,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16.h),
          SizedBox(
            width: double.infinity,
            height: 40.h,
            child: TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HomeScreen(),
                  ),
                  (route) => false,
                );
              },
              child: Text(
                'Back to Home',
                style: AppFonts.bodyText.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class MockMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Draw background
    final bgPaint = Paint()
      ..color = const Color(0xFFF1F5F9)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        Radius.circular(8.r),
      ),
      bgPaint,
    );

    // Draw stylized road path
    final roadPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6.w
      ..strokeCap = StrokeCap.round;

    final roadPath1 = Path()
      ..moveTo(0, size.height * 0.35)
      ..quadraticBezierTo(size.width * 0.4, size.height * 0.15, size.width * 0.65, size.height * 0.5)
      ..lineTo(size.width, size.height * 0.75);

    final roadPath2 = Path()
      ..moveTo(size.width * 0.25, 0)
      ..quadraticBezierTo(size.width * 0.35, size.height * 0.55, size.width * 0.75, size.height);

    canvas.drawPath(roadPath1, roadPaint);
    canvas.drawPath(roadPath2, roadPaint);

    // Draw route path (blue line)
    final routePaint = Paint()
      ..color = const Color(0xFF00ABE4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5.w
      ..strokeCap = StrokeCap.round;

    final routePath = Path()
      ..moveTo(size.width * 0.25, size.height * 0.8)
      ..cubicTo(
        size.width * 0.45, size.height * 0.7,
        size.width * 0.55, size.height * 0.4,
        size.width * 0.75, size.height * 0.25,
      );

    canvas.drawPath(routePath, routePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class HorizontalDashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF38B6FF).withOpacity(0.4)
      ..strokeWidth = 1.w
      ..style = PaintingStyle.stroke;

    const double dashWidth = 3;
    const double dashSpace = 3;
    double startX = 0;
    double endX = size.width;

    while (startX < endX) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
