import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import '../../core/utils.dart';
import 'otp_screen.dart';

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  bool _termsAccepted = false;
  bool _isLoading = false;
  final TextEditingController _phoneController = TextEditingController();

  Future<void> _sendOtp() async {
    final phone = _phoneController.text.trim();
    if (phone.isEmpty) {
      AppUtils.showSnackBar(context, 'Please enter a phone number', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final formattedPhone = phone.startsWith('+') ? phone : '+91$phone';

    try {
      final response = await ApiService.to.post(
        ApiEndpoints.sendOtp,
        body: {
          "identifier": formattedPhone,
          "type": "PHONE"
        },
      );
      
      AppUtils.printLog('Send OTP Response: ${response.data}');

      if (mounted) {
        AppUtils.showSnackBar(context, 'OTP sent successfully');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OtpScreen(phoneNumber: formattedPhone),
          ),
        );
      }
    } catch (e) {
      AppUtils.printLog('Send OTP Error: $e');
      if (mounted) {
        AppUtils.showSnackBar(context, e.toString(), isError: true);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () =>
          FocusScope.of(context).unfocus(), // Hides keyboard on tap outside
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.h),
                // Back Button
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40.w,
                    height: 40.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.authButtonBorder),
                      color: AppColors.white,
                    ),
                    child: Icon(
                      Icons.arrow_back,
                      size: 20.sp,
                      color: AppColors.black,
                    ),
                  ),
                ),
                SizedBox(height: 30.h),

                // Titles
                Text(
                  'Join us Via Phone Number',
                  style: AppFonts.h1.copyWith(
                    fontSize: 24.sp,
                    color: AppColors.black,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "We'll text a code to verify your phone",
                  style: AppFonts.captionDark,
                ),
                SizedBox(height: 30.h),

                // Input Label
                Text(
                  'Phone Number',
                  style: AppFonts.h2.copyWith(
                    fontSize: 15.sp,
                    color: AppColors.black,
                  ),
                ),
                SizedBox(height: 10.h),

                // Input Row
                Row(
                  children: [
                    // Country Code
                    Container(
                      height: 50.h,
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      decoration: BoxDecoration(
                        color: AppColors.textFieldBackground,
                        border: Border.all(
                          color: AppColors.authButtonBorder,
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Row(
                        children: [
                          Text(
                            '+91',
                            style: AppFonts.bodyText.copyWith(
                              color: AppColors.black,
                            ),
                          ),
                          SizedBox(width: 4.w),
                          Icon(
                            Icons.keyboard_arrow_down,
                            size: 18.sp,
                            color: AppColors.black,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 12.w),
                    // Phone Number Field
                    Expanded(
                      child: CustomTextField(
                        controller: _phoneController,
                        hintText: 'Enter here',
                        keyboardType: TextInputType.phone,
                        prefixIcon: Icon(
                          Icons.phone_android_outlined,
                          size: 20.sp,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 30.h),
                // Terms
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 24.w,
                      height: 24.w,
                      child: Checkbox(
                        value: _termsAccepted,
                        activeColor: const Color(0xFF00A2E8),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                        onChanged: (value) {
                          setState(() => _termsAccepted = value ?? false);
                          if (_termsAccepted && _phoneController.text.trim().isNotEmpty) {
                            _sendOtp();
                          }
                        },
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: RichText(
                        text: TextSpan(
                          style: AppFonts.captionDark,
                          children: [
                            const TextSpan(
                              text: 'BY Continue, you agree to our ',
                            ),
                            TextSpan(
                              text: 'Terms of Use',
                              style: AppFonts.linkText,
                              recognizer: TapGestureRecognizer()..onTap = () {},
                            ),
                            const TextSpan(text: ' and \n'),
                            TextSpan(
                              text: 'Privacy Policy',
                              style: AppFonts.linkText,
                              recognizer: TapGestureRecognizer()..onTap = () {},
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const Spacer(),

                CustomButton(
                  text: _isLoading ? 'Sending...' : 'Continue',
                  color: const Color(
                    0xFF00A2E8,
                  ), // Match the bright blue color from image
                  onPressed: (_termsAccepted && !_isLoading) ? _sendOtp : null,
                ),
                SizedBox(height: 24.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
