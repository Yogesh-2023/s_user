import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../widgets/custom_button.dart';
import '../../services/profile_service.dart';
import '../main_navigation_screen.dart';
import '../../core/api/api_exception.dart';
import '../../core/utils.dart';

class PersonalInformationScreen extends StatefulWidget {
  const PersonalInformationScreen({super.key});

  @override
  State<PersonalInformationScreen> createState() => _PersonalInformationScreenState();
}

class _PersonalInformationScreenState extends State<PersonalInformationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _alternatePhoneController = TextEditingController();
  String _requirement = 'PERSONAL';
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _alternatePhoneController.dispose();
    super.dispose();
  }

  Future<void> _showImageSourceDialog() async {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 12.h),
              Container(
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
              SizedBox(height: 20.h),
              Text(
                'Select Profile Image',
                style: AppFonts.h2.copyWith(fontSize: 18.sp, color: AppColors.black),
              ),
              SizedBox(height: 20.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _SourceOption(
                    icon: Icons.camera_alt_rounded,
                    label: 'Camera',
                    onTap: () {
                      Navigator.pop(context);
                      _pickImage(ImageSource.camera);
                    },
                  ),
                  _SourceOption(
                    icon: Icons.photo_library_rounded,
                    label: 'Gallery',
                    onTap: () {
                      Navigator.pop(context);
                      _pickImage(ImageSource.gallery);
                    },
                  ),
                ],
              ),
              SizedBox(height: 24.h),
            ],
          ),
        );
      },
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
      }
    } catch (e) {
      AppUtils.showSnackBar(context, 'Failed to pick image', isError: true);
    }
  }

  void _submit() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      String fullName = _fullNameController.text.trim();
      List<String> nameParts = fullName.split(' ');
      String firstName = nameParts.first;
      String lastName = nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '';
      String email = _emailController.text.trim();

      final prefs = await SharedPreferences.getInstance();
      String primaryPhone = prefs.getString('user_phone') ?? '';

      final Map<String, String> fields = {
        'name': fullName,
        'email': email,
        'phone': primaryPhone,
        'firstname': firstName,
        'lastname': lastName,
        'requirement': _requirement,
      };

      try {
        final profileService = ProfileService();
        final profile = await profileService.createProfile(
          fields: fields,
          avatarPath: _profileImage?.path,
        );

        if (profile != null) {
          if (mounted) {
            AppUtils.showSnackBar(context, 'Profile created successfully');
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const MainNavigationScreen()),
              (route) => false,
            );
          }
        } else {
          if (mounted) {
            AppUtils.showSnackBar(context, 'Failed to save profile', isError: true);
          }
        }
      } catch (e) {
        if (mounted) {
          String errorMessage = e is ApiException ? e.message : e.toString().replaceAll('ApiException:', '').trim();
          AppUtils.showSnackBar(context, errorMessage, isError: true);
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  Widget _buildHeader(BuildContext context) {
    final canPop = Navigator.canPop(context);
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 20.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (canPop) ...[
                InkWell(
                  onTap: () => Navigator.pop(context),
                  borderRadius: BorderRadius.circular(20.r),
                  child: Container(
                    width: 40.w,
                    height: 40.w,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: const Icon(Icons.arrow_back, size: 20, color: Colors.black),
                  ),
                ),
                SizedBox(width: 16.w),
              ],
              Expanded(
                child: Text(
                  'Personal Information',
                  style: AppFonts.h1.copyWith(
                    fontSize: 22.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Padding(
            padding: EdgeInsets.only(left: canPop ? 56.w : 0),
            child: Text(
              'Please fill in your details to continue.',
              style: AppFonts.bodyText.copyWith(color: Colors.black87, fontSize: 13.sp),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormTextField({
    required TextEditingController controller,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      style: AppFonts.bodyText.copyWith(
        fontSize: 13.sp,
        color: AppColors.textPrimary,
        fontWeight: FontWeight.w600,
      ),
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      textCapitalization: textCapitalization,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: AppFonts.bodyText.copyWith(fontSize: 13.sp, color: const Color(0x66000000)),
        filled: true,
        fillColor: const Color(0xFF333333).withOpacity(0.03),
        contentPadding: EdgeInsets.only(top: 10.h, bottom: 10.h, left: 14.w, right: 10.w),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.r),
          borderSide: BorderSide(color: const Color(0xFFD7D7D7), width: 1.w),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.r),
          borderSide: BorderSide(color: const Color(0xFFD7D7D7), width: 1.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.r),
          borderSide: const BorderSide(color: Color(0xFF00ABE4), width: 1),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.r),
          borderSide: BorderSide(color: AppColors.error, width: 1.w),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.r),
          borderSide: BorderSide(color: AppColors.error, width: 1.w),
        ),
      ),
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          children: [
            _buildHeader(context),
            Expanded(
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20.h),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  child: GestureDetector(
                                    onTap: _showImageSourceDialog,
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: 100.w,
                                          height: 100.w,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.grey[100],
                                            border: Border.all(color: const Color(0xFF00ABE4), width: 2),
                                            image: _profileImage != null
                                                ? DecorationImage(
                                                    image: FileImage(_profileImage!),
                                                    fit: BoxFit.cover,
                                                  )
                                                : null,
                                          ),
                                          child: _profileImage == null
                                              ? const Icon(
                                                  Icons.person,
                                                  size: 50,
                                                  color: Colors.grey,
                                                )
                                              : null,
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          right: 0,
                                          child: Container(
                                            padding: EdgeInsets.all(6.w),
                                            decoration: const BoxDecoration(
                                              color: Color(0xFF00ABE4),
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                              Icons.camera_alt,
                                              size: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(height: 24.h),
                                Text('Full Name', style: AppFonts.bodyText.copyWith(fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                                SizedBox(height: 8.h),
                                _buildFormTextField(
                                  controller: _fullNameController,
                                  hint: 'Enter your full name',
                                  textCapitalization: TextCapitalization.words,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                                  ],
                                  validator: (value) {
                                    if (value == null || value.trim().isEmpty) {
                                      return 'Please enter full name';
                                    }
                                    if (value.trim().length < 4) {
                                      return 'Name must be at least 4 characters';
                                    }
                                    return null;
                                  },
                                ),
                                SizedBox(height: 20.h),
                                Text('Email Address', style: AppFonts.bodyText.copyWith(fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                                SizedBox(height: 8.h),
                                _buildFormTextField(
                                  controller: _emailController,
                                  hint: 'Enter your email',
                                  keyboardType: TextInputType.emailAddress,
                                  validator: (value) {
                                    if (value == null || value.trim().isEmpty) {
                                      return 'Please enter your email';
                                    }
                                    // Basic email validation regex matching GetUtils.isEmail
                                    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
                                    if (!emailRegex.hasMatch(value.trim())) {
                                      return 'Please enter a valid email';
                                    }
                                    return null;
                                  },
                                ),
                                SizedBox(height: 20.h),
                                Text('Alternate Phone Number', style: AppFonts.bodyText.copyWith(fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                                SizedBox(height: 8.h),
                                _buildFormTextField(
                                  controller: _alternatePhoneController,
                                  hint: 'Enter alternate phone number',
                                  keyboardType: TextInputType.phone,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(10),
                                  ],
                                  validator: (value) {
                                    if (value == null || value.trim().isEmpty) {
                                      return null; // Optional
                                    }
                                    if (value.trim().length != 10) {
                                      return 'Please enter valid 10 digit number';
                                    }
                                    return null;
                                  },
                                ),
                                SizedBox(height: 20.h),
                                // Requirement Dropdown
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Requirement Type',
                                      style: AppFonts.captionDark.copyWith(
                                        color: AppColors.textSecondary,
                                        fontSize: 12.sp,
                                      ),
                                    ),
                                    SizedBox(height: 6.h),
                                    DropdownButtonFormField<String>(
                                      value: _requirement,
                                      dropdownColor: Colors.white,
                                      iconEnabledColor: Colors.black,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      decoration: InputDecoration(
                                        filled: true,
                                        fillColor: const Color(0xFF333333).withOpacity(0.03),
                                        contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10.r),
                                          borderSide: const BorderSide(color: Color(0xFFD7D7D7)),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10.r),
                                          borderSide: const BorderSide(color: Color(0xFFD7D7D7)),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10.r),
                                          borderSide: const BorderSide(color: Color(0xFF00ABE4)),
                                        ),
                                      ),
                                      items: [
                                        DropdownMenuItem(
                                          value: 'PERSONAL',
                                          child: Text(
                                            'Personal',
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                        DropdownMenuItem(
                                          value: 'BUSINESS',
                                          child: Text(
                                            'Business',
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ],
                                      onChanged: (val) {
                                        if (val != null) {
                                          setState(() {
                                            _requirement = val;
                                          });
                                        }
                                      },
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20.h),
                              ],
                            ),
                          ),
                        ),
                        CustomButton(
                          text: _isLoading ? 'Saving...' : 'Continue',
                          color: const Color(0xFF00ABE4),
                          onPressed: _isLoading ? null : _submit,
                        ),
                        SizedBox(height: 24.h),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SourceOption extends StatelessWidget {
  const _SourceOption({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12.r),
      child: Container(
        width: 100.w,
        padding: EdgeInsets.symmetric(vertical: 16.h),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE7ECF1)),
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Column(
          children: [
            Icon(icon, size: 32, color: const Color(0xFF00ABE4)),
            SizedBox(height: 8.h),
            Text(label, style: AppFonts.bodyText.copyWith(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
