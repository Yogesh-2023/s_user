import 'dart:io' show Platform;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../widgets/gradient_scaffold.dart';
import '../../widgets/auth_button.dart';
import '../home/home_screen.dart';
import 'phone_login_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, String>> _onboardingData = [
    {
      'image': 'assets/images/on1.png',
      'title': 'Book Comfortable Rides\nAnytime, Anywhere',
    },
    {
      'image': 'assets/images/on2.png',
      'title': 'Send Parcels Quickly With\nLive Tracking',
    },
    {
      'image': 'assets/images/on3.png',
      'title': 'Transport Heavy Goods\nWithout Any Hassle',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GradientScaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 20.h),
            // Logo
            Image.asset(
              'assets/images/icon_logo.png',
              height: 38.h, // Adjusted to 38
              fit: BoxFit.contain,
            ),
            SizedBox(height: 20.h),
            // PageView for Images and Titles
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
                itemCount: _onboardingData.length,
                itemBuilder: (context, index) {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Image
                      Expanded(
                        child: Image.asset(
                          _onboardingData[index]['image']!,
                          fit: BoxFit.contain,
                        ),
                      ),
                      SizedBox(height: 30.h),
                      // Indicator
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          _onboardingData.length,
                          (idx) => buildDot(idx, context),
                        ),
                      ),
                      SizedBox(height: 30.h),
                      // Title
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 24.w),
                        child: Text(
                          _onboardingData[index]['title']!,
                          style: AppFonts.h1.copyWith(
                            color: AppColors.black,
                            fontSize: 26.sp,
                            height: 1.3,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      SizedBox(height: 20.h),
                    ],
                  );
                },
              ),
            ),
            // Bottom Buttons Section
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                children: [
                  AuthButton(
                    text: 'Continue with Phone',
                    icon: Icons.smartphone,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PhoneLoginScreen(),
                        ),
                      );
                    },
                    isFullWidth: true,
                  ),
                  SizedBox(height: 16.h),
                  if (Platform.isIOS)
                    Row(
                      children: [
                        Expanded(
                          child: AuthButton(
                            text: 'Google',
                            imageIcon: 'assets/icons/google.png',
                            onTap: () {},
                          ),
                        ),
                        SizedBox(width: 16.w),
                        Expanded(
                          child: AuthButton(
                            text: 'Apple',
                            icon: Icons.apple,
                            onTap: () {},
                          ),
                        ),
                      ],
                    )
                  else
                    AuthButton(
                      text: 'Continue with Google',
                      imageIcon: 'assets/icons/google.png',
                      onTap: () {},
                      isFullWidth: true,
                    ),
                  SizedBox(height: 32.h),
                  // Terms and conditions
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      style: AppFonts.captionDark,
                      children: [
                        const TextSpan(
                          text: 'By Clicking Sign in you agree to the ',
                        ),
                        TextSpan(
                          text: 'Privacy Policy',
                          style: AppFonts.linkText,
                          recognizer: TapGestureRecognizer()..onTap = () {},
                        ),
                        const TextSpan(text: ' & \n'),
                        TextSpan(
                          text: 'Terms of Condition',
                          style: AppFonts.linkText,
                          recognizer: TapGestureRecognizer()..onTap = () {},
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildDot(int index, BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      height: 6.h,
      width: _currentPage == index ? 20.w : 6.w,
      decoration: BoxDecoration(
        color: _currentPage == index
            ? const Color(0xFF00A2E8)
            : const Color(0xFFBBE5FA),
        borderRadius: BorderRadius.circular(4.r),
      ),
    );
  }
}
