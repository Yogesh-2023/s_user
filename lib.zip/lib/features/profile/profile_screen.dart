import 'package:dobelgodelivery/features/activity/activity_screen.dart';
import 'package:dobelgodelivery/features/support/help_support_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../models/user_profile.dart';
import '../../services/profile_service.dart';
import '../../core/socket/socket_service.dart';
import 'profile_edit_screen.dart';
import '../auth/onboarding_screen.dart';
import '../wallet/wallet_screen.dart';
import '../bookings/bookings_screen.dart';
import '../main_navigation_screen.dart';
import 'about_screen.dart';
import 'about_us_screen.dart';
import 'privacy_policy_screen.dart';
import 'terms_conditions_screen.dart';
import '../../core/utils.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ProfileService _service = ProfileService();
  UserProfile? _profile;
  bool _isLoading = true;

  String _displayPhone(String? phone) {
    if (phone == null || phone.isEmpty) return 'XXXXX XXXXX';
    String p = phone.trim();
    if (p.startsWith('+91')) {
      p = p.substring(3);
    } else if (p.startsWith('91') && p.length > 10) {
      p = p.substring(2);
    }
    return p;
  }

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final prof = await _service.getMyProfile();
      if (prof != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user_id', prof.userId);
        final token = prefs.getString('auth_token');
        if (token != null && token.isNotEmpty) {
          if (!SocketService.to.isConnected && !SocketService.to.isConnecting) {
            SocketService.to.initSocket(sessionToken: token, userId: prof.userId);
          }
        }
      }
      if (mounted) {
        setState(() {
          _profile = prof;
          _isLoading = false;
        });
      }
    } catch (e) {
      print("Error loading profile: $e");
      if (mounted) {
        setState(() {
          _profile = null;
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('user_id');
    SocketService.to.closeSocket();
    if (mounted) {
      AppUtils.showSnackBar(context, 'Logged out successfully');
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const OnboardingScreen()),
        (route) => false,
      );
    }
  }

  Future<void> _confirmLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.r),
          ),
          backgroundColor: Colors.white,
          contentPadding: EdgeInsets.all(24.w),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.all(16.w),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.logout,
                  color: Colors.red,
                  size: 32.sp,
                ),
              ),
              SizedBox(height: 20.h),
              Text(
                'Logout',
                style: AppFonts.h2.copyWith(
                  color: AppColors.textPrimary,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10.h),
              Text(
                'Are you sure you want to log out from your account?',
                textAlign: TextAlign.center,
                style: AppFonts.bodyText.copyWith(
                  color: AppColors.textSecondary,
                  fontSize: 14.sp,
                ),
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey.shade300),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                      ),
                      child: Text(
                        'Cancel',
                        style: AppFonts.bodyText.copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                      ),
                      child: Text(
                        'Logout',
                        style: AppFonts.bodyText.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );

    if (shouldLogout == true) {
      _logout();
    }
  }

  void _showSettingsMenu() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.h),
                child: Text(
                  'Settings',
                  style: AppFonts.h2.copyWith(fontSize: 18.sp),
                ),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: Text(
                  'Logout',
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _confirmLogout();
                },
              ),
              ListTile(
                leading: const Icon(Icons.close),
                title: Text('Cancel', style: AppFonts.bodyText),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _navigateToEdit() async {
    final result = await Navigator.push<UserProfile?>(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileEditScreen(profile: _profile),
      ),
    );
    if (result != null) {
      setState(() {
        _profile = result;
      });
    } else {
      // Reload profile from API to ensure we have fresh data
      setState(() {
        _isLoading = true;
      });
      _loadProfile();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasProfile = _profile != null;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: SafeArea(
        top: false,
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF00ABE4)),
              )
            : Column(
                children: [
                  _buildHeader(context),
                Expanded(
                  child: RefreshIndicator(
                    color: const Color(0xFF00ABE4),
                    onRefresh: _loadProfile,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Profile & Pro Member Combined Card
                    GestureDetector(
                      onTap: _navigateToEdit,
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20.r),
                          border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.25), width: 1.w),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.03),
                              blurRadius: 15,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Profile row info
                            Row(
                              children: [
                                CircleAvatar(
                                  radius: 35.r,
                                  backgroundColor: Colors.grey.shade200,
                                  backgroundImage:
                                      (hasProfile &&
                                          _profile!.avatar.isNotEmpty)
                                      ? NetworkImage(_profile!.avatar)
                                            as ImageProvider
                                      : const AssetImage(
                                          'assets/images/profile.png',
                                        ),
                                ),
                                SizedBox(width: 14.w),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Flexible(
                                            child: Text(
                                              (hasProfile && (_profile!.name.isNotEmpty || _profile!.firstname.isNotEmpty || _profile!.lastname.isNotEmpty))
                                                  ? (_profile!.name.isNotEmpty ? _profile!.name : '${_profile!.firstname} ${_profile!.lastname}'.trim())
                                                  : 'Guest User',
                                              style: AppFonts.h2.copyWith(
                                                fontSize: 18.sp,
                                                fontWeight: FontWeight.bold,
                                                color: AppColors.textPrimary,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          SizedBox(width: 4.w),
                                          if (hasProfile)
                                            Icon(
                                              Icons.verified,
                                              color: const Color(0xFF00ABE4),
                                              size: 16.sp,
                                            ),
                                        ],
                                      ),
                                      SizedBox(height: 3.h),
                                      Text(
                                        _displayPhone(hasProfile ? _profile!.phone : null),
                                        style: AppFonts.bodyText.copyWith(
                                          fontSize: 13.sp,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                      SizedBox(height: 2.h),
                                      Text(
                                        hasProfile
                                            ? _profile!.email
                                            : 'guest@example.com',
                                        style: AppFonts.bodyText.copyWith(
                                          fontSize: 13.sp,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.all(6.w),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE6F7FD),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
                                  ),
                                  child: Icon(
                                    Icons.edit_rounded,
                                    color: const Color(0xFF00ABE4),
                                    size: 16.sp,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 24.h),


                    _buildAccountSection(context),
                    _buildLogoutCard(),
                    _buildDeleteAccountCard(context),
                    SizedBox(height: 24.h),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 16.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context);
              } else {
                final mainNav = context.findAncestorStateOfType<MainNavigationScreenState>();
                if (mainNav != null) {
                  mainNav.setIndex(0);
                } else {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const MainNavigationScreen(initialIndex: 0)),
                    (route) => false,
                  );
                }
              }
            },
            child: Container(
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                Icons.arrow_back_rounded,
                size: 18.sp,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Text(
              'Profile',
              style: AppFonts.h1.copyWith(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMyBookingsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.zero,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'My Bookings',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const BookingsScreen()));
                },
                child: Text(
                  'View All Bookings',
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF00ABE4),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 8.h),
        Padding(
          padding: EdgeInsets.zero,
          child: Row(
            children: [
              _buildBookingCard(
                icon: Icons.directions_car_rounded,
                iconColor: const Color(0xFF00ABE4),
                iconBgColor: const Color(0xFFE6F7FD),
                title: 'Ride',
                subtitle: '12 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.inventory_2_outlined,
                iconColor: const Color(0xFF28A745),
                iconBgColor: const Color(0xFFEAF8EC),
                title: 'Parcel',
                subtitle: '8 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.local_shipping_rounded,
                iconColor: const Color(0xFFFD7E14),
                iconBgColor: const Color(0xFFFFF3CD),
                title: 'Truck',
                subtitle: '5 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.access_time_rounded,
                iconColor: const Color(0xFF6F42C1),
                iconBgColor: const Color(0xFFF1EAFF),
                title: 'Ongoing',
                subtitle: '2 Bookings',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildBookingCard({
    required IconData icon,
    required Color iconColor,
    required Color iconBgColor,
    required String title,
    required String subtitle,
  }) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w),
        padding: EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.01),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(color: iconColor.withOpacity(0.25), width: 1.w),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: iconBgColor,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: iconColor, size: 20.sp),
            ),
            SizedBox(height: 8.h),
            Text(
              title,
              style: TextStyle(
                fontFamily: AppFonts.fontFamily,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              subtitle,
              style: TextStyle(
                fontFamily: AppFonts.fontFamily,
                fontSize: 9.sp,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildProfileCard(
          icon: Icons.favorite_border_rounded,
          title: 'Activity',
          subtitle: 'View your recent activity',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const ActivityScreen(),
              ),
            );
          },
        ),
        _buildProfileCard(
          icon: Icons.help_outline_rounded,
          title: 'Help & Support',
          subtitle: 'Call or chat with support',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const HelpSupportScreen(),
              ),
            );
          },
        ),
        _buildProfileCard(
          icon: Icons.info_outline_rounded,
          title: 'About',
          subtitle: 'Privacy, Terms & About Us',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AboutScreen(),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildProfileCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color? textColor,
    Color? iconColor,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: const Color(0xFF00ABE4).withOpacity(0.2),
          width: 1.5.w,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16.r),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 16.h),
          child: Row(
            children: [
              Icon(
                icon,
                color: iconColor ?? const Color(0xFF00ABE4),
                size: 26.sp,
              ),
              SizedBox(width: 14.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppFonts.h2.copyWith(
                        fontSize: 16.5.sp,
                        color: textColor ?? AppColors.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w800,
                        color: textColor ?? const Color(0xFF94A3B8),
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: textColor ?? const Color(0xFF94A3B8),
                size: 26.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoutCard() {
    return _buildProfileCard(
      icon: Icons.logout,
      title: 'Logout',
      subtitle: 'Sign out from provider app',
      onTap: _confirmLogout,
    );
  }

  Widget _buildDeleteAccountCard(BuildContext context) {
    return _buildProfileCard(
      icon: Icons.delete_forever_outlined,
      title: 'Delete Account',
      subtitle: 'Permanently remove your data',
      textColor: Colors.red,
      iconColor: Colors.red,
      onTap: () => _confirmDeleteAccount(context),
    );
  }

  void _confirmDeleteAccount(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.r),
          ),
          backgroundColor: Colors.white,
          contentPadding: EdgeInsets.all(24.w),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.all(16.w),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.warning_amber_rounded,
                  color: Colors.red,
                  size: 32.sp,
                ),
              ),
              SizedBox(height: 20.h),
              Text(
                'Delete Account',
                style: AppFonts.h2.copyWith(
                  color: AppColors.textPrimary,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10.h),
              Text(
                'Are you sure you want to delete your account? This action cannot be undone.',
                textAlign: TextAlign.center,
                style: AppFonts.bodyText.copyWith(
                  color: AppColors.textSecondary,
                  fontSize: 14.sp,
                ),
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey.shade300),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                      ),
                      child: Text(
                        'Cancel',
                        style: AppFonts.bodyText.copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context); // Close the dialog
                        
                        // Show success pop up
                        AppUtils.showSnackBar(context, 'Your Request has been Submitted Successfully');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                      ),
                      child: Text(
                        'Delete',
                        style: AppFonts.bodyText.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
