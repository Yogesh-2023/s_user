import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/app_fonts.dart';
import '../../constants/app_colors.dart';

class AboutUsScreen extends StatelessWidget {
  const AboutUsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text('About Us')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 20.h),
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: .1),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.local_shipping, size: 50, color: AppColors.primary),
            ),
            SizedBox(height: 24.h),
            Text('Truck App', style: AppFonts.h1.copyWith(fontSize: 24.sp)),
            SizedBox(height: 8.h),
            Text('Version 1.0.0', style: AppFonts.bodyText),
            SizedBox(height: 30.h),
            Text(
              'We are committed to providing the best logistics and transportation services by empowering users with modern technology.\n\n'
              'Our platform connects you with seamless logistics operations, ensuring that you can find rides, send parcels, and book trucks all from one app.\n\n'
              'Thank you for being a part of our journey!',
              style: AppFonts.bodyText,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
