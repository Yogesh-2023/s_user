import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Column(
                children: [
                  _buildPolicyCard(
                    numberId: 'SEC 01',
                    title: '1. Introduction & Scope',
                    content: 'Your privacy is extremely important to us. We collect and process your data to provide a seamless ride-hailing experience, ensure safety on the road, match trips efficiently, and manage driver earnings transparently.',
                    bulletPoints: [
                      'Matches you with the nearest passengers based on active routes.',
                      'Ensures security and legal compliance for all platform users.',
                    ],
                  ),
                  _buildPolicyCard(
                    numberId: 'SEC 02',
                    title: '2. Location Access (Background)',
                    content: 'To dispatch nearby ride requests and track ongoing trips for passenger safety, our application collects precise location data, including when the app is closed or running in the background. Background location access is required for core app functions.',
                    bulletPoints: [
                      'Tracks active trips in the background to provide accurate fares.',
                      'Verifies route completion and ensures passenger/driver safety.',
                    ],
                  ),
                  _buildPolicyCard(
                    numberId: 'SEC 03',
                    title: '3. Information We Collect',
                    content: 'We collect your personal information during registration (Name, Phone, Email), identity verification documents (Driver’s License, Vehicle Registration, Insurance), and financial details for payout processing.',
                    bulletPoints: [
                      'Verification: Driver’s license, vehicle documents, and commercial permit.',
                      'Payout details: Bank account number or payment wallet credentials.',
                    ],
                  ),
                  _buildPolicyCard(
                    numberId: 'SEC 04',
                    title: '4. Data Security & Storage',
                    content: 'All personal and vehicle data is encrypted in transit and at rest using industry-standard security protocols. We do not sell your personal data to third parties. We share location data with mapping partners solely for trip routing.',
                    bulletPoints: [
                      'Data Encryption: Fully secured with SSL/TLS protocols.',
                      'Third-party Sharing: Only with certified routing and map APIs.',
                    ],
                  ),
                  _buildPolicyCard(
                    numberId: 'SEC 05',
                    title: '5. Account & Data Deletion',
                    content: 'You retain complete ownership of your data. You can request changes or permanent deletion of your driver profile and associated trip records at any time by contacting our support desk or raising a ticket.',
                    bulletPoints: [
                      'Data Control: Request details modification through the profile tab.',
                      'Deletion: Permanent account closure and database purge upon request.',
                    ],
                  ),
                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16,
        bottom: 20,
        left: 20,
        right: 20,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              InkWell(
                onTap: () {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                },
                borderRadius: BorderRadius.circular(20.r),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                    size: 20,
                  ),
                ),
              ),
              SizedBox(width: 16.w),
              Text(
                'Privacy Policy',
                style: AppFonts.h2.copyWith(
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF334155),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPolicyCard({
    required String numberId,
    required String title,
    required String content,
    required List<String> bulletPoints,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(color: AppColors.primary.withOpacity(0.2), width: 1.5),
      ),
      child: Padding(
        padding: EdgeInsets.all(18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                    child: Text(
                      numberId,
                      style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w800,
                        fontFamily: AppFonts.fontFamily,
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12.h),
              Text(
                content,
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 13.sp,
                  color: const Color(0xFF94A3B8),
                  height: 1.6,
                  fontWeight: FontWeight.w800,
                ),
              ),
              if (bulletPoints.isNotEmpty) ...[
                SizedBox(height: 12.h),
                ...bulletPoints.map((point) => Padding(
                  padding: EdgeInsets.only(bottom: 8.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 6.h),
                        child: Container(
                          width: 6.w,
                          height: 6.w,
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.6),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Expanded(
                        child: Text(
                          point,
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 12.5.sp,
                            color: const Color(0xFF94A3B8),
                            fontWeight: FontWeight.w800,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
              ],
            ],
          ),
        ),
    );
  }
}
