import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';

class TermsConditionsScreen extends StatelessWidget {
  const TermsConditionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Column(
                children: [
                  _buildTermCard(
                    numberId: 'TERM 01',
                    title: '1. Agreement to Terms',
                    content: 'By registering, logging in, or performing ride services on this platform, you agree to comply with and be bound by these Terms and Conditions. If you disagree, please stop using the service.',
                    bulletPoints: [
                      'Subject to periodic updates with prior notifications.',
                      'Applies to all active and offline states within the driver application.',
                    ],
                  ),
                  _buildTermCard(
                    numberId: 'TERM 02',
                    title: '2. Eligibility & Verification',
                    content: 'As a Driver Partner, you represent that you hold a valid driver\'s license, possess active commercial vehicle insurance, and have passed the background check. All uploaded documents must remain authentic and up-to-date.',
                    bulletPoints: [
                      'Must be at least 18 years of age (or legal driving age).',
                      'Uploaded documents must be valid, legible, and unexpired.',
                    ],
                  ),
                  _buildTermCard(
                    numberId: 'TERM 03',
                    title: '3. Driver Code of Conduct',
                    content: 'You must maintain a professional behavior, adhere to traffic laws, avoid driving under the influence of substances, and keep your vehicle in a safe, clean, and road-worthy condition for trip fulfillment.',
                    bulletPoints: [
                      'Zero-tolerance policy for harassment, discrimination, or verbal abuse.',
                      'Compliance with all state and city-level traffic regulations.',
                    ],
                  ),
                  _buildTermCard(
                    numberId: 'TERM 04',
                    title: '4. Fare Payments & Wallet',
                    content: 'Fares, tips, and bonus calculations are transparently credited to your in-app wallet. Commission deductions and service fees are calculated per ride as defined. Withdrawals are processed based on the platform\'s schedule.',
                    bulletPoints: [
                      'Fares: Calculated based on base rate + distance + duration.',
                      'Settlements: Weekly direct bank deposits or instant wallet cashouts.',
                    ],
                  ),
                  _buildTermCard(
                    numberId: 'TERM 05',
                    title: '5. Account Suspension',
                    content: 'We reserve the right to suspend or block your account immediately in case of safety violations, document expiration, consistently low ratings, or fraudulent behavior on trips.',
                    bulletPoints: [
                      'Temporary holds for document reviews or expired permits.',
                      'Permanent deactivation for serious safety breaches or fraud.',
                    ],
                  ),
                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16,
        bottom: 20,
        left: 20,
        right: 20,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              InkWell(
                onTap: () {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                },
                borderRadius: BorderRadius.circular(20.r),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                    size: 20,
                  ),
                ),
              ),
              SizedBox(width: 16.w),
              Text(
                'Terms & Conditions',
                style: AppFonts.h2.copyWith(
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF334155),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTermCard({
    required String numberId,
    required String title,
    required String content,
    required List<String> bulletPoints,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(color: AppColors.primary.withOpacity(0.2), width: 1.5),
      ),
      child: Padding(
        padding: EdgeInsets.all(18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                    child: Text(
                      numberId,
                      style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w800,
                        fontFamily: AppFonts.fontFamily,
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12.h),
              Text(
                content,
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 13.sp,
                  color: const Color(0xFF94A3B8),
                  height: 1.6,
                  fontWeight: FontWeight.w800,
                ),
              ),
              if (bulletPoints.isNotEmpty) ...[
                SizedBox(height: 12.h),
                ...bulletPoints.map((point) => Padding(
                  padding: EdgeInsets.only(bottom: 8.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 6.h),
                        child: Container(
                          width: 6.w,
                          height: 6.w,
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.6),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Expanded(
                        child: Text(
                          point,
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 12.5.sp,
                            color: const Color(0xFF94A3B8),
                            fontWeight: FontWeight.w800,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
              ],
            ],
          ),
        ),
    );
  }
}
