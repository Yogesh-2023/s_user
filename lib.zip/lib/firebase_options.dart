// This is a placeholder for firebase_options.dart.
// To generate this file, run `flutterfire configure` in your terminal.
class DefaultFirebaseOptions {
  static const bool isConfigured = false;
}
