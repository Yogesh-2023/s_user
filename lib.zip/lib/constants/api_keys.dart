class ApiKeys {
  static const String googleMapsKey = "AIzaSyCLojebMjolba-euRhQRW-HvuIUZhESFS8";
  static const String razorpayKey = "rzp_test_RxMtBgMZgON9fo";
}
