import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'api_constants.dart';
import 'api_exception.dart';
import 'api_response.dart';
import 'api_status_code.dart';

class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  Future<Map<String, String>> _getMergedHeaders(Map<String, String>? customHeaders) async {
    final prefs = await SharedPreferences.getInstance();
    final cookie = prefs.getString('session_cookie');
    final token = prefs.getString('auth_token');
    return {
      ...ApiConstants.defaultHeaders,
      if (token != null && token.isNotEmpty) ...{
        'Cookie': 'session=$token; better-auth.session_token=$token',
      } else if (cookie != null && cookie.isNotEmpty) ...{
        'Cookie': cookie,
      },
      if (token != null && token.isNotEmpty) ...{
        'Authorization': 'Bearer $token',
      },
      if (customHeaders != null) ...customHeaders,
    };
  }

  Future<ApiResponse<dynamic>> get(
    String endpoint, {
    Map<String, String>? headers,
    Map<String, dynamic>? queryParameters,
  }) async {
    final uri = _buildUri(endpoint, queryParameters);
    final mergedHeaders = await _getMergedHeaders(headers);

    print('APP LOG: GET Request to -> $uri');

    try {
      final response = await _client
          .get(uri, headers: mergedHeaders)
          .timeout(ApiConstants.connectTimeout);

      return await _handleResponse(response);
    } on TimeoutException {
      throw const ApiException(
        message: 'Request timeout. Please try again.',
        statusCode: 408,
      );
    } on http.ClientException catch (error) {
      throw ApiException(message: error.message, statusCode: 0);
    } catch (error) {
      throw ApiException(message: error.toString(), statusCode: 0);
    }
  }

  Future<ApiResponse<dynamic>> post(
    String endpoint, {
    Map<String, String>? headers,
    dynamic body,
  }) async {
    final uri = _buildUri(endpoint, null);
    final mergedHeaders = await _getMergedHeaders(headers);

    print('APP LOG: POST Request to -> $uri');
    print('APP LOG: POST Request Body -> $body');
    try {
      final response = await _client
          .post(
            uri,
            headers: mergedHeaders,
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(ApiConstants.connectTimeout);

      return await _handleResponse(response);
    } on TimeoutException {
      throw const ApiException(
        message: 'Request timeout. Please try again.',
        statusCode: 408,
      );
    } on http.ClientException catch (error) {
      throw ApiException(message: error.message, statusCode: 0);
    } catch (error) {
      throw ApiException(message: error.toString(), statusCode: 0);
    }
  }

  Future<ApiResponse<dynamic>> patch(
    String endpoint, {
    Map<String, String>? headers,
    dynamic body,
  }) async {
    final uri = _buildUri(endpoint, null);
    final mergedHeaders = await _getMergedHeaders(headers);

    print('APP LOG: PATCH Request to -> $uri');
    print('APP LOG: PATCH Request Body -> $body');
    try {
      final response = await _client
          .patch(
            uri,
            headers: mergedHeaders,
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(ApiConstants.connectTimeout);

      return await _handleResponse(response);
    } on TimeoutException {
      throw const ApiException(
        message: 'Request timeout. Please try again.',
        statusCode: 408,
      );
    } on http.ClientException catch (error) {
      throw ApiException(message: error.message, statusCode: 0);
    } catch (error) {
      throw ApiException(message: error.toString(), statusCode: 0);
    }
  }

  Uri _buildUri(String endpoint, Map<String, dynamic>? queryParameters) {
    final normalizedEndpoint = endpoint.startsWith('/')
        ? endpoint
        : '/$endpoint';
    final uri = Uri.parse('${ApiConstants.baseUrl}$normalizedEndpoint');

    if (queryParameters == null || queryParameters.isEmpty) {
      return uri;
    }

    final sanitizedQuery = queryParameters.map(
      (key, value) => MapEntry(key, value.toString()),
    );

    return uri.replace(queryParameters: sanitizedQuery);
  }

  Future<ApiResponse<dynamic>> _handleResponse(http.Response response) async {
    print('APP LOG: Response Headers -> ${response.headers}');
    await _updateCookie(response);
    final body = _decodeBody(response.body);

    print('APP LOG: Response Status Code -> ${response.statusCode}');
    print('APP LOG: Response Body -> $body');

    if (ApiStatusCode.isSuccess(response.statusCode)) {
      return ApiResponse<dynamic>(
        data: body,
        statusCode: response.statusCode,
        message: _successMessage(response.statusCode),
      );
    }

    throw ApiException(
      message: _errorMessage(response.statusCode, body),
      statusCode: response.statusCode,
      responseBody: body,
    );
  }

  Future<void> _updateCookie(http.Response response) async {
    final rawCookie = response.headers['set-cookie'] ?? response.headers['Set-Cookie'];
    print('APP LOG: rawCookie from headers -> $rawCookie');
    if (rawCookie != null && rawCookie.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      final regExp = RegExp(r'(session|better-auth\.session_token)=([^;,\s]+)');
      final match = regExp.firstMatch(rawCookie);
      print('APP LOG: regex match -> $match');
      if (match != null) {
        final key = match.group(1);
        final token = match.group(2);
        if (token != null && token.isNotEmpty) {
          final cookieStr = '$key=$token';
          await prefs.setString('session_cookie', cookieStr);
          await prefs.setString('auth_token', token);
          print('APP LOG: Extracted & saved session_cookie: $cookieStr');
          print('APP LOG: Extracted & saved auth_token: $token');
        }
      }
    }
  }

  dynamic _decodeBody(String body) {
    if (body.isEmpty) {
      return null;
    }

    try {
      return jsonDecode(body);
    } catch (_) {
      return body;
    }
  }

  String _successMessage(int statusCode) {
    switch (statusCode) {
      case ApiStatusCode.ok:
        return 'Request completed successfully.';
      case ApiStatusCode.created:
        return 'Resource created successfully.';
      case ApiStatusCode.noContent:
        return 'Request completed with no content.';
      default:
        return 'Request successful.';
    }
  }

  String _errorMessage(int statusCode, dynamic body) {
    final serverMessage = _extractServerMessage(body);
    if (serverMessage != null && serverMessage.isNotEmpty) {
      return serverMessage;
    }

    switch (statusCode) {
      case ApiStatusCode.badRequest:
        return 'Invalid request.';
      case ApiStatusCode.unauthorized:
        return 'Session expired. Please login again.';
      case ApiStatusCode.forbidden:
        return 'You do not have permission to perform this action.';
      case ApiStatusCode.notFound:
        return 'Requested data was not found.';
      case ApiStatusCode.conflict:
        return 'This request conflicts with existing data.';
      case ApiStatusCode.validationError:
        return 'Please check the submitted details.';
      case ApiStatusCode.serverError:
      case ApiStatusCode.badGateway:
      case ApiStatusCode.serviceUnavailable:
        return 'Server is unavailable. Please try again later.';
      default:
        return 'Something went wrong. Please try again.';
    }
  }

  String? _extractServerMessage(dynamic body) {
    if (body is Map<String, dynamic>) {
      final message = body['message'] ?? body['error'];
      if (message is String) {
        return message;
      }
    }

    return null;
  }
}
