class ApiException implements Exception {
  const ApiException({
    required this.message,
    required this.statusCode,
    this.responseBody,
  });

  final String message;
  final int statusCode;
  final dynamic responseBody;

  @override
  String toString() => 'ApiException($statusCode): $message';
}
