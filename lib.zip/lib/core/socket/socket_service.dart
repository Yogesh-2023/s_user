import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../../constants/app_colors.dart';
import '../api/api_constants.dart';
import '../utils.dart';
import 'socket_events.dart';

enum SocketConnectionStatus { disconnected, connecting, connected, error }

class SocketService extends GetxService {
  IO.Socket? _socket;
  final Rx<SocketConnectionStatus> connectionStatus = SocketConnectionStatus.disconnected.obs;
  
  // Keep track of listeners registered before socket connects
  final Map<String, List<Function(dynamic)>> _queuedListeners = {};

  static SocketService get to {
    try {
      return Get.find<SocketService>();
    } catch (e) {
      return Get.put(SocketService(), permanent: true);
    }
  }

  // Active status checks
  bool get isConnected => connectionStatus.value == SocketConnectionStatus.connected;
  bool get isConnecting => connectionStatus.value == SocketConnectionStatus.connecting;

  // Stream for listening to connection status changes
  Stream<SocketConnectionStatus> get statusStream => connectionStatus.stream;

  // Callback to execute when connection is established (for active state recovery)
  Future<void> Function()? onConnectionEstablished;

  /// Initializes and connects to the socket server
  void initSocket({
    required String sessionToken,
    required String userId,
    String role = 'user',
  }) {
    print('--- [SOCKET_IO] Initializing socket connection for User App ---');
    print('--- [SOCKET_IO] Target URL: ${ApiConstants.baseUrl} ---');
    print('--- [SOCKET_IO] Query Params: role=$role, userId=$userId, sessionToken=*** ---');

    // Close existing socket if any
    closeSocket();

    connectionStatus.value = SocketConnectionStatus.connecting;

    String parsedSessionToken = sessionToken;
    if (sessionToken.contains('session=')) {
      final matches = RegExp(r'session=([^;]+)').firstMatch(sessionToken);
      if (matches != null && matches.groupCount >= 1) {
        parsedSessionToken = matches.group(1) ?? sessionToken;
      }
    }

    try {
      var socketUrl = ApiConstants.baseUrl.replaceAll('/api', '');
      print('--- [SOCKET_IO] Resolved Socket URL: $socketUrl ---');

      _socket = IO.io(
        socketUrl,
        IO.OptionBuilder()
            .disableAutoConnect()
            .enableForceNew()
            .enableReconnection()
            .setReconnectionAttempts(20)
            .setReconnectionDelay(1500)
            .setTimeout(20000)
            .setTransports(['websocket', 'polling'])
            .setQuery({
              'role': role,
              'sessionToken': parsedSessionToken,
              'userId': userId,
            })
            .setExtraHeaders({
              'Cookie': 'better-auth.session_token=$sessionToken',
              'Authorization': 'Bearer $sessionToken',
            })
            .build(),
      );

      _setupListeners();
      _socket!.connect();
    } catch (e) {
      connectionStatus.value = SocketConnectionStatus.error;
      print('--- [SOCKET_IO] Initialization Error: $e ---');
    }
  }

  /// Sets up default event listeners
  void _setupListeners() {
    if (_socket == null) return;

    // Attach any listeners that were queued before initialization
    _queuedListeners.forEach((event, callbacks) {
      for (var callback in callbacks) {
        listenTo(event, callback, fromQueue: true);
      }
    });
    _queuedListeners.clear();

    // 1. Connection established
    _socket!.on(SocketEvents.connect, (_) async {
      connectionStatus.value = SocketConnectionStatus.connected;
      print('--- [SOCKET_IO] Connected! Socket ID: ${_socket!.id} ---');

      // Trigger reconnection/recovery callback if registered
      if (onConnectionEstablished != null) {
        print('--- [SOCKET_IO] Triggering active booking recovery callback ---');
        await onConnectionEstablished!();
      }
    });

    // 2. Disconnected
    _socket!.on(SocketEvents.disconnect, (reason) {
      connectionStatus.value = SocketConnectionStatus.disconnected;
      print('--- [SOCKET_IO] Disconnected. Reason: $reason ---');
    });

    // 3. Connection Error
    _socket!.on(SocketEvents.connectError, (err) {
      connectionStatus.value = SocketConnectionStatus.error;
      print('--- [SOCKET_IO] Connection Error: $err ---');
    });

    // 4. General Error
    _socket!.on(SocketEvents.error, (err) {
      print('--- [SOCKET_IO] Socket Error: $err ---');
    });

    // 5. Global Listener for debugging events (Custom Event Log)
    // Note: socket_io_client in Dart doesn't have socket.onevent out of the box,
    // so we wrap the standard event registration to print inputs.
    
    // Debug Listeners for all Ride & Goods Flows (Always print in terminal)
    final debugEvents = [
      'RIDE_BOOKED',
      'NEW_TRIP_REQUEST',
      'TRIP_ACCEPTED',
      'DRIVER_FOUND',
      'DRIVER_ON_THE_WAY',
      'DRIVER_REJECTED',
      'NO_DRIVER_FOUND',
      'DRIVER_LOCATION',
      'DRIVER_ARRIVED',
      'TRIP_STARTED',
      'TRIP_COMPLETED',
      'goods.driver.assigned',
      'goods.driver.on_the_way',
      'goods.pickup.otp.sent',
      'goods.pickup.otp.required',
      'goods.booking.created',
      'goods:booking:request'
    ];

    for (var event in debugEvents) {
      _socket!.on(event, (data) {
        if (data is Map) {
          _capitalizeAuto(data);
        }
        print('\n====== 🚀 [USER APP SOCKET DEBUG] $event ======');
        print('Payload: $data');
        print('===============================================\n');
        
        // Skip location spam for snackbars
        if (event != 'DRIVER_LOCATION' && event != 'DRIVER_LOCATION_UPDATE') {
          String msg = 'Event: $event';
          if (data is Map && data['message'] != null) {
             msg = data['message'].toString();
          }
          if (Get.context != null) {
            AppUtils.showSnackBar(Get.context!, msg);
          }
        }
      });
    }
  }

  void _capitalizeAuto(Map data) {
    try {
      if (data['carName']?.toString().toUpperCase() == 'AUTO') {
        data['carName'] = 'AUTO';
      }
      if (data['carType']?.toString().toUpperCase() == 'AUTO') {
        data['carType'] = 'AUTO';
      }
      if (data['vehicleType']?.toString().toUpperCase() == 'AUTO') {
        data['vehicleType'] = 'AUTO';
      }
      for (var key in data.keys.toList()) {
        if (data[key] is Map) {
          _capitalizeAuto(data[key]);
        }
      }
    } catch (e) {
      print('Failed to capitalize map data safely: $e');
    }
  }

  /// Registers a listener for a specific socket event
  void listenTo(String event, Function(dynamic data) callback, {bool fromQueue = false}) {
    if (_socket == null) {
      print('--- [SOCKET_IO] Warning: Socket not initialized. Queueing listener for "$event". ---');
      _queuedListeners.putIfAbsent(event, () => []).add(callback);
      return;
    }

    if (!fromQueue) {
      print('--- [SOCKET_IO] Registering listener for "$event" ---');
    }

    _socket!.on(event, (data) {
      if (data is Map) {
        _capitalizeAuto(data);
      }
      print('--- [SOCKET_IO] [EVENT RECEIVED] -> Event: "$event" ---');
      print('--- [SOCKET_IO] [PAYLOAD] -> $data ---');
      
      if (event != 'DRIVER_LOCATION' && event != 'DRIVER_LOCATION_UPDATE') {
        String msg = 'Event: $event';
        if (data is Map && data['message'] != null) {
           msg = data['message'].toString();
        }
        if (Get.context != null) {
          AppUtils.showSnackBar(Get.context!, msg);
        }
      }
      
      callback(data);
    });

    // Also register error listeners for specific event (e.g. event_name:error)
    final errorEvent = '$event:error';
    _socket!.on(errorEvent, (errorData) {
      print('--- [SOCKET_IO] [ERROR RECEIVED] -> Event: "$errorEvent" ---');
      print('--- [SOCKET_IO] [ERROR DETAILS] -> $errorData ---');
      
      if (Get.context != null) {
        String errorMsg = errorData is Map ? (errorData['message'] ?? 'An error occurred') : errorData.toString();
        AppUtils.showSnackBar(Get.context!, errorMsg, isError: true);
      }
    });
  }

  /// Unregisters a listener for a specific event
  void stopListening(String event) {
    if (_socket != null) {
      print('--- [SOCKET_IO] Stopped listening to: "$event" ---');
      _socket!.off(event);
      _socket!.off('$event:error');
    }
  }

  /// Emits an event with optional payload
  void emitEvent(String event, [dynamic data]) {
    if (_socket == null || !isConnected) {
      print('--- [SOCKET_IO] Error: Cannot emit "$event". Socket is not connected. ---');
      return;
    }

    print('--- [SOCKET_IO] [EMITTING EVENT] -> Event: "$event" ---');
    if (data != null) {
      print('--- [SOCKET_IO] [EMIT PAYLOAD] -> $data ---');
      _socket!.emit(event, data);
    } else {
      _socket!.emit(event);
    }
  }

  /// Closes the socket connection
  void closeSocket() {
    if (_socket != null) {
      print('--- [SOCKET_IO] Closing and destroying socket connection ---');
      _socket!.disconnect();
      _socket!.dispose();
      _socket = null;
    }
    connectionStatus.value = SocketConnectionStatus.disconnected;
  }

  @override
  void onClose() {
    closeSocket();
    super.onClose();
  }
}
