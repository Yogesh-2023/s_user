import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import 'raise_issue_screen.dart';
import 'ticket_chat_screen.dart';

class SupportTicket {
  final String id;
  final String title;
  final String description;
  final String category;
  final DateTime createdAt;
  String status;
  List<Map<String, dynamic>> messages;

  SupportTicket({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.createdAt,
    this.status = 'Open',
    required this.messages,
  });
}

class HelpSupportScreen extends StatefulWidget {
  const HelpSupportScreen({Key? key}) : super(key: key);

  @override
  State<HelpSupportScreen> createState() => _HelpSupportScreenState();
}

class _HelpSupportScreenState extends State<HelpSupportScreen> {
  final Color themeColor = const Color(0xFF00ABE4); // DobelGo primary theme color (cyan)
  final Color lightThemeColor = const Color(0xFFE6F7FD); // DobelGo light theme color (cyan tint)
  
  // Start with some mock tickets to demonstrate the beautiful layout instantly
  static final List<SupportTicket> _tickets = [
    SupportTicket(
      id: '409b89a7',
      title: 'dhudurhdhdhd',
      description: 'shuddujdhdu',
      category: 'App Issues',
      createdAt: DateTime.now().subtract(const Duration(minutes: 5)),
      status: 'Open',
      messages: [
        {
          'sender': 'user',
          'text': 'shuddujdhdu',
          'time': DateTime.now().subtract(const Duration(minutes: 5)),
        }
      ],
    ),
    SupportTicket(
      id: 'b9ca93d2',
      title: 'Document Upload Issue',
      description: 'shuddhhdhdhdjdjdj',
      category: 'Other',
      createdAt: DateTime.now().subtract(const Duration(minutes: 10)),
      status: 'Open',
      messages: [
        {
          'sender': 'user',
          'text': 'shuddhhdhdhdjdjdj',
          'time': DateTime.now().subtract(const Duration(minutes: 10)),
        }
      ],
    ),
  ];

  void _showTicketDetails(SupportTicket ticket) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TicketChatScreen(ticket: ticket),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Column(
        children: [
          // Header Bar
          Padding(
            padding: EdgeInsets.only(
              top: statusBarHeight + 12.h,
              left: 16.w,
              right: 16.w,
              bottom: 12.h,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40.w,
                    height: 40.w,
                    decoration: BoxDecoration(
                      color: themeColor,
                      borderRadius: BorderRadius.circular(12.r),
                      boxShadow: [
                        BoxShadow(
                          color: themeColor.withOpacity(0.15),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.chevron_left_rounded,
                      color: Colors.white,
                      size: 26,
                    ),
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Toxify',
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 24.sp,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 2.w, bottom: 10.h),
                      width: 6.w,
                      height: 6.w,
                      decoration: BoxDecoration(
                        color: themeColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 40.w), // To keep logo centered
              ],
            ),
          ),
          
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Help & Support Title & Subtitle
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Help & Support',
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 22.sp,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          'Track your tickets and chat with support.',
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 12.sp,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Need Help Card
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 20.w),
                    padding: EdgeInsets.all(16.w),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: Colors.grey.shade100,
                        width: 1.5.w,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.015),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Ticket Icon Container
                        Container(
                          width: 44.w,
                          height: 44.w,
                          decoration: BoxDecoration(
                            color: lightThemeColor,
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Icon(
                            Icons.local_play_outlined,
                            color: themeColor,
                            size: 22.sp,
                          ),
                        ),
                        SizedBox(width: 12.w),

                        // Text content
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Need help?',
                                style: TextStyle(
                                  fontFamily: AppFonts.fontFamily,
                                  fontSize: 15.sp,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              SizedBox(height: 2.h),
                              Text(
                                'Raise a ticket to get assistance.',
                                style: TextStyle(
                                  fontFamily: AppFonts.fontFamily,
                                  fontSize: 11.sp,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Button
                        GestureDetector(
                          onTap: () async {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const RaiseIssueScreen(),
                              ),
                            );
                            if (result != null && result is SupportTicket) {
                              setState(() {
                                _tickets.insert(0, result);
                              });
                              // Show success dialog
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(height: 10.h),
                                      Container(
                                        padding: EdgeInsets.all(12.w),
                                        decoration: const BoxDecoration(
                                          color: Color(0xFFE2F7EE),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(
                                          Icons.check_circle_rounded,
                                          color: Color(0xFF00B050),
                                          size: 50,
                                        ),
                                      ),
                                      SizedBox(height: 16.h),
                                      Text(
                                        'Ticket Created!',
                                        style: TextStyle(
                                          fontFamily: AppFonts.fontFamily,
                                          fontSize: 18.sp,
                                          fontWeight: FontWeight.bold,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                      SizedBox(height: 8.h),
                                      Text(
                                        'Your ticket ID is ${result.id}. We will resolve your issue as soon as possible.',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: AppFonts.fontFamily,
                                          fontSize: 12.sp,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                      SizedBox(height: 20.h),
                                      SizedBox(
                                        width: double.infinity,
                                        height: 44.h,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: themeColor,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12.r),
                                            ),
                                          ),
                                          onPressed: () => Navigator.pop(context),
                                          child: Text(
                                            'Okay',
                                            style: TextStyle(
                                              fontFamily: AppFonts.fontFamily,
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
                            decoration: BoxDecoration(
                              color: themeColor,
                              borderRadius: BorderRadius.circular(12.r),
                              boxShadow: [
                                BoxShadow(
                                  color: themeColor.withOpacity(0.2),
                                  blurRadius: 6,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 14,
                                ),
                                SizedBox(width: 2.w),
                                Text(
                                  'New',
                                  style: TextStyle(
                                    fontFamily: AppFonts.fontFamily,
                                    fontSize: 12.sp,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 32.h),

                  // Tickets list or Placeholder
                  _tickets.isEmpty ? _buildNoTicketsPlaceholder() : _buildTicketsList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoTicketsPlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: SizedBox(
            width: 120.w,
            height: 120.w,
            child: CustomPaint(
              painter: SupportAgentPainter(color: themeColor),
            ),
          ),
        ),
        SizedBox(height: 24.h),
        Text(
          'No tickets yet',
          style: TextStyle(
            fontFamily: AppFonts.fontFamily,
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildTicketsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
          child: Text(
            'Your Recent Tickets',
            style: TextStyle(
              fontFamily: AppFonts.fontFamily,
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          itemCount: _tickets.length,
          itemBuilder: (context, index) {
            final ticket = _tickets[index];
            final String formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(ticket.createdAt);

            return Container(
              margin: EdgeInsets.only(bottom: 16.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20.r),
                border: Border.all(
                  color: const Color(0xFFE9F0F8),
                  width: 1.2.w,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.015),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Padding(
                padding: EdgeInsets.all(16.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Top Row: ID & Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'ID: ${ticket.id}',
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 11.sp,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE2F7EE),
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 5.w,
                                height: 5.w,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF00B050),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                ticket.status.toUpperCase(),
                                style: TextStyle(
                                  fontFamily: AppFonts.fontFamily,
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF00B050),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12.h),

                    // Title
                    Text(
                      ticket.title,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    SizedBox(height: 6.h),

                    // Clock & Date Row
                    Row(
                      children: [
                        Icon(
                          Icons.access_time,
                          color: AppColors.textSecondary,
                          size: 13.sp,
                        ),
                        SizedBox(width: 4.w),
                        Text(
                          formattedDate,
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 11.sp,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12.h),

                    // Divider
                    Container(
                      height: 1.h,
                      color: const Color(0xFFF0F4F8),
                    ),
                    SizedBox(height: 12.h),

                    // Description
                    Text(
                      ticket.description,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 12.sp,
                        color: AppColors.textSecondary,
                        height: 1.4,
                      ),
                    ),
                    SizedBox(height: 16.h),

                    // Chat Now Button (Light blue container matching cyan theme)
                    GestureDetector(
                      onTap: () => _showTicketDetails(ticket),
                      child: Container(
                        width: double.infinity,
                        height: 42.h,
                        decoration: BoxDecoration(
                          color: lightThemeColor,
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.chat_bubble_outline_rounded,
                              color: themeColor,
                              size: 16.sp,
                            ),
                            SizedBox(width: 6.w),
                            Text(
                              'Chat Now',
                              style: TextStyle(
                                fontFamily: AppFonts.fontFamily,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w800,
                                color: themeColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class SupportAgentPainter extends CustomPainter {
  final Color color;
  SupportAgentPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5.w
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    double cx = size.width / 2;
    double cy = size.height / 2;

    // Draw Headband (Arch)
    Rect headbandRect = Rect.fromCircle(center: Offset(cx, cy - 8.h), radius: 36.w);
    canvas.drawArc(headbandRect, -3.14, 3.14, false, paint);

    // Draw Hair outline (Outer curve)
    Path hairPath = Path();
    hairPath.moveTo(cx - 28.w, cy + 4.h);
    hairPath.cubicTo(cx - 28.w, cy - 20.h, cx + 28.w, cy - 20.h, cx + 28.w, cy + 4.h);
    canvas.drawPath(hairPath, paint);

    // Semicircle for bottom of the face / chin
    Rect faceRect = Rect.fromCircle(center: Offset(cx, cy + 4.h), radius: 20.w);
    canvas.drawArc(faceRect, 0, 3.14, false, paint);

    // Eyes (two small dots)
    canvas.drawCircle(Offset(cx - 7.w, cy + 2.h), 2.2.w, fillPaint);
    canvas.drawCircle(Offset(cx + 7.w, cy + 2.h), 2.2.w, fillPaint);

    // Earcups on sides of headband
    Rect leftEarcup = Rect.fromLTWH(cx - 40.w, cy - 10.h, 7.w, 20.h);
    canvas.drawRRect(RRect.fromRectAndRadius(leftEarcup, Radius.circular(4.r)), fillPaint);

    Rect rightEarcup = Rect.fromLTWH(cx + 33.w, cy - 10.h, 7.w, 20.h);
    canvas.drawRRect(RRect.fromRectAndRadius(rightEarcup, Radius.circular(4.r)), fillPaint);

    // Microphone stem
    Path micPath = Path();
    micPath.moveTo(cx + 33.w, cy + 4.h);
    micPath.quadraticBezierTo(cx + 28.w, cy + 18.h, cx + 8.w, cy + 16.h);
    canvas.drawPath(micPath, paint);

    // Microphone tip
    canvas.drawCircle(Offset(cx + 6.w, cy + 16.h), 3.2.w, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
