import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../models/user_profile.dart';
import '../../services/profile_service.dart';

class ProfileEditScreen extends StatefulWidget {
  final UserProfile? profile;
  const ProfileEditScreen({Key? key, this.profile}) : super(key: key);

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final ProfileService _service = ProfileService();
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _firstCtrl;
  late TextEditingController _lastCtrl;
  String _requirement = 'PERSONAL';
  XFile? _selectedImage;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    final p = widget.profile;
    _nameCtrl = TextEditingController(text: p?.name ?? '');
    _emailCtrl = TextEditingController(text: p?.email ?? '');
    _phoneCtrl = TextEditingController(text: p?.phone ?? '');
    _firstCtrl = TextEditingController(text: p?.firstname ?? '');
    _lastCtrl = TextEditingController(text: p?.lastname ?? '');
    if (p != null && p.requirement.isNotEmpty) {
      _requirement = p.requirement.toUpperCase();
    }
    if (p == null) {
      _loadSavedPhone();
    }
  }

  Future<void> _loadSavedPhone() async {
    final prefs = await SharedPreferences.getInstance();
    final phone = prefs.getString('user_phone') ?? '';
    if (phone.isNotEmpty) {
      setState(() {
        _phoneCtrl.text = phone;
      });
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _firstCtrl.dispose();
    _lastCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    final img = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (img != null) {
      setState(() {
        _selectedImage = img;
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    final fields = {
      'name': _nameCtrl.text.trim(),
      'email': _emailCtrl.text.trim(),
      'phone': _phoneCtrl.text.trim(),
      'firstname': _firstCtrl.text.trim(),
      'lastname': _lastCtrl.text.trim(),
      'requirement': _requirement,
    };

    UserProfile? result;
    try {
      if (widget.profile == null) {
        result = await _service.createProfile(
          fields: fields,
          avatarPath: _selectedImage?.path ?? '',
        );
      } else {
        result = await _service.updateProfile(
          fields: fields,
          avatarPath: _selectedImage?.path,
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        if (result != null) {
          Navigator.pop(context, result);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to save profile. Please try again.')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditMode = widget.profile != null;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          isEditMode ? 'Edit Profile' : 'Create Profile',
          style: AppFonts.h2.copyWith(fontSize: 20.sp),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF00ABE4)))
          : SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Avatar Picker
                    GestureDetector(
                      onTap: _pickAvatar,
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFF00ABE4), width: 3),
                            ),
                            child: CircleAvatar(
                              radius: 55.r,
                              backgroundColor: Colors.grey.shade200,
                              backgroundImage: _selectedImage != null
                                  ? FileImage(File(_selectedImage!.path))
                                  : (widget.profile?.avatar.isNotEmpty ?? false)
                                      ? NetworkImage(widget.profile!.avatar) as ImageProvider
                                      : const AssetImage('assets/images/profile.png'),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            right: 4,
                            child: Container(
                              padding: EdgeInsets.all(6.w),
                              decoration: const BoxDecoration(
                                color: Color(0xFF00ABE4),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                                size: 18.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),

                    _buildField(
                      label: 'Username / Name',
                      controller: _nameCtrl,
                      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                    _buildField(
                      label: 'First Name',
                      controller: _firstCtrl,
                      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                    _buildField(
                      label: 'Last Name',
                      controller: _lastCtrl,
                      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                    _buildField(
                      label: 'Email Address',
                      controller: _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                    _buildField(
                      label: 'Phone Number',
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                      readOnly: true,
                    ),

                    // Requirement Dropdown
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 8.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Requirement Type',
                            style: AppFonts.captionDark.copyWith(
                              color: AppColors.textSecondary,
                              fontSize: 12.sp,
                            ),
                          ),
                          SizedBox(height: 6.h),
                           DropdownButtonFormField<String>(
                             value: _requirement,
                             dropdownColor: Colors.white,
                             iconEnabledColor: Colors.black,
                             style: TextStyle(
                               color: Colors.black,
                               fontSize: 14.sp,
                               fontWeight: FontWeight.w600,
                             ),
                             decoration: InputDecoration(
                               filled: true,
                               fillColor: AppColors.textFieldBackground,
                               contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                               border: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: BorderSide(color: AppColors.authButtonBorder),
                               ),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: BorderSide(color: AppColors.authButtonBorder),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: const BorderSide(color: Color(0xFF00ABE4)),
                               ),
                             ),
                             items: [
                               DropdownMenuItem(
                                 value: 'PERSONAL',
                                 child: Text(
                                   'Personal',
                                   style: TextStyle(
                                     color: Colors.black,
                                     fontSize: 14.sp,
                                     fontWeight: FontWeight.w600,
                                   ),
                                 ),
                               ),
                               DropdownMenuItem(
                                 value: 'BUSINESS',
                                 child: Text(
                                   'Business',
                                   style: TextStyle(
                                     color: Colors.black,
                                     fontSize: 14.sp,
                                     fontWeight: FontWeight.w600,
                                   ),
                                 ),
                               ),
                             ],
                             onChanged: (val) {
                               if (val != null) {
                                 setState(() {
                                   _requirement = val;
                                 });
                               }
                             },
                           ),
                        ],
                      ),
                    ),

                    SizedBox(height: 32.h),

                    // Save Button
                    SizedBox(
                      width: double.infinity,
                      height: 52.h,
                      child: ElevatedButton(
                        onPressed: _save,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00ABE4),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          elevation: 0,
                        ),
                        child: Text(
                          isEditMode ? 'Update Profile' : 'Create Profile',
                          style: AppFonts.buttonText.copyWith(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildField({
    required String label,
    required TextEditingController controller,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    bool readOnly = false,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppFonts.captionDark.copyWith(
              color: AppColors.textSecondary,
              fontSize: 12.sp,
            ),
          ),
          SizedBox(height: 6.h),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            validator: validator,
            readOnly: readOnly,
            style: AppFonts.bodyText.copyWith(
              color: readOnly ? Colors.grey : AppColors.textPrimary,
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              filled: true,
              fillColor: readOnly ? Colors.grey.shade100 : AppColors.textFieldBackground,
              contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: AppColors.authButtonBorder),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: AppColors.authButtonBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: readOnly ? AppColors.authButtonBorder : const Color(0xFF00ABE4)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
