import 'package:dobelgodelivery/features/activity/activity_screen.dart';
import 'package:dobelgodelivery/features/support/help_support_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../models/user_profile.dart';
import '../../services/profile_service.dart';
import 'profile_edit_screen.dart';
import '../auth/onboarding_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ProfileService _service = ProfileService();
  UserProfile? _profile;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final prof = await _service.getMyProfile();
      if (mounted) {
        setState(() {
          _profile = prof;
          _isLoading = false;
        });
      }
    } catch (e) {
      print("Error loading profile: $e");
      if (mounted) {
        setState(() {
          _profile = null;
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const OnboardingScreen()),
        (route) => false,
      );
    }
  }

  Future<void> _confirmLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18.r),
          ),
          title: Text(
            'Logout',
            style: AppFonts.h2.copyWith(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            'Are you sure you want to logout?',
            style: AppFonts.bodyText.copyWith(fontSize: 13.sp),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(
                'Cancel',
                style: AppFonts.bodyText.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(
                'Logout',
                style: AppFonts.bodyText.copyWith(
                  color: AppColors.error,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );

    if (shouldLogout == true) {
      _logout();
    }
  }

  void _showSettingsMenu() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.h),
                child: Text(
                  'Settings',
                  style: AppFonts.h2.copyWith(fontSize: 18.sp),
                ),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: Text(
                  'Logout',
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _confirmLogout();
                },
              ),
              ListTile(
                leading: const Icon(Icons.close),
                title: Text('Cancel', style: AppFonts.bodyText),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _navigateToEdit() async {
    final result = await Navigator.push<UserProfile?>(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileEditScreen(profile: _profile),
      ),
    );
    if (result != null) {
      setState(() {
        _profile = result;
      });
    } else {
      // Reload profile from API to ensure we have fresh data
      setState(() {
        _isLoading = true;
      });
      _loadProfile();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasProfile = _profile != null;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF00ABE4)),
              )
            : SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Profile',
                              style: AppFonts.h1.copyWith(
                                fontSize: 26.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'Manage your account and preferences',
                              style: AppFonts.bodyText.copyWith(
                                fontSize: 13.sp,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),

                      ],
                    ),
                    SizedBox(height: 24.h),

                    // Profile & Pro Member Combined Card
                    GestureDetector(
                      onTap: _navigateToEdit,
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20.r),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.03),
                              blurRadius: 15,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Profile row info
                            Row(
                              children: [
                                CircleAvatar(
                                  radius: 35.r,
                                  backgroundColor: Colors.grey.shade200,
                                  backgroundImage:
                                      (hasProfile &&
                                          _profile!.avatar.isNotEmpty)
                                      ? NetworkImage(_profile!.avatar)
                                            as ImageProvider
                                      : const AssetImage(
                                          'assets/images/profile.png',
                                        ),
                                ),
                                SizedBox(width: 14.w),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Flexible(
                                            child: Text(
                                              hasProfile
                                                  ? '${_profile!.firstname} ${_profile!.lastname}'
                                                  : 'Guest User',
                                              style: AppFonts.h2.copyWith(
                                                fontSize: 18.sp,
                                                fontWeight: FontWeight.bold,
                                                color: AppColors.textPrimary,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          SizedBox(width: 4.w),
                                          if (hasProfile)
                                            Icon(
                                              Icons.verified,
                                              color: const Color(0xFF00ABE4),
                                              size: 16.sp,
                                            ),
                                        ],
                                      ),
                                      SizedBox(height: 3.h),
                                      Text(
                                        hasProfile
                                            ? _profile!.phone
                                            : '+91 XXXXX XXXXX',
                                        style: AppFonts.bodyText.copyWith(
                                          fontSize: 13.sp,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                      SizedBox(height: 2.h),
                                      Text(
                                        hasProfile
                                            ? _profile!.email
                                            : 'guest@example.com',
                                        style: AppFonts.bodyText.copyWith(
                                          fontSize: 13.sp,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(
                                  Icons.chevron_right,
                                  color: Colors.grey.shade400,
                                  size: 20.sp,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 24.h),

                    // Wallet Section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Wallet',
                          style: AppFonts.h2.copyWith(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        GestureDetector(
                          onTap: () {},
                          child: Text(
                            'View All Transactions >',
                            style: AppFonts.bodyText.copyWith(
                              color: const Color(0xFF00ABE4),
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12.h),

                    // Wallet Card (Full Width, Cashback Removed)
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(16.w),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.r),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.02),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Wallet Balance',
                            style: AppFonts.bodyText.copyWith(
                              fontSize: 12.sp,
                              color: Colors.grey.shade500,
                            ),
                          ),
                          SizedBox(height: 6.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '₹1,250.00',
                                style: AppFonts.h2.copyWith(
                                  fontSize: 22.sp,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 12.w,
                                    vertical: 8.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.green.shade50,
                                    borderRadius: BorderRadius.circular(8.r),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'Add Money',
                                        style: AppFonts.captionDark.copyWith(
                                          color: Colors.green.shade700,
                                          fontSize: 12.sp,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(width: 4.w),
                                      Icon(
                                        Icons.add_circle_outline,
                                        color: Colors.green.shade700,
                                        size: 14.sp,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),
                    _buildMyBookingsSection(),
                    SizedBox(height: 20.h),
                    _buildAccountSection(context),
                    _buildLogoutCard(),
                    SizedBox(height: 24.h),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildMyBookingsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.zero,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'My Bookings',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              InkWell(
                onTap: () {},
                child: Text(
                  'View All Bookings',
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF007BFF),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 8.h),
        Padding(
          padding: EdgeInsets.zero,
          child: Row(
            children: [
              _buildBookingCard(
                icon: Icons.directions_car_rounded,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Ride',
                subtitle: '12 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.inventory_2_outlined,
                iconColor: const Color(0xFF28A745),
                iconBgColor: const Color(0xFFEAF8EC),
                title: 'Parcel',
                subtitle: '8 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.local_shipping_rounded,
                iconColor: const Color(0xFFFD7E14),
                iconBgColor: const Color(0xFFFFF3CD),
                title: 'Truck',
                subtitle: '5 Bookings',
              ),
              _buildBookingCard(
                icon: Icons.access_time_rounded,
                iconColor: const Color(0xFF6F42C1),
                iconBgColor: const Color(0xFFF1EAFF),
                title: 'Ongoing',
                subtitle: '2 Bookings',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildBookingCard({
    required IconData icon,
    required Color iconColor,
    required Color iconBgColor,
    required String title,
    required String subtitle,
  }) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w),
        padding: EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.01),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(color: Colors.grey.shade100, width: 1),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: iconBgColor,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: iconColor, size: 20.sp),
            ),
            SizedBox(height: 8.h),
            Text(
              title,
              style: TextStyle(
                fontFamily: AppFonts.fontFamily,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              subtitle,
              style: TextStyle(
                fontFamily: AppFonts.fontFamily,
                fontSize: 9.sp,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(top: 8.h, bottom: 8.h),
          child: Text(
            'Account',
            style: TextStyle(
              fontFamily: AppFonts.fontFamily,
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(vertical: 4.h),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.015),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              _buildAccountItem(
                icon: Icons.person_outline_rounded,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Personal Information',
                subtitle: 'Update your personal details',
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.location_on_outlined,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Saved Addresses',
                subtitle: 'Manage your saved addresses',
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.payment_outlined,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Payment Methods',
                subtitle: 'Manage cards, UPI and wallets',
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.card_giftcard_outlined,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Refer & Earn',
                subtitle: 'Invite friends and earn rewards',
                badgeText: 'Earn up to ₹500',
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.help_outline_rounded,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'Help & Support',
                subtitle: 'FAQs, support and more',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const HelpSupportScreen(),
                    ),
                  );
                },
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.info_outline_rounded,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'About Us',
                subtitle: 'Learn more about our services',
              ),
              _buildDivider(),
              _buildAccountItem(
                icon: Icons.history_rounded,
                iconColor: const Color(0xFF007BFF),
                iconBgColor: const Color(0xFFE8F1FF),
                title: 'My Activity',
                subtitle: 'View your activity log',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ActivityScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAccountItem({
    required IconData icon,
    required Color iconColor,
    required Color iconBgColor,
    required String title,
    required String subtitle,
    String? badgeText,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16.r),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: iconBgColor,
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Icon(icon, color: iconColor, size: 20.sp),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 11.sp,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            if (badgeText != null) ...[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF8EC),
                  borderRadius: BorderRadius.circular(6.r),
                ),
                child: Text(
                  badgeText,
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF28A745),
                  ),
                ),
              ),
              SizedBox(width: 8.w),
            ],
            Icon(
              Icons.chevron_right_rounded,
              color: Colors.grey.shade400,
              size: 20.sp,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.grey.shade100,
      indent: 52.w,
    );
  }

  Widget _buildLogoutCard() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 12.h),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5F5),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: const Color(0xFFFFE5E5), width: 1),
      ),
      child: InkWell(
        onTap: _confirmLogout,
        borderRadius: BorderRadius.circular(16.r),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(8.w),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE5E5),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Icon(
                  Icons.logout_rounded,
                  color: AppColors.error,
                  size: 20.sp,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Logout',
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.error,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Securely logout from your account',
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 11.sp,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                color: AppColors.error,
                size: 20.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
