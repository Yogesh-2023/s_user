class UserProfile {
  final String id;
  final String userId;
  final String firstname;
  final String lastname;
  final String name;
  final String email;
  final String phone;
  final String avatar;
  final String requirement;

  UserProfile({
    required this.id,
    required this.userId,
    required this.firstname,
    required this.lastname,
    required this.name,
    required this.email,
    required this.phone,
    required this.avatar,
    required this.requirement,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    String firstname = json['firstname']?.toString() ?? '';
    String lastname = json['lastname']?.toString() ?? '';
    final name = json['name']?.toString() ?? json['fullName']?.toString() ?? '';
    
    if (firstname.isEmpty && lastname.isEmpty && name.isNotEmpty) {
      final parts = name.trim().split(' ');
      if (parts.isNotEmpty) {
        firstname = parts.first;
        if (parts.length > 1) {
          lastname = parts.sublist(1).join(' ');
        }
      }
    }

    return UserProfile(
      id: json['id']?.toString() ?? '',
      userId: json['userId']?.toString() ?? '',
      firstname: firstname,
      lastname: lastname,
      name: name,
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      avatar: json['avatar']?.toString() ?? '',
      requirement: json['requirement']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'firstname': firstname,
      'lastname': lastname,
      'name': name,
      'email': email,
      'phone': phone,
      'avatar': avatar,
      'requirement': requirement,
    };
  }
}
