import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/api/api_constants.dart';
import '../core/api/api_endpoints.dart';

class TicketService {
  Future<Map<String, dynamic>?> raiseTicket({
    required String subject,
    required String category,
    required String description,
    String? attachmentPath,
  }) async {
    try {
      final uri = Uri.parse('${ApiConstants.baseUrl}${ApiEndpoints.tickets}');
      final request = http.MultipartRequest('POST', uri);

      request.headers['Accept'] = 'application/json';

      final prefs = await SharedPreferences.getInstance();
      final cookie = prefs.getString('session_cookie');
      final token = prefs.getString('auth_token');
      if (token != null && token.isNotEmpty) {
        request.headers['Cookie'] = 'session=$token; better-auth.session_token=$token';
      } else if (cookie != null && cookie.isNotEmpty) {
        request.headers['Cookie'] = cookie;
      }
      if (token != null && token.isNotEmpty) {
        request.headers['Authorization'] = 'Bearer $token';
      }

      request.fields.addAll({
        'subject': subject,
        'category': category,
        'description': description,
      });

      if (attachmentPath != null && attachmentPath.isNotEmpty) {
        String ext = attachmentPath.split('.').last.toLowerCase();
        MediaType? mediaType;
        if (ext == 'pdf') {
          mediaType = MediaType('application', 'pdf');
        } else if (ext == 'png') {
          mediaType = MediaType('image', 'png');
        } else {
          mediaType = MediaType('image', 'jpeg');
        }

        request.files.add(
          await http.MultipartFile.fromPath(
            'attachment', 
            attachmentPath,
            contentType: mediaType,
          ),
        );
      }

      print('APP LOG: Raise Ticket Request to -> $uri');
      print('APP LOG: Raise Ticket Fields -> ${request.fields}');

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      print('APP LOG: Raise Ticket Status Code -> ${response.statusCode}');
      print('APP LOG: Raise Ticket Body -> ${response.body}');

      if (response.statusCode < 200 || response.statusCode >= 300) {
        return null;
      }

      if (response.body.isEmpty) {
        return <String, dynamic>{};
      }

      final decoded = jsonDecode(response.body);
      if (decoded is Map<String, dynamic>) {
        final data = decoded['data'];
        if (data is Map<String, dynamic>) {
          return data;
        }
        return decoded;
      }
    } catch (e) {
      print('Raise ticket error: $e');
    }

    return null;
  }

  Future<List<dynamic>?> getTickets() async {
    try {
      final uri = Uri.parse('${ApiConstants.baseUrl}${ApiEndpoints.tickets}');
      
      final prefs = await SharedPreferences.getInstance();
      final cookie = prefs.getString('session_cookie');
      final token = prefs.getString('auth_token');
      
      final headers = <String, String>{'Accept': 'application/json'};
      if (token != null && token.isNotEmpty) {
        headers['Cookie'] = 'session=$token; better-auth.session_token=$token';
        headers['Authorization'] = 'Bearer $token';
      } else if (cookie != null && cookie.isNotEmpty) {
        headers['Cookie'] = cookie;
      }
      
      print('APP LOG: Get Tickets Request to -> $uri');
      final response = await http.get(uri, headers: headers);
      print('APP LOG: Get Tickets Status Code -> ${response.statusCode}');
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        final decoded = jsonDecode(response.body);
        if (decoded is Map<String, dynamic>) {
            final data = decoded['data'];
            if (data is List) {
                return data;
            } else if (data != null) {
                return [data];
            }
            return [decoded];
        } else if (decoded is List) {
            return decoded;
        }
      }
    } catch (e) {
      print('Get tickets error: $e');
    }
    return null;
  }
}
