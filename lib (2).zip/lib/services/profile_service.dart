import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http_parser/http_parser.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_constants.dart';
import '../../core/api/api_endpoints.dart';
import '../../core/api/api_exception.dart';
import '../models/user_profile.dart';

class ProfileService {
  Future<UserProfile?> getMyProfile() async {
    try {
      final response = await ApiService.to.get(ApiEndpoints.profileMe);
      if (response.data != null) {
        final data = response.data;
        if (data is Map<String, dynamic>) {
          if (data['success'] == true && data['data'] != null) {
            return UserProfile.fromJson(data['data']);
          }
        }
      }
    } catch (e) {
      print('Error getting profile: $e');
    }
    return null;
  }

  Future<UserProfile?> _multipartRequest({
    required String method,
    required String endpoint,
    required Map<String, String> fields,
    String? avatarPath,
    String? fileKey,
  }) async {
    try {
      final uri = Uri.parse('${ApiConstants.baseUrl}$endpoint');
      final request = http.MultipartRequest(method, uri);

      // Add default headers
      request.headers.addAll(ApiConstants.defaultHeaders);

      // Add auth token and cookie
      final prefs = await SharedPreferences.getInstance();
      final cookie = prefs.getString('session_cookie');
      final token = prefs.getString('auth_token');
      if (token != null && token.isNotEmpty) {
        request.headers['Cookie'] = 'session=$token; better-auth.session_token=$token';
      } else if (cookie != null && cookie.isNotEmpty) {
        request.headers['Cookie'] = cookie;
      }
      if (token != null && token.isNotEmpty) {
        request.headers['Authorization'] = 'Bearer $token';
      }

      // Add form fields
      request.fields.addAll(fields);

      // Add avatar file if available
      if (avatarPath != null && avatarPath.isNotEmpty) {
        final key = fileKey ?? 'avatar';
        final extension = avatarPath.split('.').last.toLowerCase();
        
        MediaType? contentType;
        if (extension == 'jpg' || extension == 'jpeg') {
          contentType = MediaType('image', 'jpeg');
        } else if (extension == 'png') {
          contentType = MediaType('image', 'png');
        } else if (extension == 'pdf') {
          contentType = MediaType('application', 'pdf');
        } else {
          // Fallback to jpeg
          contentType = MediaType('image', 'jpeg');
        }

        final filename = avatarPath.split('/').last;

        request.files.add(
          await http.MultipartFile.fromPath(
            key,
            avatarPath,
            filename: filename,
            contentType: contentType,
          ),
        );
      }

      print('APP LOG: Multipart $method Request to -> $uri');
      print('APP LOG: Multipart Request Fields -> $fields');
      print('APP LOG: Multipart Request Headers -> ${request.headers}');

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      print('APP LOG: Multipart Response Status Code -> ${response.statusCode}');
      print('APP LOG: Multipart Response Body -> ${response.body}');

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final jsonBody = jsonDecode(response.body);
        if (jsonBody != null && jsonBody['success'] == true) {
          final data = jsonBody['data'];
          if (data != null) {
            return UserProfile.fromJson(data);
          }
        }
      } else {
        print('Multipart request failed: ${response.statusCode} - ${response.body}');
        dynamic body;
        try {
          if (response.body.isNotEmpty) {
            body = jsonDecode(response.body);
          }
        } catch (_) {}

        String message = 'Failed to save profile';
        if (body is Map<String, dynamic>) {
          message = body['message'] ?? body['error'] ?? message;
        }

        throw ApiException(
          message: message,
          statusCode: response.statusCode,
          responseBody: body,
        );
      }
    } catch (e) {
      print('Multipart request error: $e');
      rethrow;
    }
    return null;
  }

  Future<UserProfile?> createProfile({
    required Map<String, String> fields,
    String? avatarPath,
  }) async {
    return _multipartRequest(
      method: 'POST',
      endpoint: ApiEndpoints.profileCreate,
      fields: fields,
      avatarPath: avatarPath,
      fileKey: 'avatar',
    );
  }

  Future<UserProfile?> updateProfile({
    required Map<String, String> fields,
    String? avatarPath,
  }) async {
    return _multipartRequest(
      method: 'POST',
      endpoint: ApiEndpoints.profileUpdate,
      fields: fields,
      avatarPath: avatarPath,
      fileKey: 'avatar',
    );
  }
}
