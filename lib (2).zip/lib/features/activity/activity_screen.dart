import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dotted_border/dotted_border.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../main_navigation_screen.dart';

class ActivityScreen extends StatelessWidget {
  const ActivityScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool canPop = Navigator.canPop(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16.h),
                  _buildOffersSection(),
                  SizedBox(height: 20.h),
                  _buildNotificationsSection(),
                  SizedBox(height: 32.h),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: canPop
          ? Container(
              height: 74.h,
              decoration: BoxDecoration(
                color: const Color(0xFFE6F7FD),
                border: Border(
                  top: BorderSide(color: Colors.grey.shade300, width: 1.0),
                ),
              ),
              child: BottomNavigationBar(
                currentIndex: 1,
                backgroundColor: const Color(0xFFE6F7FD),
                elevation: 0,
                type: BottomNavigationBarType.fixed,
                selectedItemColor: const Color(0xFF00ABE4),
                unselectedItemColor: Colors.grey,
                showUnselectedLabels: true,
                onTap: (index) {
                  final navState = context.findAncestorStateOfType<MainNavigationScreenState>();
                  if (navState != null) {
                    navState.setIndex(index);
                    Navigator.pop(context);
                  } else {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MainNavigationScreen(initialIndex: index),
                      ),
                      (route) => false,
                    );
                  }
                },
                items: const [
                  BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.favorite_border),
                    label: 'Activity',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.receipt_long_outlined),
                    label: 'Booking',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.person_outline),
                    label: 'Profile',
                  ),
                ],
              ),
            )
          : null,
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 16.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context);
              } else {
                final mainNav = context.findAncestorStateOfType<MainNavigationScreenState>();
                if (mainNav != null) {
                  mainNav.setIndex(0);
                } else {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const MainNavigationScreen(initialIndex: 0)),
                    (route) => false,
                  );
                }
              }
            },
            child: Container(
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                Icons.arrow_back_rounded,
                size: 18.sp,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Text(
              'Activity',
              style: AppFonts.h1.copyWith(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOffersSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Exclusive Offers for You',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              InkWell(
                onTap: () {},
                child: Row(
                  children: [
                    Text(
                      'View All',
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFF007BFF),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Icon(
                      Icons.chevron_right_rounded,
                      size: 16.sp,
                      color: const Color(0xFF007BFF),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 12.h),
        SizedBox(
          height: 185.h,
          child: ListView(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            scrollDirection: Axis.horizontal,
            physics: const ClampingScrollPhysics(),
            children: [
              _buildOfferCard(
                type: 'Ride Offer',
                discount: '20% OFF',
                description: 'On your next ride',
                code: 'RIDE20',
                imagePath: 'assets/images/on3.png',
                actionText: 'Book Now',
                bgColor: const Color(0xFFF0F5FF),
                textColor: const Color(0xFF007BFF),
                buttonColor: const Color(0xFF007BFF),
                gradientStart: const Color(0xFFE6F0FF),
              ),
              _buildOfferCard(
                type: 'Parcel Offer',
                discount: '15% OFF',
                description: 'On parcel booking',
                code: 'PARCEL15',
                imagePath: 'assets/images/on1.png',
                actionText: 'Send Now',
                bgColor: const Color(0xFFEAF8EC),
                textColor: const Color(0xFF28A745),
                buttonColor: const Color(0xFF28A745),
                gradientStart: const Color(0xFFDCF5DF),
              ),
              _buildOfferCard(
                type: 'Truck Offer',
                discount: '10% OFF',
                description: 'On truck booking',
                code: 'TRUCK10',
                imagePath: 'assets/images/truck.png',
                actionText: 'Book Now',
                bgColor: const Color(0xFFFFF3CD),
                textColor: const Color(0xFFFD7E14),
                buttonColor: const Color(0xFFFD7E14),
                gradientStart: const Color(0xFFFFF7DF),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOfferCard({
    required String type,
    required String discount,
    required String description,
    required String code,
    required String imagePath,
    required String actionText,
    required Color bgColor,
    required Color textColor,
    required Color buttonColor,
    required Color gradientStart,
  }) {
    return Container(
      width: 155.w,
      margin: EdgeInsets.only(right: 14.w, bottom: 12.h),
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [gradientStart, bgColor, Colors.white.withOpacity(0.9)],
          stops: const [0.0, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: Colors.white, width: 1.5.w),
        boxShadow: [
          BoxShadow(
            color: textColor.withOpacity(0.12),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                type,
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 10.sp,
                  fontWeight: FontWeight.bold,
                  color: textColor.withOpacity(0.8),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                decoration: BoxDecoration(
                  color: textColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(6.r),
                ),
                child: Text(
                  'HOT',
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 7.sp,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 4.h),
          Text(
            discount,
            style: TextStyle(
              fontFamily: AppFonts.fontFamily,
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: textColor,
              letterSpacing: -0.2,
            ),
          ),
          Text(
            description,
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: 10.5.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 6.h),
          DottedBorder(
            color: textColor.withOpacity(0.4),
            strokeWidth: 1,
            dashPattern: const [3, 3],
            borderType: BorderType.RRect,
            radius: Radius.circular(6.r),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
              alignment: Alignment.center,
              child: Text(
                'Code: $code',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 9.sp,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
            ),
          ),
          const Spacer(),
          Center(
            child: Image.asset(
              imagePath,
              height: 44.h,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return Icon(Icons.broken_image, size: 36.sp, color: Colors.grey);
              },
            ),
          ),
          const Spacer(),
          Container(
            padding: EdgeInsets.symmetric(vertical: 4.h, horizontal: 8.w),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.6),
              borderRadius: BorderRadius.circular(20.r),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  actionText,
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.bold,
                    color: buttonColor,
                  ),
                ),
                SizedBox(width: 2.w),
                Icon(
                  Icons.arrow_forward_rounded,
                  color: buttonColor,
                  size: 10.sp,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Notifications',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
              InkWell(
                onTap: () {},
                child: Text(
                  'Mark all as read',
                  style: TextStyle(
                    fontFamily: AppFonts.fontFamily,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF00ABE4),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 12.h),
        _buildNotificationTile(
          icon: Icons.check_circle_outline_rounded,
          iconColor: const Color(0xFF28A745),
          iconBgColor: const Color(0xFFEAF8EC),
          title: 'Ride Completed',
          subtitle: 'Your ride to Sector 62, Noida has been completed.',
          time: '10:30 AM',
          isUnread: true,
        ),
        _buildNotificationTile(
          icon: Icons.inventory_2_outlined,
          iconColor: const Color(0xFFFD7E14),
          iconBgColor: const Color(0xFFFFF3CD),
          title: 'Parcel Delivered',
          subtitle: 'Your parcel has been delivered successfully.',
          time: 'Yesterday, 07:15 PM',
          isUnread: true,
        ),
        _buildNotificationTile(
          icon: Icons.local_shipping_outlined,
          iconColor: const Color(0xFF6F42C1),
          iconBgColor: const Color(0xFFF1EAFF),
          title: 'Truck Booking Confirmed',
          subtitle: 'Your truck booking for 14 Jun 2026 is confirmed.',
          time: 'Yesterday, 03:40 PM',
          isUnread: true,
        ),
        _buildNotificationTile(
          icon: Icons.local_offer_outlined,
          iconColor: const Color(0xFF007BFF),
          iconBgColor: const Color(0xFFE8F1FF),
          title: 'Offer Unlocked!',
          subtitle: 'You have unlocked a 20% off on your next ride.',
          time: '12 Jun 2026, 11:20 AM',
          isUnread: false,
        ),
        _buildNotificationTile(
          icon: Icons.notifications_active_outlined,
          iconColor: const Color(0xFFFEBF06),
          iconBgColor: const Color(0xFFFFFBE6),
          title: 'Price Drop Alert',
          subtitle: 'Good news! Prices have dropped for your frequent route.',
          time: '11 Jun 2026, 09:10 AM',
          isUnread: false,
        ),
        SizedBox(height: 4.h),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: InkWell(
            onTap: () {},
            borderRadius: BorderRadius.circular(16.r),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 14.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.r),
                border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.3), width: 1.w),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'View All Notifications',
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 13.sp,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF00ABE4),
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Icon(
                    Icons.arrow_forward_rounded,
                    color: const Color(0xFF00ABE4),
                    size: 16.sp,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationTile({
    required IconData icon,
    required Color iconColor,
    required Color iconBgColor,
    required String title,
    required String subtitle,
    required String time,
    required bool isUnread,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: iconColor.withOpacity(0.4), width: 1.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: iconBgColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: iconColor.withOpacity(0.25),
                  blurRadius: 12,
                  spreadRadius: 1,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 20.sp,
            ),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontFamily: AppFonts.fontFamily,
                          fontSize: 13.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      time,
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade500,
                        fontSize: 10.5.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  subtitle,
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: 10.5.sp,
                    fontWeight: FontWeight.w600,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          if (isUnread) ...[
            SizedBox(width: 8.w),
            Padding(
              padding: EdgeInsets.only(top: 4.h),
              child: Container(
                width: 8.w,
                height: 8.w,
                decoration: BoxDecoration(
                  color: const Color(0xFF007BFF),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF007BFF).withOpacity(0.4),
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }


  Widget _buildDivider() {
    return Divider(
      height: 1,
      thickness: 1,
      color: Colors.grey.shade100,
      indent: 52.w,
    );
  }
}
