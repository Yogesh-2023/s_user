import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../constants/app_assets.dart';
import '../../constants/app_fonts.dart';
import 'cancel_ride_screen.dart';
import 'driver_chat_screen.dart';
import 'driver_tracking_screen.dart';
import '../../core/socket/socket_service.dart';
import '../../core/socket/socket_events.dart';
import '../main_navigation_screen.dart';

class DriverAssignedScreen extends StatefulWidget {
  final String tripId;
  final Map<String, dynamic>? driverData;

  const DriverAssignedScreen({
    super.key,
    required this.tripId,
    this.driverData,
  });

  @override
  State<DriverAssignedScreen> createState() => _DriverAssignedScreenState();
}

class _DriverAssignedScreenState extends State<DriverAssignedScreen> {
  GoogleMapController? _mapController;
  Position? _currentPosition;

  static const double _addressLabelFontSize = 11;
  static const double _addressValueFontSize = 12;
  static const FontWeight _addressLabelFontWeight = FontWeight.w600;
  static const FontWeight _addressValueFontWeight = FontWeight.w600;

  LatLng? _driverLocation;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
    _setupSocketListeners();
  }

  void _setupSocketListeners() {
    SocketService.to.listenTo(SocketEvents.driverLocation, (data) {
      if (!mounted) return;
      if (data is Map && data['lat'] != null && data['lng'] != null) {
        final lat = double.tryParse(data['lat'].toString());
        final lng = double.tryParse(data['lng'].toString());
        if (lat != null && lng != null) {
          setState(() {
            _driverLocation = LatLng(lat, lng);
          });
          _updateMapCamera();
        }
      }
    });

    SocketService.to.listenTo(SocketEvents.driverArrived, (data) {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DriverTrackingScreen(
            tripId: widget.tripId,
            driverData: widget.driverData,
            initialState: RideState.verifyOTP,
          ),
        ),
      );
    });

    SocketService.to.listenTo(SocketEvents.tripCancelled, (data) {
      if (!mounted) return;
      final payload = data is List ? (data.isNotEmpty ? data.first : {}) : data;
      final reason = payload?['message'] ?? 'Trip was cancelled by driver.';
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(reason),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const MainNavigationScreen()),
        (route) => false,
      );
    });
  }

  void _updateMapCamera() {
    if (_mapController == null) return;
    if (_currentPosition != null && _driverLocation != null) {
      double minLat = _currentPosition!.latitude < _driverLocation!.latitude ? _currentPosition!.latitude : _driverLocation!.latitude;
      double maxLat = _currentPosition!.latitude > _driverLocation!.latitude ? _currentPosition!.latitude : _driverLocation!.latitude;
      double minLng = _currentPosition!.longitude < _driverLocation!.longitude ? _currentPosition!.longitude : _driverLocation!.longitude;
      double maxLng = _currentPosition!.longitude > _driverLocation!.longitude ? _currentPosition!.longitude : _driverLocation!.longitude;
      
      LatLngBounds bounds = LatLngBounds(
        southwest: LatLng(minLat - 0.005, minLng - 0.005),
        northeast: LatLng(maxLat + 0.005, maxLng + 0.005),
      );
      _mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 50));
    }
  }

  @override
  void dispose() {
    SocketService.to.stopListening(SocketEvents.driverLocation);
    SocketService.to.stopListening(SocketEvents.driverArrived);
    SocketService.to.stopListening(SocketEvents.tripCancelled);
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      if (!mounted) return;
      setState(() {
        _currentPosition = position;
      });
      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 15,
          ),
        ),
      );
    } catch (e) {
      debugPrint("Error fetching location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: Stack(
        children: [
          // Background Map
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(28.7041, 77.1025), // Default to Delhi
                zoom: 15,
              ),
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              markers: {
                if (_currentPosition != null)
                  Marker(
                    markerId: const MarkerId('user_location'),
                    position: LatLng(
                      _currentPosition!.latitude,
                      _currentPosition!.longitude,
                    ),
                    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
                    infoWindow: const InfoWindow(title: 'Your Location'),
                  ),
                if (_driverLocation != null)
                  Marker(
                    markerId: const MarkerId('driver_vehicle'),
                    position: _driverLocation!,
                    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
                    infoWindow: const InfoWindow(title: 'Driver Location'),
                  ),
              },
              onMapCreated: (controller) {
                _mapController = controller;
                if (_currentPosition != null) {
                  _mapController?.animateCamera(
                    CameraUpdate.newCameraPosition(
                      CameraPosition(
                        target: LatLng(
                          _currentPosition!.latitude,
                          _currentPosition!.longitude,
                        ),
                        zoom: 15,
                      ),
                    ),
                  );
                }
              },
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 16.h,
            left: 20.w,
            child: _buildBackButton(context),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 94.h,
            left: 94.w,
            child: _buildDriverMapLabel(),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 64.h,
            right: 44.w,
            child: _buildOtpChip(widget.driverData?['rideStartOtp']?.toString() ?? '5824'),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: _buildBottomPanel(context),
          ),
        ],
      ),
    );
  }

  Widget _buildBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 36.w,
        height: 36.w,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Icon(Icons.arrow_back, color: Colors.black, size: 20.sp),
      ),
    );
  }

  Widget _buildDriverMapLabel() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.location_on, color: const Color(0xFF00ABE4), size: 30.sp),
        SizedBox(width: 6.w),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Driver',
                style: AppFonts.captionDark.copyWith(
                  color: Colors.black,
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              RichText(
                text: TextSpan(
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade600,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w500,
                  ),
                  children: [
                    const TextSpan(text: 'Arriving in '),
                    TextSpan(
                      text: '3 min',
                      style: AppFonts.captionDark.copyWith(
                        color: const Color(0xFF00ABE4),
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOtpChip(String otp) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(6.r),
      ),
      child: Column(
        children: [
          Text(
            'OTP',
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: 9.sp,
            ),
          ),
          Text(
            otp,
            style: AppFonts.bodyText.copyWith(
              color: Colors.black,
              fontSize: 12.sp,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomPanel(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.75,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(30.r)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, -6),
          ),
        ],
      ),
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          20.w,
          20.h,
          20.w,
          MediaQuery.of(context).padding.bottom + 16.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDriverInfo(widget.driverData),
            SizedBox(height: 16.h),
            _buildVehicleCard(widget.driverData),
            SizedBox(height: 16.h),
            _buildTripCard(context),
            SizedBox(height: 20.h),
            _buildPrimaryButton(
              label: 'Cancel Ride',
              color: const Color(0xFFF0FBFE),
              textColor: Colors.black,
              onPressed: () => _showCancelRideSheet(context),
            ),
          ],
        ),
      ),
    );
  }

  void _showCancelRideSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return Container(
          padding: EdgeInsets.fromLTRB(
            14.w,
            10.h,
            14.w,
            MediaQuery.of(sheetContext).padding.bottom + 16.h,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(20.r),
                ),
              ),
              SizedBox(height: 26.h),
              Text(
                'Cancel Ride?',
                style: AppFonts.h2.copyWith(
                  color: Colors.black,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 8.h),
              Text(
                'Driver has already been assigned.\nCancellation charges may apply.',
                textAlign: TextAlign.center,
                style: AppFonts.captionDark.copyWith(
                  color: Colors.grey.shade500,
                  fontSize: 12.sp,
                  height: 1.25,
                ),
              ),
              SizedBox(height: 28.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1F1),
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Colors.redAccent,
                      size: 22.sp,
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        'If you cancel now, a cancellation fee may be deducted from your payment',
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.black87,
                          fontSize: 11.sp,
                          height: 1.25,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 26.h),
              _buildSheetButton(
                label: 'Cancel Ride',
                color: const Color(0xFFFF2D2D),
                textColor: Colors.white,
                onPressed: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CancelRideScreen(tripId: widget.tripId),
                    ),
                  );
                },
              ),
              SizedBox(height: 10.h),
              _buildSheetButton(
                label: 'Keep Ride',
                color: const Color(0xFFF0FBFE),
                textColor: Colors.black,
                onPressed: () => Navigator.pop(sheetContext),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSheetButton({
    required String label,
    required Color color,
    required Color textColor,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 44.h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
        onPressed: onPressed,
        child: Text(
          label,
          style: AppFonts.buttonText.copyWith(
            color: textColor,
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildDriverInfo(Map<String, dynamic>? data) {
    final driver = data?['driver'] ?? {};
    final driverImage = driver['profileImage'] ?? driver['image'];
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12.r),
          child: driverImage != null && driverImage.toString().startsWith('http')
              ? Image.network(
                  driverImage,
                  width: 50.w,
                  height: 50.w,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Image.asset(AppAssets.profileImage, width: 50.w, height: 50.w, fit: BoxFit.cover),
                )
              : Image.asset(
                  AppAssets.profileImage,
                  width: 50.w,
                  height: 50.w,
                  fit: BoxFit.cover,
                ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      driver['name'] ?? 'Raj Kumar',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppFonts.h2.copyWith(
                        color: Colors.black,
                        fontSize: 17.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  _buildRatingChip(driver['rating']?.toString() ?? '3.8'),
                ],
              ),

              SizedBox(height: 3.h),
              Row(
                children: [
                  Icon(
                    Icons.verified,
                    color: const Color(0xFF00ABE4),
                    size: 14.sp,
                  ),
                  SizedBox(width: 4.w),
                  Text(
                    'Verified Driver',
                    style: AppFonts.captionDark.copyWith(
                      color: const Color(0xFF00ABE4),
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRatingChip(String rating) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 9.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7D6),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star, color: const Color(0xFFFFB300), size: 13.sp),
          SizedBox(width: 3.w),
          Text(
            rating,
            style: AppFonts.captionDark.copyWith(
              color: Colors.black,
              fontSize: 11.sp,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVehicleCard(Map<String, dynamic>? data) {
    final vehicle = data?['driver']?['vehicle'] ?? {};
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 52.w,
            height: 42.h,
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(8.r),
            ),
            padding: EdgeInsets.all(4.w),
            child: Image.asset(AppAssets.carImage, fit: BoxFit.contain),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  vehicle['vehicleName'] ?? 'SUV White',
                  style: AppFonts.h2.copyWith(
                    color: Colors.black,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  vehicle['vehicleNumber'] ?? 'DL 01 AB 123',
                  style: AppFonts.captionDark.copyWith(
                    color: const Color(0xFF404B5A),
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTripCard(BuildContext context) {
    return Column(
      children: [
        _buildRouteTimeline(widget.driverData),
        SizedBox(height: 12.h),
        _buildFarePaymentRow(widget.driverData),
        SizedBox(height: 12.h),
        Row(
          children: [
            _buildActionButton(
              Icons.phone,
              'Call',
              onTap: () => _callDriver(context),
            ),
            SizedBox(width: 8.w),
            _buildActionButton(
              Icons.chat_bubble_outline,
              'Chat',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DriverChatScreen(driverData: widget.driverData),
                  ),
                );
              },
            ),
            SizedBox(width: 8.w),
            _buildActionButton(
              Icons.share_outlined,
              'Share',
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sharing trip details...')),
                );
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRouteTimeline(Map<String, dynamic>? data) {
    final booking = data?['booking'] ?? {};
    final pickup = booking['pickup'] ?? {};
    final drop = booking['drop'] ?? {};
    final distanceKm = booking['distanceKm']?.toString() ?? '0.0';

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            SizedBox(height: 18.h),
            Icon(Icons.radio_button_checked, color: Colors.green, size: 18.sp),
            Container(width: 2.w, height: 32.h, color: const Color(0xFFD7DEE8)),
            Icon(
              Icons.location_on,
              color: const Color(0xFFB71C1C),
              size: 20.sp,
            ),
          ],
        ),
        SizedBox(width: 10.w),
        Expanded(
          child: Column(
            children: [
              _buildAddressBox(
                label: 'Pick-up Location',
                address: pickup['address'] ?? 'Loading...',
                distance: '',
              ),
              SizedBox(height: 10.h),
              _buildAddressBox(
                label: 'Your Destination',
                address: drop['address'] ?? 'Loading...',
                distance: '',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAddressBox({
    required String label,
    required String address,
    required String distance,
  }) {
    return Container(
      padding: EdgeInsets.fromLTRB(12.w, 9.h, 10.w, 9.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: _addressLabelFontSize.sp,
                    fontWeight: _addressLabelFontWeight,
                  ),
                ),
                SizedBox(height: 3.h),
                Text(
                  address,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.black,
                    fontSize: _addressValueFontSize.sp,
                    fontWeight: _addressValueFontWeight,
                  ),
                ),
              ],
            ),
          ),
          if (distance.isNotEmpty) ...[
            SizedBox(width: 8.w),
            Text(
              distance,
              style: AppFonts.captionDark.copyWith(
                color: const Color(0xFF7C8795),
                fontSize: 9.sp,
              ),
            ),
          ]
        ],
      ),
    );
  }

  Widget _buildFarePaymentRow(Map<String, dynamic>? data) {
    final booking = data?['booking'] ?? {};
    final fare = booking['totalFare']?.toString() ?? '0';
    final paymentMethod = booking['pickup']?['paymentMethod']?.toString() ?? 'Cash';

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
      decoration: BoxDecoration(
        color: const Color(0xFFF2FBFE),
        borderRadius: BorderRadius.circular(5.r),
        border: Border.all(color: const Color(0xFFD8F2FC)),
      ),
      child: Row(
        children: [
          Icon(
            Icons.currency_rupee,
            color: const Color(0xFF00ABE4),
            size: 21.sp,
          ),
          SizedBox(width: 8.w),
          Expanded(child: _buildInfoBlock('Fare', '₹$fare')),
          Container(width: 1.w, height: 28.h, color: const Color(0xFFD7EDF5)),
          SizedBox(width: 14.w),
          Icon(
            Icons.account_balance_wallet_outlined,
            color: const Color(0xFF00ABE4),
            size: 21.sp,
          ),
          SizedBox(width: 8.w),
          Expanded(child: _buildInfoBlock('Payment Method', paymentMethod)),
        ],
      ),
    );
  }

  Widget _buildInfoBlock(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppFonts.captionDark.copyWith(
            color: const Color(0xFF8390A0),
            fontSize: 10.sp,
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          value,
          style: AppFonts.h2.copyWith(
            color: Colors.black,
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Future<void> _callDriver(BuildContext context) async {
    final uri = Uri(scheme: 'tel', path: '9090909090');
    final didLaunch = await launchUrl(uri);

    if (!didLaunch && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to open phone dialer')),
      );
    }
  }

  Widget _buildActionButton(
    IconData icon,
    String label, {
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8.r),
          child: Container(
            height: 34.h,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8.r),
              border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 15.sp, color: const Color(0xFF7D8793)),
                SizedBox(width: 5.w),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppFonts.bodyText.copyWith(
                      color: const Color(0xFF7D8793),
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSafetyBanner() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: const Color(0xFFEAFBF1),
        borderRadius: BorderRadius.circular(6.r),
        border: Border.all(color: const Color(0xFF22C55E).withOpacity(0.2)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 12.r,
            backgroundColor: const Color(0xFF22C55E),
            child: Icon(Icons.verified, color: Colors.white, size: 14.sp),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Verified Driver',
                  style: AppFonts.h2.copyWith(
                    color: const Color(0xFF039855),
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  'Your safety is our priority. Emergency support is available 24x7',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppFonts.captionDark.copyWith(
                    color: const Color(0xFF8A95A3),
                    fontSize: 10.sp,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrimaryButton({
    required String label,
    required Color color,
    required Color textColor,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 44.h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
        onPressed: onPressed,
        child: Text(
          label,
          style: AppFonts.buttonText.copyWith(
            color: textColor,
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
