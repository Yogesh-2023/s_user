import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../main_navigation_screen.dart';
import '../home/home_screen.dart';

import '../../core/api/api_service.dart';

class CancelReason {
  final String text;
  final IconData icon;
  final Color iconColor;
  final Color iconBgColor;

  CancelReason({
    required this.text,
    required this.icon,
    required this.iconColor,
    required this.iconBgColor,
  });
}

class CancelRideScreen extends StatefulWidget {
  final String tripId;

  const CancelRideScreen({super.key, required this.tripId});

  @override
  State<CancelRideScreen> createState() => _CancelRideScreenState();
}

class _CancelRideScreenState extends State<CancelRideScreen> {
  int _selectedIndex = 0; // Default select the first one
  bool _isLoading = false;

  final List<CancelReason> _reasons = [
    CancelReason(
      text: 'Driver taking too long',
      icon: Icons.payments_outlined,
      iconColor: const Color(0xFF00BCD4),
      iconBgColor: const Color(0xFFE0F7FA),
    ),
    CancelReason(
      text: 'Changed my plan',
      icon: Icons.schedule,
      iconColor: const Color(0xFF3F51B5),
      iconBgColor: const Color(0xFFE8EAF6),
    ),
    CancelReason(
      text: 'Booking by mistake',
      icon: Icons.close,
      iconColor: const Color(0xFFFF9800),
      iconBgColor: const Color(0xFFFFF3E0),
    ),
    CancelReason(
      text: 'Fare too high',
      icon: Icons.currency_rupee,
      iconColor: const Color(0xFF9C27B0),
      iconBgColor: const Color(0xFFF3E5F5),
    ),
    CancelReason(
      text: 'Driver asked to cancel',
      icon: Icons.person_outline,
      iconColor: const Color(0xFFFF5722),
      iconBgColor: const Color(0xFFFBE9E7),
    ),
    CancelReason(
      text: 'Other (Please specify)',
      icon: Icons.more_horiz,
      iconColor: Colors.grey.shade700,
      iconBgColor: Colors.grey.shade200,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBlueBackground, // Top header background
      body: Column(
        children: [
          // Custom Header
          Padding(
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20.h,
              left: 20.w,
              right: 20.w,
              bottom: 20.h,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 20.r,
                    child: const Icon(Icons.arrow_back, color: Colors.black),
                  ),
                ),
                SizedBox(width: 16.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Why do you want to cancel?',
                        style: AppFonts.h1.copyWith(
                          fontSize: 20.sp,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        "We're sorry to see you go",
                        style: AppFonts.bodyText.copyWith(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Main Body
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
              ),
              child: ListView(
                padding: EdgeInsets.all(20.w),
                children: [
                  // Warning Box
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                      top: 13.h,
                      bottom: 13.h,
                      left: 16.w,
                      right: 16.w,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFDF2F2),
                      border: Border.all(
                        color: const Color(0xFFF0F0F0),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(15.r),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.info_outline,
                          color: Colors.red,
                          size: 20.sp,
                        ),
                        SizedBox(width: 10.w),
                        Expanded(
                          child: Text(
                            'Cancellation charges may apply as a driver has already been assigned.',
                            style: AppFonts.bodyText.copyWith(
                              fontSize: 12.sp,
                              color: const Color(0xFF333333),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 24.h),

                  // Title
                  Text(
                    'Please select a reason',
                    style: AppFonts.h2.copyWith(
                      fontSize: 16.sp,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 16.h),

                  // Reasons List
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _reasons.length,
                    separatorBuilder: (context, index) =>
                        SizedBox(height: 12.h),
                    itemBuilder: (context, index) {
                      final reason = _reasons[index];
                      final isSelected = _selectedIndex == index;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: 40.h,
                          padding: EdgeInsets.only(
                            top: 10.h,
                            right: 19.w,
                            bottom: 10.h,
                            left: 10.w,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFF00ABE4).withOpacity(0.05)
                                : Colors.white,
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF00ABE4)
                                  : const Color(0xFFF0F0F0),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(15.r),
                          ),
                          child: Row(
                            children: [
                              // Icon with background
                              CircleAvatar(
                                radius: 10.r,
                                backgroundColor: reason.iconBgColor,
                                child: Icon(
                                  reason.icon,
                                  size: 12.sp,
                                  color: reason.iconColor,
                                ),
                              ),
                              SizedBox(width: 10.w),
                              // Text
                              Expanded(
                                child: Text(
                                  reason.text,
                                  style: AppFonts.bodyText.copyWith(
                                    color: Colors.black87,
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.normal,
                                  ),
                                ),
                              ),
                              // Radio Button
                              Container(
                                width: 20.w,
                                height: 20.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: isSelected
                                        ? const Color(0xFF00ABE4)
                                        : Colors.grey.shade300,
                                    width: isSelected ? 5.w : 1.w,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 24.h),

                  // Additional Comment
                  RichText(
                    text: TextSpan(
                      text: 'Additional comment ',
                      style: AppFonts.h2.copyWith(
                        fontSize: 14.sp,
                        color: Colors.black,
                      ),
                      children: [
                        TextSpan(
                          text: '(optional)',
                          style: AppFonts.bodyText.copyWith(
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12.h),
                  Container(
                    height: 68.h,
                    padding: EdgeInsets.all(10.w),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        color: const Color(0xFFD7D7D7),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(10.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.18),
                          offset: const Offset(0, 3),
                          blurRadius: 4,
                          blurStyle: BlurStyle.inner,
                        ),
                      ],
                    ),
                    child: TextField(
                      maxLines: null,
                      style: AppFonts.bodyText.copyWith(color: Colors.black),
                      decoration: InputDecoration(
                        hintText: 'Tell us more...',
                        hintStyle: AppFonts.bodyText.copyWith(
                          color: Colors.grey.shade400,
                        ),
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                  SizedBox(height: 24.h),

                  // Feedback Info Box
                  Container(
                    padding: EdgeInsets.all(16.w),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF4F8FD),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          radius: 12.r,
                          backgroundColor: const Color(0xFFE6F7FD),
                          child: Icon(
                            Icons.verified,
                            color: const Color(0xFF00ABE4),
                            size: 14.sp,
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Expanded(
                          child: Text(
                            'Your feedback helps us improve our service.\nIt will not be shared with your driver.',
                            style: AppFonts.captionDark.copyWith(
                              color: Colors.black87,
                              fontWeight: FontWeight.normal,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 40.h), // Bottom padding for scroll
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        color: Colors.white,
        padding: EdgeInsets.only(
          top: 16.h,
          left: 20.w,
          right: 20.w,
          bottom: MediaQuery.of(context).padding.bottom > 0
              ? MediaQuery.of(context).padding.bottom
              : 20.h,
        ),
        child: SizedBox(
          width: double.infinity,
          height: 40.h,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00ABE4),
              padding: EdgeInsets.only(
                top: 12.h,
                bottom: 12.h,
                left: 10.w,
                right: 10.w,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.r),
              ),
            ),
            onPressed: _isLoading ? null : () => _cancelRide(),
            child: _isLoading 
                ? SizedBox(height: 20.h, width: 20.h, child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Text('Submit', style: AppFonts.buttonText),
          ),
        ),
      ),
    );
  }

  Future<void> _cancelRide() async {
    setState(() {
      _isLoading = true;
    });

    final reason = _reasons[_selectedIndex].text;

    try {
      final response = await ApiService.to.post(
        '/api/user/trips/${widget.tripId}/cancel',
        body: {'reason': reason},
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        _showCancelledDialog(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(response.data?['message'] ?? 'Failed to cancel ride')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('An error occurred while cancelling the ride')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showCancelledDialog(BuildContext context) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.r),
          ),
          child: Padding(
            padding: EdgeInsets.fromLTRB(20.w, 22.h, 20.w, 18.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 52.w,
                  height: 52.w,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFEBEE),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check_circle_outline,
                    color: Colors.redAccent,
                    size: 30.sp,
                  ),
                ),
                SizedBox(height: 14.h),
                Text(
                  'Ride Cancelled',
                  style: AppFonts.h2.copyWith(
                    color: Colors.black,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  'Your ride has been cancelled successfully.',
                  textAlign: TextAlign.center,
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.grey.shade600,
                    fontSize: 13.sp,
                    height: 1.3,
                  ),
                ),
                SizedBox(height: 20.h),
                SizedBox(
                  width: double.infinity,
                  height: 42.h,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00ABE4),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const MainNavigationScreen(),
                        ),
                        (route) => false,
                      );
                    },
                    child: Text('Go to Home', style: AppFonts.buttonText),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
