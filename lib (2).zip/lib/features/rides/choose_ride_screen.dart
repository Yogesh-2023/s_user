import 'dart:math' as math;
import 'dart:ui' as ui;
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../constants/api_keys.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import '../parcels/pickup_address_screen.dart';
import 'looking_for_ride_screen.dart';

class ChooseRideScreen extends StatefulWidget {
  final String? pickupAddress;
  final String? destinationAddress;

  const ChooseRideScreen({
    super.key,
    this.pickupAddress,
    this.destinationAddress,
  });

  @override
  State<ChooseRideScreen> createState() => _ChooseRideScreenState();
}

class _ChooseRideScreenState extends State<ChooseRideScreen> {
  static const double _addressLabelFontSize = 11;
  static const double _addressValueFontSize = 12;
  static const FontWeight _addressLabelFontWeight = FontWeight.w600;
  static const FontWeight _addressValueFontWeight = FontWeight.w600;

  int _selectedRideIndex = 0;
  GoogleMapController? _mapController;
  Position? _currentPosition;
  final Set<Marker> _markers = {};
  
  bool _isLoadingFares = true;
  List<dynamic> _fareEstimates = [];

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
    _fetchFareEstimates();
  }

  Future<LatLng?> _getLatLngFromAddress(String address) async {
    final String url =
        'https://maps.googleapis.com/maps/api/geocode/json?address=${Uri.encodeComponent(address)}&key=${ApiKeys.googleMapsKey}';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          final location = data['results'][0]['geometry']['location'];
          return LatLng(location['lat'], location['lng']);
        }
      }
    } catch (e) {
      debugPrint('Error geocoding address: $e');
    }
    return null;
  }

  Future<void> _fetchFareEstimates() async {
    setState(() {
      _isLoadingFares = true;
    });

    try {
      final pickupAddress = widget.pickupAddress;
      final dropAddress = widget.destinationAddress;

      if (pickupAddress == null || dropAddress == null) {
        setState(() {
          _isLoadingFares = false;
        });
        return;
      }

      final pickupLatLng = await _getLatLngFromAddress(pickupAddress);
      final dropLatLng = await _getLatLngFromAddress(dropAddress);

      if (pickupLatLng != null && dropLatLng != null) {
        final body = {
          "pickupLatitude": pickupLatLng.latitude,
          "pickupLongitude": pickupLatLng.longitude,
          "dropLatitude": dropLatLng.latitude,
          "dropLongitude": dropLatLng.longitude
        };

        final response = await ApiService.to.post(
          ApiEndpoints.fareEstimate,
          body: body,
        );

        if (response.data != null && response.data['carOptions'] != null) {
          final parentDuration = response.data['duration']?.toString() ?? '0';
          final options = response.data['carOptions'] as List;
          
          setState(() {
            _fareEstimates = options.map((option) {
              return {
                ...option,
                'parentDuration': parentDuration,
              };
            }).toList();
            _isLoadingFares = false;
          });
          return;
        }
      }
    } catch (e) {
      debugPrint('Error fetching fare estimates: $e');
    }

    setState(() {
      _isLoadingFares = false;
    });
  }

  Map<String, String> _selectedRideDetails() {
    final fallback = {'carType': 'CAB', 'carName': 'Cab', 'vehicleType': 'CAB'};

    if (_fareEstimates.isEmpty || _selectedRideIndex >= _fareEstimates.length) {
      return fallback;
    }

    final estimate = _fareEstimates[_selectedRideIndex];
    if (estimate is! Map) return fallback;

    String carName =
        (estimate['name'] ??
                estimate['carName'] ??
                estimate['carType'] ??
                estimate['vehicleType'] ??
                fallback['carName'])
            .toString();
    String carType =
        (estimate['carType'] ??
                estimate['vehicleType'] ??
                _toVehicleType(carName))
            .toString();
    String vehicleType =
        (estimate['vehicleType'] ??
                estimate['carType'] ??
                _toVehicleType(carName))
            .toString();

    String carNameVal = carName.toUpperCase();

    return {'carType': carType, 'carName': carNameVal, 'vehicleType': vehicleType};
  }

  String _toVehicleType(String value) {
    return value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]+'), '_');
  }

  Future<BitmapDescriptor> _getCarMarkerIcon() async {
    try {
      final ByteData data = await rootBundle.load('assets/images/car1.png');
      final ui.Codec codec = await ui.instantiateImageCodec(
        data.buffer.asUint8List(),
        targetWidth: 80, // Premium visible size matching aspect ratio
      );
      final ui.FrameInfo fi = await codec.getNextFrame();
      final ByteData? byteData = await fi.image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData != null) {
        return BitmapDescriptor.fromBytes(byteData.buffer.asUint8List());
      }
    } catch (e) {
      debugPrint("Error loading custom car marker asset: $e");
    }
    // Fallback in case of error
    return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure);
  }

  double _calculateBearing(LatLng from, LatLng to) {
    final double lat1 = from.latitude * (math.pi / 180.0);
    final double lon1 = from.longitude * (math.pi / 180.0);
    final double lat2 = to.latitude * (math.pi / 180.0);
    final double lon2 = to.longitude * (math.pi / 180.0);

    final double dLon = lon2 - lon1;

    final double y = math.sin(dLon) * math.cos(lat2);
    final double x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLon);

    final double radians = math.atan2(y, x);
    final double degrees = radians * (180.0 / math.pi);
    return (degrees + 360.0) % 360.0;
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      BitmapDescriptor carIcon = await _getCarMarkerIcon();

      setState(() {
        _currentPosition = position;
        final LatLng userLatLng = LatLng(position.latitude, position.longitude);

        final LatLng car1Pos = LatLng(
          position.latitude + 0.0018,
          position.longitude - 0.0018,
        );
        final LatLng car2Pos = LatLng(
          position.latitude + 0.0018,
          position.longitude + 0.0018,
        );
        final LatLng car3Pos = LatLng(
          position.latitude + 0.0005,
          position.longitude + 0.0022,
        );
        final LatLng car4Pos = LatLng(
          position.latitude - 0.0015,
          position.longitude + 0.0012,
        );
        final LatLng car5Pos = LatLng(
          position.latitude - 0.0018,
          position.longitude - 0.0018,
        );

        _markers.add(
          Marker(
            markerId: const MarkerId('car1'),
            position: car1Pos,
            icon: carIcon,
            rotation: _calculateBearing(car1Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car2'),
            position: car2Pos,
            icon: carIcon,
            rotation: _calculateBearing(car2Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car3'),
            position: car3Pos,
            icon: carIcon,
            rotation: _calculateBearing(car3Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car4'),
            position: car4Pos,
            icon: carIcon,
            rotation: _calculateBearing(car4Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car5'),
            position: car5Pos,
            icon: carIcon,
            rotation: _calculateBearing(car5Pos, userLatLng) + 90,
          ),
        );
      });

      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 15.5,
          ),
        ),
      );
    } catch (e) {
      debugPrint("Error fetching location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: Stack(
        children: [
          // Live Google Map
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(28.7041, 77.1025), // Default to Delhi
                zoom: 15.5,
              ),
              markers: _markers,
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              onMapCreated: (controller) {
                _mapController = controller;
                if (_currentPosition != null) {
                  _mapController?.animateCamera(
                    CameraUpdate.newCameraPosition(
                      CameraPosition(
                        target: LatLng(
                          _currentPosition!.latitude,
                          _currentPosition!.longitude,
                        ),
                        zoom: 15.5,
                      ),
                    ),
                  );
                }
              },
            ),
          ),

          // Top Floating Address Card
          Positioned(
            top: MediaQuery.of(context).padding.top + 20.h,
            left: 20.w,
            right: 20.w,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20.r),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Column(
                    children: [
                      Icon(
                        Icons.radio_button_checked,
                        color: Colors.green,
                        size: 26.sp,
                      ),
                      Container(
                        width: 1.5.w,
                        height: 42.h,
                        color: Colors.grey.shade300,
                      ),
                      Icon(Icons.location_on, color: Colors.red, size: 24.sp),
                    ],
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildAddressField(
                          label: 'Pick-up Location',
                          address:
                              widget.pickupAddress ??
                              'BSI Business Park H161 Noida Sector 63',
                        ),
                        SizedBox(height: 10.h),
                        _buildAddressField(
                          label: 'Your Destination',
                          address:
                              widget.destinationAddress ??
                              'A-3, District Centre, Saket, New Delhi, Delhi 110017',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Bottom Sheet
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(top: 12.h, bottom: 16.h),
                      width: 40.w,
                      height: 4.h,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                  ),

                  // Title
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Icon(
                            Icons.arrow_back,
                            color: Colors.black,
                            size: 24.sp,
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Text(
                          'Choose a Ride',
                          style: AppFonts.h1.copyWith(
                            fontSize: 20.sp,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16.h),

                  // Rides List
                  Flexible(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: 320.h),
                      child: _isLoadingFares 
                          ? const Center(child: CircularProgressIndicator(color: Color(0xFF00ABE4)))
                          : _fareEstimates.isEmpty
                              ? Center(
                                  child: Text(
                                    'No rides available at the moment.',
                                    style: AppFonts.bodyText,
                                  ),
                                )
                              : ListView.builder(
                                  shrinkWrap: true,
                                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                                  itemCount: _fareEstimates.length,
                                  itemBuilder: (context, index) {
                                    final estimate = _fareEstimates[index];
                                    String name = estimate['name']?.toString() ?? estimate['carType']?.toString() ?? 'CAB';
                                    if (name.toUpperCase() == 'AUTO') name = 'AUTO';
                                    final duration = estimate['parentDuration']?.toString() ?? '5';
                                    final fare = estimate['price']?.toString() ?? '0';
                                    
                                    return Padding(
                                      padding: EdgeInsets.only(bottom: 12.h),
                                      child: _buildRideCard(
                                        index: index,
                                        title: '$name',
                                        time: '$duration min away',
                                        dropTime: 'Available',
                                        price: '₹$fare',
                                        imagePath: 'assets/images/on3.png',
                                      ),
                                    );
                                  },
                                ),
                    ),
                  ),

                  // Payment Method
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 20.w,
                      vertical: 16.h,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8F9FA),
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                        bottom: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Payment Method',
                          style: AppFonts.h2.copyWith(
                            fontSize: 16.sp,
                            color: Colors.black,
                          ),
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.money,
                              color: Colors.grey.shade700,
                              size: 20.sp,
                            ),
                            SizedBox(width: 8.w),
                            Text(
                              'Cash',
                              style: AppFonts.bodyText.copyWith(
                                color: Colors.black,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Icon(Icons.arrow_drop_down, color: Colors.black),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Continue Button
                  Padding(
                    padding: EdgeInsets.all(20.w),
                    child: SizedBox(
                      width: double.infinity,
                      height: 50.h,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00ABE4),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.r),
                          ),
                        ),
                        onPressed: () async {
                          // Show loading dialog
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => const Center(
                              child: CircularProgressIndicator(
                                color: Color(0xFF00ABE4),
                              ),
                            ),
                          );

                          String? tripId;
                          try {
                            final pickupAddress = widget.pickupAddress;
                            final dropAddress = widget.destinationAddress;
                            final pickupLatLng = await _getLatLngFromAddress(pickupAddress ?? '');
                            final dropLatLng = await _getLatLngFromAddress(dropAddress ?? '');
                            final selectedRide = _selectedRideDetails();

                            final body = <String, dynamic>{
                              'pickupLocation': {
                                'address': pickupAddress ?? 'Delhi',
                                'latitude': pickupLatLng?.latitude ?? 28.6276,
                                'longitude': pickupLatLng?.longitude ?? 77.3820,
                              },
                              'dropLocation': {
                                'address': dropAddress ?? 'Delhi',
                                'latitude': dropLatLng?.latitude ?? 28.5244,
                                'longitude': dropLatLng?.longitude ?? 77.2173,
                              },
                              'carType': selectedRide['carType'],
                              'paymentMethod': 'CASH',
                            };

                            dynamic response;
                            int retries = 3;
                            while (retries > 0) {
                              try {
                                response = await ApiService.to.post(
                                  ApiEndpoints.bookRide,
                                  body: body,
                                ).timeout(const Duration(seconds: 10)); // Timeout for slow net
                                break;
                              } catch (e) {
                                retries--;
                                if (retries == 0) rethrow; // Throw to outer catch if all retries fail
                                await Future.delayed(const Duration(seconds: 2));
                              }
                            }

                            Navigator.pop(context); // Dismiss loading dialog

                            if (response?.data != null) {
                              final data = response.data is Map ? response.data['data'] : null;
                              if (data is Map) {
                                tripId = (data['id'] ?? data['bookingId'] ?? data['goodsBookingId'])?.toString();
                              } else if (response.data['tripId'] != null) {
                                tripId = response.data['tripId'].toString();
                              }
                            }

                            if (tripId == null) {
                              throw Exception('Invalid response format');
                            }
                          } catch (e) {
                            Navigator.pop(context); // Dismiss loading dialog
                            print('--- [ERROR] Book ride API failed: $e ---');
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Network is slow. Please try booking again.'),
                                backgroundColor: Color(0xFFDC3545),
                                duration: Duration(seconds: 3),
                              ),
                            );
                            return; // Stop here, do not navigate
                          }

                          if (!mounted) return;
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LookingForRideScreen(tripId: tripId!),
                            ),
                          );
                        },
                        child: Text('Continue', style: AppFonts.buttonText),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddressField({required String label, required String address}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppFonts.captionDark.copyWith(
              color: Colors.grey.shade500,
              fontSize: _addressLabelFontSize.sp,
              fontWeight: _addressLabelFontWeight,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            address,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.bodyText.copyWith(
              color: Colors.black,
              fontSize: _addressValueFontSize.sp,
              fontWeight: _addressValueFontWeight,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRideCard({
    required int index,
    required String title,
    required String time,
    required String dropTime,
    required String price,
    String? oldPrice,
    required String imagePath,
  }) {
    bool isSelected = _selectedRideIndex == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedRideIndex = index;
        });
      },
      child: Container(
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
          color: isSelected ? null : Colors.white,
          gradient: isSelected
              ? LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF00ABE4).withOpacity(0.10),
                    const Color(0xFF00ABE4).withOpacity(0.0),
                  ],
                )
              : null,
          border: Border.all(
            color: isSelected ? const Color(0xFF00ABE4) : Colors.grey.shade200,
            width: 1,
          ),
          borderRadius: BorderRadius.circular(16.r),
        ),
        child: Row(
          children: [
            // Car Image Placeholder Box
            Container(
              width: 60.w,
              height: 60.w,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF00ABE4).withOpacity(0.10),
                    const Color(0xFF00ABE4).withOpacity(0.0),
                  ],
                ),
                border: Border.all(
                  color: const Color(0xFF00ABE4).withOpacity(0.20),
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Padding(
                padding: EdgeInsets.all(8.w),
                child: Image.asset(
                  imagePath,
                  fit: BoxFit.contain,
                ), // Using onboarding image as car placeholder
              ),
            ),
            SizedBox(width: 16.w),
            // Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppFonts.h2.copyWith(
                      fontSize: 16.sp,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Row(
                    children: [
                      Text(
                        time,
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.grey.shade600,
                        ),
                      ),
                      Text(
                        ' • ',
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.grey.shade400,
                        ),
                      ),
                      Text(
                        dropTime,
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Price
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    if (oldPrice != null)
                      Icon(
                        Icons.local_offer,
                        color: const Color(0xFF00ABE4),
                        size: 14.sp,
                      ),
                    if (oldPrice != null) SizedBox(width: 4.w),
                    Text(
                      price,
                      style: AppFonts.h2.copyWith(
                        fontSize: 16.sp,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                if (oldPrice != null)
                  Text(
                    oldPrice,
                    style: AppFonts.captionDark.copyWith(
                      color: Colors.grey.shade500,
                      decoration: TextDecoration.lineThrough,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
