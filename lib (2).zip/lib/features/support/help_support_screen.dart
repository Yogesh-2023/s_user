import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../services/ticket_service.dart';
import 'raise_issue_screen.dart';
import 'ticket_chat_screen.dart';

class SupportTicket {
  final String id;
  final String title;
  final String description;
  final String category;
  final DateTime createdAt;
  String status;
  List<Map<String, dynamic>> messages;

  SupportTicket({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.createdAt,
    this.status = 'Open',
    required this.messages,
  });
}

class HelpSupportScreen extends StatefulWidget {
  const HelpSupportScreen({super.key});

  @override
  State<HelpSupportScreen> createState() => _HelpSupportScreenState();
}

class _HelpSupportScreenState extends State<HelpSupportScreen> {
  final Color themeColor = const Color(0xFF00ABE4); // DobelGo primary theme color (cyan)
  final Color lightThemeColor = const Color(0xFFE6F7FD); // DobelGo light theme color (cyan tint)
  
  final List<SupportTicket> _tickets = [];
  final TicketService _ticketService = TicketService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadTickets();
  }

  Future<void> _loadTickets() async {
    setState(() {
      _isLoading = true;
    });
    
    final List<SupportTicket> defaultTickets = [
      SupportTicket(
        id: '409b89a7',
        title: 'dhudurhdhdhd',
        description: 'shuddujdhdu',
        category: 'App Issues',
        createdAt: DateTime.now().subtract(Duration(minutes: 5)),
        status: 'Open',
        messages: [
          {
            'sender': 'user',
            'text': 'shuddujdhdu',
            'time': DateTime.now().subtract(Duration(minutes: 5)),
          }
        ],
      ),
      SupportTicket(
        id: 'b9ca93d2',
        title: 'Document Upload Issue',
        description: 'shuddhhdhdhdjdjdj',
        category: 'Other',
        createdAt: DateTime.now().subtract(Duration(minutes: 10)),
        status: 'Open',
        messages: [
          {
            'sender': 'user',
            'text': 'shuddhhdhdhdjdjdj',
            'time': DateTime.now().subtract(Duration(minutes: 10)),
          }
        ],
      ),
    ];

    try {
      List<dynamic>? apiTickets = await _ticketService.getTickets();
      if (apiTickets != null && apiTickets.isNotEmpty) {
        final mapped = apiTickets.map((item) {
          final ticketId = (item['id'] ?? item['_id'] ?? item['ticketId'] ?? '').toString();
          final title = (item['subject'] ?? item['title'] ?? '').toString();
          final description = (item['description'] ?? '').toString();
          final category = (item['category'] ?? 'General').toString();
          final status = (item['status'] ?? 'Open').toString();
          final createdAtStr = item['createdAt'];
          final createdAt = createdAtStr is String 
              ? DateTime.tryParse(createdAtStr) ?? DateTime.now()
              : DateTime.now();

          return SupportTicket(
            id: ticketId,
            title: title,
            description: description,
            category: category,
            createdAt: createdAt,
            status: status,
            messages: [
              {
                'sender': 'user',
                'text': description,
                'time': createdAt,
              }
            ],
          );
        }).toList();

        setState(() {
          _tickets.clear();
          _tickets.addAll(mapped);
          _isLoading = false;
        });
        return;
      }
    } catch (e) {
      print("=== HELP SUPPORT LOAD ERROR ===");
      print(e.toString());
    }

    setState(() {
      _tickets.clear();
      _tickets.addAll(defaultTickets);
      _isLoading = false;
    });
  }

  void _showTicketDetails(SupportTicket ticket) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TicketChatScreen(ticket: ticket),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE9EDF1),
      body: Column(
        children: [
          _buildHeaderSection(context),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16.h),
                  // Need Help Card
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [AppColors.primary.withOpacity(0.85), AppColors.primary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        // Decorative background circles
                        Positioned(
                          right: -20.w,
                          top: -20.h,
                          child: Container(
                            width: 100.w,
                            height: 100.w,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                        Positioned(
                          left: 40.w,
                          bottom: -30.h,
                          child: Container(
                            width: 80.w,
                            height: 80.w,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.08),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(16.w),
                          child: Row(
                          children: [
                            // Ticket Icon Container
                            Container(
                              width: 42.w,
                              height: 42.w,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.support_agent_rounded,
                                color: AppColors.primary,
                                size: 20.sp,
                              ),
                            ),
                            SizedBox(width: 12.w),

                            // Text content
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Need Help?',
                                    style: TextStyle(
                                      fontFamily: AppFonts.fontFamily,
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  SizedBox(height: 2.h),
                                  Text(
                                    'Raise a ticket to get assistance.',
                                    style: TextStyle(
                                      fontFamily: AppFonts.fontFamily,
                                      fontSize: 11.sp,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white.withOpacity(0.9),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Button
                            GestureDetector(
                              onTap: () async {
                                final result = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const RaiseIssueScreen(),
                                  ),
                                );
                                if (result != null && result is SupportTicket) {
                                  setState(() {
                                    _tickets.insert(0, result);
                                  });
                                  // Show success dialog
                                  showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          SizedBox(height: 10.h),
                                          Container(
                                            padding: EdgeInsets.all(12.w),
                                            decoration: const BoxDecoration(
                                              color: Color(0xFFE2F7EE),
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                              Icons.check_circle_rounded,
                                              color: Color(0xFF00B050),
                                              size: 50,
                                            ),
                                          ),
                                          SizedBox(height: 16.h),
                                          Text(
                                            'Ticket Created!',
                                            style: TextStyle(
                                              fontFamily: AppFonts.fontFamily,
                                              fontSize: 18.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.textPrimary,
                                            ),
                                          ),
                                          SizedBox(height: 8.h),
                                          Text(
                                            'Your ticket ID is ${result.id}. We will resolve your issue as soon as possible.',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontFamily: AppFonts.fontFamily,
                                              fontSize: 12.sp,
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                          SizedBox(height: 20.h),
                                          SizedBox(
                                            width: double.infinity,
                                            height: 44.h,
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: themeColor,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(12.r),
                                                ),
                                              ),
                                              onPressed: () => Navigator.pop(context),
                                              child: Text(
                                                'Okay',
                                                style: TextStyle(
                                                  fontFamily: AppFonts.fontFamily,
                                                  fontSize: 14.sp,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.1),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.add_circle_rounded,
                                      color: AppColors.primary,
                                      size: 16.sp,
                                    ),
                                    SizedBox(width: 4.w),
                                    Text(
                                      'New',
                                      style: TextStyle(
                                        fontFamily: AppFonts.fontFamily,
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w900,
                                        color: AppColors.primary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 24.h),

                // Tickets list or Placeholder
                _isLoading 
                    ? Center(child: Padding(padding: EdgeInsets.all(20.w), child: CircularProgressIndicator(color: themeColor)))
                    : _tickets.isEmpty ? _buildNoTicketsPlaceholder() : _buildTicketsList(),
              ],
            ),
          ),
        ),
      ],
      ),
    );
  }

  Widget _buildNoTicketsPlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: SizedBox(
            width: 120.w,
            height: 120.w,
            child: CustomPaint(
              painter: SupportAgentPainter(color: themeColor),
            ),
          ),
        ),
        SizedBox(height: 24.h),
        Text(
          'No tickets yet',
          style: TextStyle(
            fontFamily: AppFonts.fontFamily,
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildTicketsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 8.h),
          child: Row(
            children: [
              Icon(Icons.history_rounded, color: AppColors.primary, size: 20.sp),
              SizedBox(width: 8.w),
              Text(
                'Recent Tickets',
                style: TextStyle(
                  fontFamily: AppFonts.fontFamily,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFF1E293B),
                ),
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 24.h),
          itemCount: _tickets.length,
          itemBuilder: (context, index) {
            final ticket = _tickets[index];
            final String formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(ticket.createdAt);

            Color statusColor = ticket.status.toLowerCase() == 'open' ? Colors.orange : Colors.green;

            return Container(
              margin: EdgeInsets.only(bottom: 16.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20.r),
                border: Border.all(
                  color: AppColors.primary.withOpacity(0.08),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Padding(
                padding: EdgeInsets.all(16.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Top Row: ID & Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'ID: #${ticket.id.length > 6 ? ticket.id.substring(0, 6).toUpperCase() : ticket.id.toUpperCase()}',
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w900,
                            color: AppColors.primary,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8.r),
                          ),
                          child: Text(
                            ticket.status.toUpperCase(),
                            style: TextStyle(
                              fontFamily: AppFonts.fontFamily,
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w900,
                              color: statusColor,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12.h),

                    // Title
                    Text(
                      ticket.title,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF1E293B),
                      ),
                    ),
                    SizedBox(height: 6.h),

                    // Clock & Date Row
                    Row(
                      children: [
                        Icon(
                          Icons.access_time_rounded,
                          color: const Color(0xFF94A3B8),
                          size: 14.sp,
                        ),
                        SizedBox(width: 6.w),
                        Text(
                          formattedDate,
                          style: TextStyle(
                            fontFamily: AppFonts.fontFamily,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF94A3B8),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 14.h),

                    // Divider
                    Divider(height: 1, thickness: 1.5, color: Colors.grey.shade100),
                    SizedBox(height: 14.h),

                    // Description
                    Text(
                      ticket.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 13.sp,
                        color: const Color(0xFF64748B),
                        height: 1.4,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 18.h),

                    // Chat Now Button
                    GestureDetector(
                      onTap: () => _showTicketDetails(ticket),
                      child: Container(
                        width: double.infinity,
                        height: 40.h,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(5.w),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 4,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.chat_bubble_rounded,
                                color: AppColors.primary,
                                size: 12.sp,
                              ),
                            ),
                            SizedBox(width: 6.w),
                            Text(
                              'Chat Support',
                              style: TextStyle(
                                fontFamily: AppFonts.fontFamily,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w900,
                                color: AppColors.primary,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildHeaderSection(BuildContext context) {
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 20.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              InkWell(
                onTap: () => Navigator.maybePop(context),
                borderRadius: BorderRadius.circular(20.r),
                child: Container(
                  width: 40.w,
                  height: 40.w,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                    size: 20.sp,
                  ),
                ),
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Text(
                  'Help & Support',
                  style: AppFonts.h1.copyWith(
                    fontSize: 22.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SupportAgentPainter extends CustomPainter {
  final Color color;
  SupportAgentPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5.w
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    double cx = size.width / 2;
    double cy = size.height / 2;

    // Draw Headband (Arch)
    Rect headbandRect = Rect.fromCircle(center: Offset(cx, cy - 8.h), radius: 36.w);
    canvas.drawArc(headbandRect, -3.14, 3.14, false, paint);

    // Draw Hair outline (Outer curve)
    Path hairPath = Path();
    hairPath.moveTo(cx - 28.w, cy + 4.h);
    hairPath.cubicTo(cx - 28.w, cy - 20.h, cx + 28.w, cy - 20.h, cx + 28.w, cy + 4.h);
    canvas.drawPath(hairPath, paint);

    // Semicircle for bottom of the face / chin
    Rect faceRect = Rect.fromCircle(center: Offset(cx, cy + 4.h), radius: 20.w);
    canvas.drawArc(faceRect, 0, 3.14, false, paint);

    // Eyes (two small dots)
    canvas.drawCircle(Offset(cx - 7.w, cy + 2.h), 2.2.w, fillPaint);
    canvas.drawCircle(Offset(cx + 7.w, cy + 2.h), 2.2.w, fillPaint);

    // Earcups on sides of headband
    Rect leftEarcup = Rect.fromLTWH(cx - 40.w, cy - 10.h, 7.w, 20.h);
    canvas.drawRRect(RRect.fromRectAndRadius(leftEarcup, Radius.circular(4.r)), fillPaint);

    Rect rightEarcup = Rect.fromLTWH(cx + 33.w, cy - 10.h, 7.w, 20.h);
    canvas.drawRRect(RRect.fromRectAndRadius(rightEarcup, Radius.circular(4.r)), fillPaint);

    // Microphone stem
    Path micPath = Path();
    micPath.moveTo(cx + 33.w, cy + 4.h);
    micPath.quadraticBezierTo(cx + 28.w, cy + 18.h, cx + 8.w, cy + 16.h);
    canvas.drawPath(micPath, paint);

    // Microphone tip
    canvas.drawCircle(Offset(cx + 6.w, cy + 16.h), 3.2.w, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
