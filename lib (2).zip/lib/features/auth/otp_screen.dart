import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:smart_auth/smart_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../widgets/custom_button.dart';
import '../main_navigation_screen.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_exception.dart';
import '../../core/api/api_endpoints.dart';
import '../../core/socket/socket_service.dart';
import '../../core/utils.dart';
import '../../services/profile_service.dart';
import 'personal_information_screen.dart';

class OtpScreen extends StatefulWidget {
  final String phoneNumber;
  const OtpScreen({super.key, required this.phoneNumber});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  late List<FocusNode> _focusNodes;
  late List<TextEditingController> _controllers;
  final SmartAuth _smartAuth = SmartAuth.instance;
  bool _isListening = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _focusNodes = List.generate(4, (index) => FocusNode());
    _controllers = List.generate(4, (index) => TextEditingController());
    _listenForSms();
  }

  void _listenForSms() async {
    try {
      final res = await _smartAuth.getSmsWithUserConsentApi(matcher: r'\d{4}');
      if (res.hasData && res.data != null && res.data!.code != null) {
        String code = res.data!.code!;
        _fillAndVerifyOtp(code);
      }
    } catch (e) {
      debugPrint("Error listening for SMS: $e");
    } finally {
      if (mounted) {
        setState(() {
          _isListening = false;
        });
      }
    }
  }

  void _fillAndVerifyOtp(String otp) {
    if (otp.length >= 4) {
      for (int i = 0; i < 4; i++) {
        _controllers[i].text = otp[i];
      }
      _verifyAndContinue();
    }
  }

  void _verifyAndContinue() async {
    String otp = _controllers.map((c) => c.text).join();
    if (otp.length < 4) {
      AppUtils.showSnackBar(context, 'Please enter complete 4‑digit OTP', isError: true);
      return;
    }
    
    setState(() {
      _isLoading = true;
    });

    try {
      final response = await ApiService.to.post(
        '${ApiEndpoints.verifyOtp}user',
        body: {
          "identifier": widget.phoneNumber,
          "otp": otp,
          "type": "PHONE"
        },
      );
      
      AppUtils.printLog('Verify OTP Response: ${response.data}');
      if (response.data != null) {
        final data = response.data;
        String? token;
        if (data is Map) {
          if (data['sessionToken'] != null) {
            token = data['sessionToken'];
          } else if (data['token'] != null) {
            token = data['token'];
          } else if (data['accessToken'] != null) {
            token = data['accessToken'];
          } else if (data['data'] is Map) {
            final dataMap = data['data'];
            if (dataMap['sessionToken'] != null) {
              token = dataMap['sessionToken'];
            } else if (dataMap['token'] != null) {
              token = dataMap['token'];
            } else if (dataMap['accessToken'] != null) {
              token = dataMap['accessToken'];
            }
          }
        }
        if (token == null) {
          final prefs = await SharedPreferences.getInstance();
          token = prefs.getString('auth_token');
        }

        if (token != null) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('auth_token', token);
          await prefs.setString('user_phone', widget.phoneNumber);
          
          String? userId;
          if (data is Map) {
            final dynamic dataVal = data['data'];
            if (dataVal is Map) {
              userId = (dataVal['userId'] ?? dataVal['id'] ?? dataVal['user']?['id'] ?? dataVal['user']?['userId'])?.toString();
            }
            userId ??= (data['userId'] ?? data['id'] ?? data['user']?['id'] ?? data['user']?['userId'])?.toString();
          }
          
          if (userId != null) {
            await prefs.setString('user_id', userId);
            AppUtils.printLog('Saved User ID: $userId');
            SocketService.to.initSocket(sessionToken: token, userId: userId);
          } else {
            AppUtils.printLog('Warning: No userId found in verification response');
          }
          
          AppUtils.printLog('Saved Auth Token: $token and Phone: ${widget.phoneNumber}');
        } else {
          AppUtils.printLog('No token found in response data or SharedPreferences');
        }

        if (mounted) {
          bool isProfileComplete = false;
          if (data is Map) {
            isProfileComplete = data['isProfileComplete'] == true ||
                (data['user'] is Map && data['user']['isProfileComplete'] == true) ||
                (data['data'] is Map && data['data']['isProfileComplete'] == true) ||
                (data['data'] is Map && data['data']['user'] is Map && data['data']['user']['isProfileComplete'] == true);
          }
          
          if (isProfileComplete) {
            AppUtils.showSnackBar(context, 'Logged in successfully');
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const MainNavigationScreen()),
              (route) => false,
            );
          } else {
            AppUtils.showSnackBar(context, 'Verification successful');
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const PersonalInformationScreen()),
              (route) => false,
            );
          }
        }
      }
    } catch (e) {
      AppUtils.printLog('Verify OTP Error: $e');
      if (mounted) {
        String errorMessage = 'Wrong OTP! Please check the code and try again.';
        final errStr = e.toString();
        
        if (e is ApiException) {
          errorMessage = e.message;
        } else {
          errorMessage = errStr;
        }
        
        if (errorMessage.toLowerCase().contains('otp') || 
            errorMessage.toLowerCase().contains('invalid') ||
            errStr.contains('400') || 
            errStr.contains('401')) {
          errorMessage = 'Wrong OTP! Please check the code and try again.';
        }
        
        AppUtils.showSnackBar(context, errorMessage, isError: true);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    for (var node in _focusNodes) {
      node.dispose();
    }
    for (var controller in _controllers) {
      controller.dispose();
    }
    _smartAuth.removeUserConsentApiListener();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.h),
                // Back Button
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40.w,
                    height: 40.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.authButtonBorder),
                      color: AppColors.white,
                    ),
                    child: Icon(
                      Icons.arrow_back,
                      size: 20.sp,
                      color: AppColors.black,
                    ),
                  ),
                ),
                SizedBox(height: 30.h),

                // Titles
                Text(
                  'Verify Phone Number',
                  style: AppFonts.h1.copyWith(
                    fontSize: 24.sp,
                    color: AppColors.black,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "We've sent an SMS with an activation code to your phone",
                  style: AppFonts.captionDark,
                ),
                if (_isListening) ...[
                  SizedBox(height: 16.h),
                  Row(
                    children: [
                      SizedBox(
                        width: 16.w,
                        height: 16.w,
                        child: const CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Color(0xFF00A2E8),
                          ),
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Text(
                        "Waiting for SMS...",
                        style: AppFonts.captionDark.copyWith(
                          color: const Color(0xFF00A2E8),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
                SizedBox(height: 30.h),

                // OTP Input Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(7, (index) {
                    if (index.isOdd) return SizedBox(width: 8.w);
                    return _buildOtpBox(index ~/ 2, context);
                  }),
                ),

                SizedBox(height: 30.h),

                // Resend text
                Center(
                  child: RichText(
                    text: TextSpan(
                      style: AppFonts.captionDark,
                      children: [
                        const TextSpan(text: "Didn't receive code? "),
                        TextSpan(
                          text: 'Resend again',
                          style: AppFonts.linkText,
                          recognizer: TapGestureRecognizer()..onTap = () {},
                        ),
                      ],
                    ),
                  ),
                ),

                const Spacer(),

                CustomButton(
                  text: _isLoading ? 'Verifying...' : 'Verify & Continue',
                  color: const Color(0xFF00A2E8),
                  onPressed: _isLoading ? null : _verifyAndContinue,
                ),
                SizedBox(height: 24.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOtpBox(int index, BuildContext context) {
    return Container(
      width: 56.w,
      height: 56.w,
      decoration: BoxDecoration(
        color: const Color(0xFFEFF1F4), // Match driver app's field color
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: RawKeyboardListener(
        focusNode: FocusNode(),
        onKey: (event) {
          if (event.runtimeType.toString() == 'RawKeyDownEvent' && 
              event.logicalKey == LogicalKeyboardKey.backspace) {
            if (_controllers[index].text.isEmpty && index > 0) {
              FocusScope.of(context).requestFocus(_focusNodes[index - 1]);
            }
          }
        },
        child: Center(
          child: TextField(
            controller: _controllers[index],
            focusNode: _focusNodes[index],
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            textAlignVertical: TextAlignVertical.center,
            style: AppFonts.h2.copyWith(color: AppColors.black, fontSize: 24.sp),
            inputFormatters: [
              LengthLimitingTextInputFormatter(1),
              FilteringTextInputFormatter.digitsOnly,
            ],
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
              isDense: true,
            ),
            onChanged: (value) {
              if (value.isNotEmpty && index < 3) {
                FocusScope.of(context).requestFocus(_focusNodes[index + 1]);
              } else if (value.isEmpty && index > 0) {
                FocusScope.of(context).requestFocus(_focusNodes[index - 1]);
              } else if (index == 3) {
                FocusScope.of(context).unfocus();
                if (value.isNotEmpty) {
                  _verifyAndContinue();
                }
              }
            },
          ),
        ),
      ),
    );
  }
}
