import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../models/user_profile.dart';
import '../../services/profile_service.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import '../../core/api/api_exception.dart';
import '../../core/utils.dart';
import 'package:flutter/services.dart';

class ProfileEditScreen extends StatefulWidget {
  final UserProfile? profile;
  const ProfileEditScreen({Key? key, this.profile}) : super(key: key);

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final ProfileService _service = ProfileService();
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _firstCtrl;
  late TextEditingController _lastCtrl;
  String _requirement = 'PERSONAL';
  String _originalPhone = '';
  XFile? _selectedImage;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;
  bool _isSendingOtp = false;

  @override
  void initState() {
    super.initState();
    final p = widget.profile;
    final fullName = p?.name?.isNotEmpty == true ? p!.name : [p?.firstname ?? '', p?.lastname ?? ''].join(' ').trim();
    _nameCtrl = TextEditingController(text: fullName);
    _emailCtrl = TextEditingController(text: p?.email ?? '');
    
    String initialPhone = p?.phone ?? '';
    if (initialPhone.startsWith('+91')) {
      initialPhone = initialPhone.substring(3);
    } else if (initialPhone.startsWith('91') && initialPhone.length > 10) {
      initialPhone = initialPhone.substring(2);
    }
    _phoneCtrl = TextEditingController(text: initialPhone);
    _originalPhone = initialPhone;

    _firstCtrl = TextEditingController(text: p?.firstname ?? '');
    _lastCtrl = TextEditingController(text: p?.lastname ?? '');
    
    if (p != null && p.requirement.isNotEmpty) {
      _requirement = p.requirement.toUpperCase();
    }
    if (p == null) {
      _loadSavedPhone();
    }
    _phoneCtrl.addListener(() {
      setState(() {});
    });
  }

  Future<void> _loadSavedPhone() async {
    final prefs = await SharedPreferences.getInstance();
    final phone = prefs.getString('user_phone') ?? '';
    if (phone.isNotEmpty) {
      String sanitized = phone.trim();
      if (sanitized.startsWith('+91')) {
        sanitized = sanitized.substring(3);
      } else if (sanitized.startsWith('91') && sanitized.length > 10) {
        sanitized = sanitized.substring(2);
      }
      setState(() {
        _phoneCtrl.text = sanitized;
      });
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _firstCtrl.dispose();
    _lastCtrl.dispose();
    super.dispose();
  }

  void _showImageSourceBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        ),
        padding: EdgeInsets.only(
          top: 14.h,
          left: 20.w,
          right: 20.w,
          bottom: 24.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10.r),
                ),
              ),
            ),
            SizedBox(height: 20.h),
            Text(
              'Select Profile Picture',
              style: TextStyle(
                fontFamily: AppFonts.fontFamily,
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 24.h),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      _pickImage(ImageSource.camera);
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 20.h),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8F9FA),
                        borderRadius: BorderRadius.circular(16.r),
                        border: Border.all(color: Colors.grey.shade100),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.camera_alt_rounded,
                            color: const Color(0xFF00ABE4),
                            size: 32.sp,
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            'Camera',
                            style: TextStyle(
                              fontFamily: AppFonts.fontFamily,
                              fontSize: 13.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 16.w),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      _pickImage(ImageSource.gallery);
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 20.h),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8F9FA),
                        borderRadius: BorderRadius.circular(16.r),
                        border: Border.all(color: Colors.grey.shade100),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.photo_library_rounded,
                            color: const Color(0xFF00ABE4),
                            size: 32.sp,
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            'Gallery',
                            style: TextStyle(
                              fontFamily: AppFonts.fontFamily,
                              fontSize: 13.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    final img = await _picker.pickImage(source: source, imageQuality: 80);
    if (img != null) {
      setState(() {
        _selectedImage = img;
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    final fullName = _nameCtrl.text.trim();
    final parts = fullName.split(' ');
    final first = parts.isNotEmpty ? parts.first : '';
    final last = parts.length > 1 ? parts.sublist(1).join(' ') : '';

    final newPhone = _phoneCtrl.text.trim();
    final formattedPhone = newPhone.startsWith('+') ? newPhone : '+91$newPhone';

    final Map<String, String> fields = {
      'name': fullName,
      'email': _emailCtrl.text.trim(),
      'phone': formattedPhone,
      'firstname': first,
      'lastname': last,
      'requirement': _requirement,
    };

    if (newPhone != _originalPhone && newPhone.isNotEmpty) {
      AppUtils.showSnackBar(context, 'Please verify your new phone number first.', isError: true);
      setState(() => _isLoading = false);
      return;
    }
    _performSave(fields);
  }

  Future<void> _verifyPhone() async {
    final newPhone = _phoneCtrl.text.trim();
    if (newPhone.isEmpty) return;
    setState(() => _isSendingOtp = true);
    final formattedPhone = newPhone.startsWith('+') ? newPhone : '+91$newPhone';
    
    try {
      final response = await ApiService.to.post(
        ApiEndpoints.sendOtp,
        body: {
          "identifier": formattedPhone,
          "type": "PHONE"
        },
      );
      setState(() => _isSendingOtp = false);
      if (response.statusCode == 200 || response.statusCode == 201) {
        _showOTPBottomSheet(formattedPhone);
      }
    } catch (e) {
      setState(() => _isSendingOtp = false);
      AppUtils.showSnackBar(context, 'Failed to send OTP', isError: true);
    }
  }

  Future<void> _showOTPBottomSheet(String newPhone) async {
    final List<FocusNode> focusNodes = List.generate(4, (index) => FocusNode());
    final List<TextEditingController> controllers = List.generate(4, (index) => TextEditingController());
    bool isVerifying = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: 24.w,
                right: 24.w,
                top: 24.h,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Verify Phone Number',
                    style: AppFonts.h1.copyWith(fontSize: 20.sp),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'We sent an OTP to $newPhone',
                    style: AppFonts.captionDark,
                  ),
                  SizedBox(height: 24.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(7, (index) {
                      if (index.isOdd) return SizedBox(width: 8.w);
                      final boxIndex = index ~/ 2;
                      return Container(
                        width: 56.w,
                        height: 56.w,
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF1F4),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: RawKeyboardListener(
                          focusNode: FocusNode(),
                          onKey: (event) {
                            if (event.runtimeType.toString() == 'RawKeyDownEvent' && 
                                event.logicalKey == LogicalKeyboardKey.backspace) {
                              if (controllers[boxIndex].text.isEmpty && boxIndex > 0) {
                                FocusScope.of(context).requestFocus(focusNodes[boxIndex - 1]);
                              }
                            }
                          },
                          child: TextField(
                            controller: controllers[boxIndex],
                            focusNode: focusNodes[boxIndex],
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            style: AppFonts.h2.copyWith(color: AppColors.textPrimary, fontSize: 24.sp),
                            inputFormatters: [
                              LengthLimitingTextInputFormatter(1),
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            decoration: const InputDecoration(border: InputBorder.none),
                            onChanged: (value) {
                              if (value.isNotEmpty && boxIndex < 3) {
                                FocusScope.of(context).requestFocus(focusNodes[boxIndex + 1]);
                              } else if (value.isEmpty && boxIndex > 0) {
                                FocusScope.of(context).requestFocus(focusNodes[boxIndex - 1]);
                              } else if (boxIndex == 3 && value.isNotEmpty) {
                                FocusScope.of(context).unfocus();
                              }
                            },
                          ),
                        ),
                      );
                    }),
                  ),
                  SizedBox(height: 24.h),
                  SizedBox(
                    width: double.infinity,
                    height: 50.h,
                    child: ElevatedButton(
                      onPressed: isVerifying
                          ? null
                          : () async {
                              final otp = controllers.map((c) => c.text).join();
                              if (otp.length < 4) return;
                              setSheetState(() => isVerifying = true);
                              try {
                                final response = await ApiService.to.post(
                                  ApiEndpoints.verifyOtp,
                                  body: {
                                    "identifier": newPhone,
                                    "otp": otp,
                                    "type": "PHONE"
                                  },
                                );
                                if (response.statusCode == 200 || response.statusCode == 201) {
                                  Navigator.pop(context, true); // Success
                                }
                              } catch (e) {
                                AppUtils.showSnackBar(context, 'Invalid OTP', isError: true);
                                setSheetState(() => isVerifying = false);
                              }
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF00ABE4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                      ),
                      child: isVerifying
                          ? const CircularProgressIndicator(color: Colors.white)
                          : Text(
                              'Verify & Save',
                              style: AppFonts.buttonText.copyWith(color: Colors.white),
                            ),
                    ),
                  ),
                  SizedBox(height: 24.h),
                ],
              ),
            );
          },
        );
      },
    ).then((verified) {
      for (var node in focusNodes) {
        node.dispose();
      }
      for (var controller in controllers) {
        controller.dispose();
      }
      if (verified == true) {
        setState(() {
          _originalPhone = _phoneCtrl.text.trim();
        });
        AppUtils.showSnackBar(context, 'Phone number verified successfully.');
      }
    });
  }

  Future<void> _performSave(Map<String, String> fields) async {
    try {
      UserProfile? result;
      if (widget.profile == null) {
        result = await _service.createProfile(
          fields: fields,
          avatarPath: _selectedImage?.path,
        );
      } else {
        result = await _service.updateProfile(
          fields: fields,
          avatarPath: _selectedImage?.path,
        );
      }
      
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        if (result != null) {
          Navigator.pop(context, result);
        } else {
          AppUtils.showSnackBar(context, 'Failed to save profile', isError: true);
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        String errorMessage = e is ApiException ? e.message : e.toString().replaceAll('ApiException:', '').trim();
        AppUtils.showSnackBar(context, errorMessage, isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditMode = widget.profile != null;
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          top: false,
          child: Column(
          children: [
            _buildHeader(context, isEditMode),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Avatar Picker
                      GestureDetector(
                        onTap: _showImageSourceBottomSheet,
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFF00ABE4), width: 3),
                            ),
                            child: CircleAvatar(
                              radius: 55.r,
                              backgroundColor: Colors.grey.shade200,
                              backgroundImage: _selectedImage != null
                                  ? FileImage(File(_selectedImage!.path))
                                  : (widget.profile?.avatar.isNotEmpty ?? false)
                                      ? NetworkImage(widget.profile!.avatar) as ImageProvider
                                      : const AssetImage('assets/images/profile.png'),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            right: 4,
                            child: Container(
                              padding: EdgeInsets.all(6.w),
                              decoration: const BoxDecoration(
                                color: Color(0xFF00ABE4),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                                size: 18.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),

                    _buildField(
                      label: 'Full Name',
                      controller: _nameCtrl,
                      hintText: 'Enter your full name',
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Full Name is required';
                        if (v.trim().length < 3) return 'Name must be at least 3 characters long';
                        return null;
                      },
                      textCapitalization: TextCapitalization.words,
                    ),
                    _buildField(
                      label: 'Email Address',
                      controller: _emailCtrl,
                      hintText: 'Enter your email address',
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Email is required';
                        final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
                        if (!emailRegex.hasMatch(v.trim())) return 'Enter a valid email address';
                        return null;
                      },
                    ),
                    _buildField(
                      label: 'Phone Number',
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Phone number is required';
                        if (v.trim().length != 10) return 'Enter a valid 10-digit number';
                        return null;
                      },
                      readOnly: false,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(10),
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      suffixIcon: _phoneCtrl.text.trim() != _originalPhone && _phoneCtrl.text.trim().isNotEmpty && _phoneCtrl.text.trim().length == 10
                          ? (_isSendingOtp 
                              ? const SizedBox(
                                  width: 20, 
                                  height: 20, 
                                  child: Padding(
                                    padding: EdgeInsets.all(12.0),
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF00ABE4)),
                                  ),
                                )
                              : TextButton(
                                  onPressed: _verifyPhone,
                                  child: Text(
                                    'Verify',
                                    style: AppFonts.bodyText.copyWith(
                                      color: const Color(0xFF00ABE4),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ))
                          : null,
                    ),
                    // Requirement Dropdown
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 8.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Requirement Type',
                            style: AppFonts.captionDark.copyWith(
                              color: AppColors.textSecondary,
                              fontSize: 12.sp,
                            ),
                          ),
                          SizedBox(height: 6.h),
                           DropdownButtonFormField<String>(
                             value: _requirement,
                             dropdownColor: Colors.white,
                             iconEnabledColor: Colors.black,
                             style: TextStyle(
                               color: Colors.black,
                               fontSize: 14.sp,
                               fontWeight: FontWeight.w600,
                             ),
                             decoration: InputDecoration(
                               filled: true,
                               fillColor: AppColors.textFieldBackground,
                               contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                               border: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: BorderSide(color: AppColors.authButtonBorder),
                               ),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: BorderSide(color: AppColors.authButtonBorder),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.circular(12.r),
                                 borderSide: const BorderSide(color: Color(0xFF00ABE4)),
                               ),
                             ),
                             items: [
                               DropdownMenuItem(
                                 value: 'PERSONAL',
                                 child: Text(
                                   'Personal',
                                   style: TextStyle(
                                     color: Colors.black,
                                     fontSize: 14.sp,
                                     fontWeight: FontWeight.w600,
                                   ),
                                 ),
                               ),
                               DropdownMenuItem(
                                 value: 'BUSINESS',
                                 child: Text(
                                   'Business',
                                   style: TextStyle(
                                     color: Colors.black,
                                     fontSize: 14.sp,
                                     fontWeight: FontWeight.w600,
                                   ),
                                 ),
                               ),
                             ],
                             onChanged: (val) {
                               if (val != null) {
                                 setState(() {
                                   _requirement = val;
                                 });
                               }
                             },
                           ),
                        ],
                      ),
                    ),

                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 24.w, right: 24.w, bottom: 20.h, top: 12.h),
            child: SizedBox(
              width: double.infinity,
              height: 52.h,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00ABE4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  elevation: 0,
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(
                        isEditMode ? 'Update Profile' : 'Create Profile',
                        style: AppFonts.buttonText.copyWith(color: Colors.white),
                      ),
              ),
            ),
          ),
        ],
      ),
    ),
  ),
);
}

  Widget _buildHeader(BuildContext context, bool isEditMode) {
    final canPop = Navigator.canPop(context);
    return Container(
      color: const Color(0xFFE6F7FD),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 16.h,
        bottom: 20.h,
        left: 20.w,
        right: 20.w,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (canPop) ...[
                InkWell(
                  onTap: () => Navigator.pop(context),
                  borderRadius: BorderRadius.circular(20.r),
                  child: Container(
                    width: 40.w,
                    height: 40.w,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Icon(Icons.arrow_back, size: 20.sp, color: Colors.black),
                  ),
                ),
                SizedBox(width: 16.w),
              ],
              Expanded(
                child: Text(
                  isEditMode ? 'Edit Profile' : 'Create Profile',
                  style: AppFonts.h1.copyWith(
                    fontSize: 22.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Padding(
            padding: EdgeInsets.only(left: canPop ? 56.w : 0),
            child: Text(
              isEditMode 
                  ? 'Update your personal profile details.' 
                  : 'Please fill in your details to create a profile.',
              style: AppFonts.bodyText.copyWith(
                fontSize: 13.sp,
                color: Colors.grey.shade600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField({
    required String label,
    required TextEditingController controller,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    bool readOnly = false,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    Widget? suffixIcon,
    String? hintText,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppFonts.captionDark.copyWith(
              color: AppColors.textSecondary,
              fontSize: 12.sp,
            ),
          ),
          SizedBox(height: 6.h),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            validator: validator,
            readOnly: readOnly,
            inputFormatters: inputFormatters,
            textCapitalization: textCapitalization,
            style: AppFonts.bodyText.copyWith(
              color: readOnly ? Colors.grey : AppColors.textPrimary,
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: AppFonts.bodyText.copyWith(color: Colors.grey.shade400, fontSize: 14.sp),
              suffixIcon: suffixIcon,
              errorStyle: const TextStyle(height: 1, fontSize: 12),
              errorMaxLines: 2,
              filled: true,
              fillColor: readOnly ? Colors.grey.shade100 : AppColors.textFieldBackground,
              contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: AppColors.authButtonBorder),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: AppColors.authButtonBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
                borderSide: BorderSide(color: readOnly ? AppColors.authButtonBorder : const Color(0xFF00ABE4)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
