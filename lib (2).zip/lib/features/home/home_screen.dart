import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/utils.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../../constants/api_keys.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../widgets/service_card.dart';
import '../bookings/bookings_screen.dart';
import '../notifications/notification_screen.dart';
import '../activity/activity_screen.dart';
import '../parcels/pickup_address_screen.dart';
import '../rides/choose_ride_screen.dart';
import 'location_search_screen.dart';
import 'search_vehicles_screen.dart';
import '../profile/profile_screen.dart';
import '../rides/looking_for_ride_screen.dart';
import '../rides/driver_assigned_screen.dart';
import '../rides/driver_tracking_screen.dart';
import '../parcels/delivery_booked_screen.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _currentAddress = "Fetching location...";
  GoogleMapController? _mapController;
  Position? _currentPosition;

  String? get _prefilledPickupAddress {
    const unavailableAddresses = {
      'Fetching location...',
      'Location services disabled',
      'Location permission denied',
      'Location permission permanently denied',
      'Unable to get location',
      'Location not found',
      'Error getting address',
    };

    if (unavailableAddresses.contains(_currentAddress)) {
      return null;
    }

    return _currentAddress;
  }

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
    _checkOngoingBooking();
  }

  Future<void> _checkOngoingBooking() async {
    try {
      final response = await ApiService.to.get(ApiEndpoints.ongoingBooking);
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data;
        if (data['hasOngoingTrip'] == true && data['booking'] != null) {
          final booking = data['booking'];
          final String bookingId = booking['id'] ?? '';
          final String status = booking['status'] ?? '';
          final bool isGoods = booking['isGoods'] == true;

          if (bookingId.isEmpty) return;

          // Check if we are still searching/pending
          final searchingStatuses = {'PENDING', 'SEARCHING', 'DISPATCHED'};
          if (searchingStatuses.contains(status)) {
            if (mounted) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => LookingForRideScreen(tripId: bookingId),
                ),
              );
            }
            return;
          }

          if (!isGoods) {
            final driver = booking['driver'] ?? {};
            final driverProfile = driver['driverProfile'] ?? {};
            
            final mappedDriver = {
              'id': driver['id'],
              'name': driver['name'] ?? '${driverProfile['firstName'] ?? ''} ${driverProfile['lastName'] ?? ''}'.trim(),
              'phone': driver['phone'],
              'image': driverProfile['profileImage'],
              'rating': driverProfile['rating'] ?? 4.5,
              'totalReviews': driverProfile['totalReviews'] ?? 0,
            };

            final driverData = <String, dynamic>{
              'booking': booking,
              'driver': mappedDriver,
              'vehicle': booking['vehicle'] ?? driverProfile['vehicles']?[0],
              'pickup': booking['pickup'],
              'drop': booking['drop'],
              'rideStartOtp': booking['rideStartOtp'],
            };

            if (mounted) {
              final activeTrackingStatuses = ['DRIVER_ARRIVED', 'OTP_VERIFIED', 'PICKED_UP', 'IN_TRANSIT'];
              
              if (activeTrackingStatuses.contains(status)) {
                // Determine the correct RideState
                RideState initialState = RideState.verifyOTP;
                if (status == 'PICKED_UP' || status == 'IN_TRANSIT') {
                  initialState = RideState.inProgress;
                }
                
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DriverTrackingScreen(
                      tripId: bookingId,
                      driverData: driverData,
                      initialState: initialState,
                    ),
                  ),
                );
              } else {
                // DRIVER_ASSIGNED or ON_THE_WAY
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DriverAssignedScreen(
                      tripId: bookingId,
                      driverData: driverData,
                    ),
                  ),
                );
              }
            }
          } else {
            if (mounted) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => DeliveryBookedScreen(bookingId: bookingId),
                ),
              );
            }
          }
        }
      }
    } catch (e) {
      debugPrint("Error checking ongoing booking: $e");
    }
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      if (mounted) {
        setState(() {
          _currentAddress = "Location services disabled";
        });
      }
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        if (mounted) {
          setState(() {
            _currentAddress = "Location permission denied";
          });
        }
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      if (mounted) {
        setState(() {
          _currentAddress = "Location permission permanently denied";
        });
      }
      return;
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      if (mounted) {
        setState(() {
          _currentPosition = position;
        });
      }
      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 15,
          ),
        ),
      );
      _getAddressFromLatLng(position);
    } catch (e) {
      if (mounted) {
        setState(() {
          _currentAddress = "Unable to get location";
        });
      }
    }
  }

  Future<void> _getAddressFromLatLng(Position position) async {
    final String url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=${ApiKeys.googleMapsKey}';
    try {
      final response = await http.get(Uri.parse(url));
      if (!mounted) return;
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          setState(() {
            _currentAddress = AppUtils.cleanGeocodedAddress(data['results'][0]['formatted_address']);
          });
        } else {
          setState(() {
            _currentAddress = "Location not found";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _currentAddress = "Error getting address";
        });
      }
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Top Map Area Placeholder
            SizedBox(
              height: 210.h,
              child: Stack(
                children: [
                  // Live Google Map
                  Positioned.fill(
                    child: GoogleMap(
                      initialCameraPosition: const CameraPosition(
                        target: LatLng(28.7041, 77.1025), // Default to Delhi
                        zoom: 12,
                      ),
                      myLocationEnabled: true,
                      myLocationButtonEnabled: false,
                      zoomControlsEnabled: false,
                      scrollGesturesEnabled: false,
                      zoomGesturesEnabled: false,
                      rotateGesturesEnabled: false,
                      tiltGesturesEnabled: false,
                      onMapCreated: (controller) {
                        _mapController = controller;
                        if (_currentPosition != null) {
                          _mapController?.animateCamera(
                            CameraUpdate.newCameraPosition(
                              CameraPosition(
                                target: LatLng(
                                  _currentPosition!.latitude,
                                  _currentPosition!.longitude,
                                ),
                                zoom: 15,
                              ),
                            ),
                          );
                        }
                      },
                    ),
                  ),
                  Column(
                    children: [
                      _buildTopBar(),
                      SizedBox(height: 48.h), // Lowered location pill
                      _buildLocationPill(),
                    ],
                  ),
                  Positioned(
                    right: 20.w,
                    bottom: 12.h,
                    child: GestureDetector(
                      onTap: _getCurrentLocation,
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 20.r,
                        child: Icon(
                          Icons.my_location,
                          color: const Color(0xFF00ABE4),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Bottom Sheet Content
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(30.r),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -5),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(14.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Drag handle
                      Center(
                        child: Container(
                          width: 40.w,
                          height: 4.h,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                        ),
                      ),
                      SizedBox(height: 20.h),

                      // Search Bar
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LocationSearchScreen(
                                initialPickupLocation: _prefilledPickupAddress,
                              ),
                            ),
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 16.w,
                            vertical: 12.h,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            border: Border.all(
                              color: const Color(0xFF00ABE4).withOpacity(0.3),
                              width: 3,
                            ),
                            borderRadius: BorderRadius.circular(30.r),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.search,
                                color: const Color(0xFF00ABE4),
                                size: 24.sp,
                              ),
                              SizedBox(width: 12.w),
                              Text(
                                'where we are going ?',
                                style: AppFonts.bodyText.copyWith(
                                  color: AppColors.black,
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 20.h),

                      // Sale Banner
                      GestureDetector(
                        onTap: () {},
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12.r),
                          child: Image.asset(
                            'assets/images/last.png',
                            width: double.infinity,
                            fit: BoxFit.fitWidth,
                          ),
                        ),
                      ),
                      SizedBox(height: 24.h),

                      // Everything You Need Title
                      Text(
                        'Everything you Need',
                        style: AppFonts.h1.copyWith(
                          fontSize: 20.sp,
                          color: AppColors.black,
                        ),
                      ),
                      SizedBox(height: 16.h),

                      // Grid Area
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Col 1
                          Expanded(
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 88.h,
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => LocationSearchScreen(
                                            initialPickupLocation: _prefilledPickupAddress,
                                          ),
                                        ),
                                      );
                                    },
                                    child: const ServiceCard(
                                      title: 'Sedan',
                                      time: '5 min',
                                      imagePath: 'assets/images/on1.png',
                                    ),
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                SizedBox(
                                  height: 88.h,
                                  child: const ServiceCard(
                                    title: 'SUV',
                                    time: '5 min',
                                    imagePath: 'assets/images/on2.png',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 12.w),
                          // Col 2
                          Expanded(
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 88.h,
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              LocationSearchScreen(
                                                initialPickupLocation:
                                                    _prefilledPickupAddress,
                                              ),
                                        ),
                                      );
                                    },
                                    child: const ServiceCard(
                                      title: 'Cab',
                                      time: '25 min',
                                      imagePath: 'assets/images/on3.png',
                                    ),
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                SizedBox(
                                  height: 88.h,
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              PickupAddressScreen(
                                                initialPickupAddress:
                                                    _prefilledPickupAddress,
                                              ),
                                        ),
                                      );
                                    },
                                    child: const ServiceCard(
                                      title: 'Truck',
                                      time: '5 min',
                                      imagePath: 'assets/images/on1.png',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 12.w),
                          // Col 3 (All Services)
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SearchVehiclesScreen(
                                      pickupAddress: _prefilledPickupAddress,
                                    ),
                                  ),
                                );
                              },
                              child: Container(
                                height: 184.h,
                                padding: EdgeInsets.all(12.w),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      const Color(0xFF00ABE4).withOpacity(0.10),
                                      const Color(0xFF00ABE4).withOpacity(0.0),
                                    ],
                                  ),
                                  border: Border.all(
                                    color: const Color(
                                      0xFF00ABE4,
                                    ).withOpacity(0.20),
                                    width: 0.5,
                                  ),
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 4.w,
                                          vertical: 2.h,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFE0F2FE),
                                          borderRadius: BorderRadius.circular(
                                            4.r,
                                          ),
                                        ),
                                        child: Text(
                                          'UPTO 50% OFF',
                                          style: TextStyle(
                                            fontSize: 8.sp,
                                            color: const Color(0xFF0284C7),
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 28.h),
                                    Text(
                                      'All\nServices',
                                      style: AppFonts.h2.copyWith(
                                        fontSize: 16.sp,
                                        color: AppColors.black,
                                      ),
                                    ),
                                    SizedBox(height: 4.h),
                                    Text(
                                      'See all Services',
                                      style: AppFonts.captionDark.copyWith(
                                        fontSize: 10.sp,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                    SizedBox(height: 8.h),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Icon(
                                          Icons.grid_view,
                                          color: const Color(0xFF00ABE4),
                                          size: 30.sp,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 24.h),
                      // Exclusive Offer
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Exclusive Offer',
                            style: AppFonts.h1.copyWith(
                              fontSize: 20.sp,
                              color: AppColors.black,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16.h),

                      // Banner Image
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const ActivityScreen(),
                            ),
                          );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16.r),
                          child: Image.asset(
                            'assets/images/banner.png',
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(height: 20.h),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SearchVehiclesScreen(
                      pickupAddress: _prefilledPickupAddress,
                    ),
                  ),
                );
              },
              child: Container(
                height: 38.h,
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20.r),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.search,
                      color: const Color(0xFF00ABE4),
                      size: 18.sp,
                    ),
                    SizedBox(width: 6.w),
                    Expanded(
                      child: Text(
                        'Search Car, Cab, Truck...',
                        style: AppFonts.bodyText.copyWith(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 13.sp,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(width: 8.w),
          Row(
            children: [
              Container(
                height: 38.h,
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.account_balance_wallet,
                      color: Color(0xFF00ABE4),
                      size: 18,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      '₹ 0.00',
                      style: AppFonts.h2.copyWith(
                        fontSize: 13.sp,
                        color: AppColors.black,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 6.w),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ActivityScreen(),
                    ),
                  );
                },
                child: Container(
                  width: 38.h,
                  height: 38.h,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.notifications_none,
                    color: Colors.black,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLocationPill() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 24.w),
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30.r),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.location_on, color: Color(0xFF00ABE4)),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              _currentAddress,
              style: AppFonts.bodyText.copyWith(
                color: Colors.black,
                fontWeight: FontWeight.w600,
                fontSize: 13.sp,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const Icon(Icons.keyboard_arrow_down, color: Colors.black),
        ],
      ),
    );
  }
}
