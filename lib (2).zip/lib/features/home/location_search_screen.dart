import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/utils.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../../constants/api_keys.dart';
import '../../constants/app_colors.dart';
import '../../constants/app_fonts.dart';
import '../../core/api/api_service.dart';
import '../rides/choose_ride_screen.dart';

class LocationSearchScreen extends StatefulWidget {
  final String? initialPickupLocation;

  const LocationSearchScreen({super.key, this.initialPickupLocation});

  @override
  State<LocationSearchScreen> createState() => _LocationSearchScreenState();
}

class _LocationSearchScreenState extends State<LocationSearchScreen> {
  final TextEditingController _pickupController = TextEditingController();
  final TextEditingController _dropController = TextEditingController();
  final FocusNode _pickupFocusNode = FocusNode();
  final FocusNode _dropFocusNode = FocusNode();

  List<dynamic> _placeSuggestions = [];
  final List<Map<String, String>> _recentSearches = [];
  bool _isGettingCurrentLocation = false;
  bool _isLoadingRecentSearches = false;

  @override
  void initState() {
    super.initState();
    final initialPickupLocation = widget.initialPickupLocation;
    if (initialPickupLocation != null && initialPickupLocation.isNotEmpty) {
      _pickupController.text = initialPickupLocation;
    } else {
      _useCurrentLocation();
    }
    _fetchRecentSearches();
  }

  Future<void> _fetchRecentSearches() async {
    setState(() {
      _isLoadingRecentSearches = true;
    });

    try {
      final response = await ApiService.to.get(
        '/api/goods/bookings/recent-addresses?limit=5',
      );
      if (response.data != null && response.data['success'] == true) {
        final List<dynamic> recentList = response.data['data'] ?? [];
        final List<Map<String, String>> parsedSearches = [];
        final Set<String> existingAddresses = {};

        for (final item in recentList) {
          String? title;
          String? address;

          if (item is String) {
            title = item;
            address = item;
          } else if (item is Map<String, dynamic>) {
            title =
                item['title'] ??
                item['name'] ??
                item['label'] ??
                item['address'] ??
                item['pickupAddress'] ??
                item['dropAddress'] ??
                item['formattedAddress'];
            address =
                item['address'] ??
                item['pickupAddress'] ??
                item['dropAddress'] ??
                item['subtitle'] ??
                item['formattedAddress'] ??
                title;
          }

          final trimmedAddress = address?.trim();
          if (trimmedAddress != null &&
              trimmedAddress.isNotEmpty &&
              existingAddresses.add(trimmedAddress)) {
            parsedSearches.add({
              'title': (title?.toString().trim().isNotEmpty ?? false)
                  ? title!.toString().trim()
                  : 'Recent Location',
              'address': trimmedAddress,
            });
          }
        }

        if (mounted) {
          setState(() {
            _recentSearches
              ..clear()
              ..addAll(parsedSearches);
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching recent searches: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingRecentSearches = false;
        });
      }
    }
  }

  void _handleLocationSelection(String locationName) {
    if (_pickupFocusNode.hasFocus ||
        (_pickupController.text.isEmpty && !_dropFocusNode.hasFocus)) {
      _pickupController.text = locationName;
      _pickupFocusNode.unfocus();
      if (_dropController.text.isEmpty) {
        FocusScope.of(context).requestFocus(_dropFocusNode);
      }
    } else if (_dropFocusNode.hasFocus || _pickupController.text.isNotEmpty) {
      _dropController.text = locationName;
      _dropFocusNode.unfocus();
      if (_pickupController.text.isEmpty) {
        FocusScope.of(context).requestFocus(_pickupFocusNode);
      }
    }

    setState(() {
      _placeSuggestions = [];
    });

    if (_pickupController.text.isNotEmpty && _dropController.text.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChooseRideScreen(
            pickupAddress: _pickupController.text,
            destinationAddress: _dropController.text,
          ),
        ),
      );
    }
  }

  Future<void> _getPlaceSuggestions(String input) async {
    if (input.isEmpty) {
      setState(() {
        _placeSuggestions = [];
      });
      return;
    }

    final String url =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=${ApiKeys.googleMapsKey}&components=country:in';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK') {
          setState(() {
            _placeSuggestions = data['predictions'];
          });
        } else {
          debugPrint(
            'Google API Error: ${data['status']} - ${data['error_message']}',
          );
        }
      } else {
        debugPrint('HTTP Error: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Error fetching places: $e');
    }
  }

  Future<void> _useCurrentLocation() async {
    if (_isGettingCurrentLocation) return;

    setState(() {
      _isGettingCurrentLocation = true;
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _setPickupLocation('Location services disabled');
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        _setPickupLocation('Location permission denied');
        return;
      }

      if (permission == LocationPermission.deniedForever) {
        _setPickupLocation('Location permission permanently denied');
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      final address = await _getAddressFromLatLng(position);
      _setPickupLocation(address);
    } catch (e) {
      _setPickupLocation('Unable to get current location');
    } finally {
      if (mounted) {
        setState(() {
          _isGettingCurrentLocation = false;
        });
      }
    }
  }

  Future<String> _getAddressFromLatLng(Position position) async {
    final String url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=${ApiKeys.googleMapsKey}';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status'] == 'OK' && data['results'].isNotEmpty) {
        final formattedAddress =
            data['results'][0]['formatted_address'] as String;
        return AppUtils.cleanGeocodedAddress(formattedAddress);
      }
    }

    return 'Current Location';
  }

  void _setPickupLocation(String locationName) {
    if (!mounted) return;

    setState(() {
      _pickupController.text = locationName;
      _placeSuggestions = [];
    });
    _pickupFocusNode.unfocus();
    FocusScope.of(context).requestFocus(_dropFocusNode);
  }

  @override
  void dispose() {
    _pickupController.dispose();
    _dropController.dispose();
    _pickupFocusNode.dispose();
    _dropFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // Header Area with light blue background
          Container(
            color: AppColors.lightBlueBackground,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20.h,
              bottom: 20.h,
              left: 20.w,
              right: 20.w,
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 20.r,
                    child: const Icon(Icons.arrow_back, color: Colors.black),
                  ),
                ),
                SizedBox(width: 16.w),
                Text(
                  'Book your ride',
                  style: AppFonts.h1.copyWith(
                    fontSize: 20.sp,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),

          // Inputs Area below the header
          Container(
            margin: EdgeInsets.only(
              top: 20.h,
              left: 20.w,
              right: 20.w,
              bottom: 10.h,
            ),
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F8F8),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(color: Colors.grey.shade200),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.02),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Row(
              children: [
                // Timeline Graphic
                Column(
                  children: [
                    Icon(
                      Icons.radio_button_checked,
                      color: Colors.green,
                      size: 20.sp,
                    ),
                    Container(
                      width: 1,
                      height: 40.h,
                      color: Colors.grey.shade300,
                    ),
                    Icon(Icons.location_on, color: Colors.red, size: 20.sp),
                  ],
                ),
                SizedBox(width: 12.w),
                // Input Fields
                Expanded(
                  child: Column(
                    children: [
                      _buildInputField(
                        controller: _pickupController,
                        hint: 'Pick up Location',
                        onChanged: _getPlaceSuggestions,
                        focusNode: _pickupFocusNode,
                      ),
                      SizedBox(height: 12.h),
                      _buildInputField(
                        controller: _dropController,
                        hint: 'Drop Location',
                        onChanged: _getPlaceSuggestions,
                        focusNode: _dropFocusNode,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Recent Search or Suggestions
          Expanded(
            child: _placeSuggestions.isNotEmpty
                ? ListView.builder(
                    padding: EdgeInsets.symmetric(
                      horizontal: 20.w,
                      vertical: 10.h,
                    ),
                    itemCount: _placeSuggestions.length,
                    itemBuilder: (context, index) {
                      final place = _placeSuggestions[index];
                      return _buildSuggestionItem(place);
                    },
                  )
                : ListView(
                    padding: EdgeInsets.symmetric(
                      horizontal: 20.w,
                      vertical: 16.h,
                    ),
                    children: [
                      Text(
                        'Recent Search',
                        style: AppFonts.h2.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 16.h),
                      if (_isLoadingRecentSearches)
                        Center(
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 24.h),
                            child: const CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF00ABE4),
                            ),
                          ),
                        )
                      else
                        ..._recentSearches.map(
                          (search) => _buildRecentSearchItem(
                            search['title'] ?? 'Recent Location',
                            search['address'] ?? '',
                          ),
                        ),
                    ],
                  ),
          ),

          // Bottom Button
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
            child: GestureDetector(
              onTap: _useCurrentLocation,
              child: Container(
                width: double.infinity,
                height: 40.h,
                padding: EdgeInsets.only(
                  top: 12.h,
                  bottom: 12.h,
                  left: 10.w,
                  right: 10.w,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF00ABE4).withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (_isGettingCurrentLocation)
                      SizedBox(
                        width: 16.w,
                        height: 16.w,
                        child: const CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFF00ABE4),
                        ),
                      )
                    else
                      Icon(
                        Icons.my_location,
                        color: const Color(0xFF00ABE4),
                        size: 16.sp,
                      ),
                    SizedBox(width: 8.w),
                    Text(
                      _isGettingCurrentLocation
                          ? 'Getting location...'
                          : 'Use Current Location',
                      style: AppFonts.bodyText.copyWith(
                        color: const Color(0xFF00ABE4),
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hint,
    required Function(String) onChanged,
    required FocusNode focusNode,
  }) {
    return Container(
      height: 44.h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onChanged: onChanged,
        textAlignVertical: TextAlignVertical.top,
        style: AppFonts.bodyText.copyWith(
          color: Colors.black,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: AppFonts.bodyText,
          isDense: true,
          border: InputBorder.none,
          contentPadding: EdgeInsets.only(
            left: 12.w,
            right: 12.w,
            top: 10.h,
            bottom: 12.h,
          ),
          suffixIconConstraints: BoxConstraints(
            minHeight: 24.h,
            minWidth: 40.w,
          ),
          suffixIcon: ValueListenableBuilder<TextEditingValue>(
            valueListenable: controller,
            builder: (context, value, child) {
              if (value.text.isNotEmpty) {
                return GestureDetector(
                  onTap: () {
                    controller.clear();
                    onChanged('');
                  },
                  child: Icon(Icons.close, color: Colors.grey, size: 20.sp),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSuggestionItem(Map<String, dynamic> place) {
    final structuredFormatting =
        place['structured_formatting'] as Map<String, dynamic>?;
    final mainText =
        structuredFormatting?['main_text'] ?? place['description'] ?? '';
    final secondaryText = structuredFormatting?['secondary_text'] ?? '';

    return InkWell(
      onTap: () => _handleLocationSelection(mainText),
      child: Container(
        margin: EdgeInsets.only(bottom: 10.h),
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: const Color(0xFF00ABE4).withOpacity(0.20),
            width: 1.2.w,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00ABE4).withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 38.w,
              height: 38.w,
              decoration: const BoxDecoration(
                color: Color(0xFFE6F7FD),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.location_on_rounded,
                color: const Color(0xFF00ABE4),
                size: 20.sp,
              ),
            ),
            SizedBox(width: 14.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    mainText,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1E293B),
                    ),
                  ),
                  if (secondaryText.isNotEmpty) ...[
                    SizedBox(height: 4.h),
                    Text(
                      secondaryText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: AppFonts.fontFamily,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w500,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            SizedBox(width: 8.w),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: const Color(0xFF00ABE4).withOpacity(0.7),
              size: 14.sp,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentSearchItem(String title, String address) {
    return InkWell(
      onTap: () {
        _handleLocationSelection(address.isNotEmpty ? address : title);
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 10.h),
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey.shade200, width: 1.2.w),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 38.w,
              height: 38.w,
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.history_rounded,
                color: Colors.grey.shade700,
                size: 20.sp,
              ),
            ),
            SizedBox(width: 14.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1E293B),
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    address,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: AppFonts.fontFamily,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8.w),
            Icon(
              Icons.favorite_border_rounded,
              color: Colors.red.withOpacity(0.5),
              size: 18.sp,
            ),
          ],
        ),
      ),
    );
  }
}
