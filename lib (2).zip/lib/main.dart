import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'core/api/api_service.dart';
import 'core/socket/socket_service.dart';
import 'features/splash/splash_screen.dart';
import 'core/network/network_controller.dart';
import 'services/review_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock orientation to portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  Get.put<ApiService>(ApiService(), permanent: permanentApiCheck());
  Get.put<SocketService>(SocketService(), permanent: true);
  Get.put<NetworkController>(NetworkController(), permanent: true);
  Get.put<ReviewService>(ReviewService(), permanent: true);
  runApp(const MyApp());
}

bool permanentApiCheck() => true;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Initialize ScreenUtil for responsive design
    // We use a common size like 375x812 (iPhone X/11/12/13/14 Pro)
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          scrollBehavior: const NoBounceScrollBehavior(),
          title: 'Taxify',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            textTheme: Typography.englishLike2018.apply(fontSizeFactor: 1.sp),
          ),
          builder: (context, appChild) {
            return GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: () {
                final currentFocus = FocusManager.instance.primaryFocus;
                if (currentFocus != null && !currentFocus.hasPrimaryFocus) {
                  currentFocus.unfocus();
                }
              },
              child: appChild ?? const SizedBox.shrink(),
            );
          },
          home: child,
        );
      },
      child: const SplashScreen(), // Starts with Splash Screen
    );
  }
}

class NoBounceScrollBehavior extends MaterialScrollBehavior {
  const NoBounceScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const ClampingScrollPhysics();
  }

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }
}
