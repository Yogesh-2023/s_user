class ApiEndpoints {
  const ApiEndpoints._();

  // Auth & User Endpoints
  static const String profileCreate = '/api/user/profile/create';
  static const String profileMe = '/api/user/profile/me';
  static const String profileUpdate = '/api/user/profile/create';
  static const String logout = '/api/auth/logout';

  // Booking Endpoints
  static const String userRideHistory = '/api/bookings/user/history';
  static const String ongoingBooking = '/api/bookings/ongoing';
  static const String fareEstimate = '/api/rides/fare-estimate';
  static const String bookRide = '/api/rides';
  static const String cancelRide = '/api/rides/cancel';
  static const String carOptions = '/api/rides/car-options';
  // Force rebuild comment

  // Other Endpoints
  static const String tickets = '/api/support/tickets';

  // Review Endpoints
  static const String submitUserReview = '/api/reviews/user';
  static const String allUserReviews = '/api/reviews/user/all';
  static String getBookingReview(String bookingId) => '/api/reviews/booking/$bookingId';

  // Auth Endpoints
  static const String sendOtp = '/api/auth/custom/send-otp';
  static const String verifyOtp = '/api/auth/custom/verify-otp/';

  // Goods Endpoints
  static const String goodsEstimate = '/api/goods/estimate';
  static const String goodsBookings = '/api/goods/bookings';
  static String goodsBookingDetails(String id) => '/api/goods/bookings/$id';
  static String goodsAdvancePayment(String id) => '/api/goods/bookings/$id/advance-payment';
  static String goodsVerifyPickupOtp(String id) => '/api/goods/bookings/$id/verify-pickup-otp';
  static String goodsVerifyDeliveryOtp(String id) => '/api/goods/bookings/$id/verify-delivery-otp';
  static String goodsStatus(String id) => '/api/goods/bookings/$id/status';
  static String goodsTracking(String id) => '/api/goods/bookings/$id/tracking';
}
