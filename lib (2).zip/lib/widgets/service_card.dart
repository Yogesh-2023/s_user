import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../constants/app_fonts.dart';
import '../constants/app_colors.dart';

class ServiceCard extends StatelessWidget {
  final String title;
  final String time;
  final String imagePath;

  const ServiceCard({
    super.key,
    required this.title,
    required this.time,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF00ABE4).withOpacity(0.10),
            const Color(0xFF00ABE4).withOpacity(0.0),
          ],
        ),
        border: Border.all(
          color: const Color(0xFF00ABE4).withOpacity(0.20),
          width: 0.5,
        ),
        borderRadius: BorderRadius.circular(10.r),
      ),
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.h2.copyWith(
              fontSize: 15.sp,
              color: AppColors.black,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            time,
            style: AppFonts.captionDark.copyWith(
              color: AppColors.textSecondary,
              fontSize: 11.sp,
            ),
          ),
          SizedBox(height: 4.h),
          Expanded(
            child: Align(
              alignment: Alignment.bottomRight,
              child: Image.asset(imagePath, height: 54.h, fit: BoxFit.contain),
            ),
          ),
        ],
      ),
    );
  }
}
