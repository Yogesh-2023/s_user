import 'dart:ui';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../constants/app_fonts.dart';
import '../../constants/app_assets.dart';
import 'cancel_ride_screen.dart';
import 'payment_screen.dart';
import 'driver_chat_screen.dart';
import 'ride_invoice_screen.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../core/socket/socket_service.dart';
import '../../core/socket/socket_events.dart';
import '../../core/api/api_constants.dart';
import '../main_navigation_screen.dart';

enum RideState { arriving, verifyOTP, inProgress }

class DriverTrackingScreen extends StatefulWidget {
  final String? tripId;
  final Map<String, dynamic>? driverData;
  final RideState? initialState;

  const DriverTrackingScreen({
    super.key,
    this.tripId,
    this.driverData,
    this.initialState,
  });

  @override
  State<DriverTrackingScreen> createState() => _DriverTrackingScreenState();
}

class _DriverTrackingScreenState extends State<DriverTrackingScreen> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  RideState _rideState = RideState.arriving;
  
  int _waitingSeconds = 0;
  Timer? _waitingTimer;
  Map<String, dynamic>? _bookingData;

  @override
  void initState() {
    super.initState();
    if (widget.initialState != null) {
      _rideState = widget.initialState!;
      if (_rideState == RideState.verifyOTP) {
        _startWaitingTimer();
      }
    }
    _getCurrentLocation();
    _setupSocketListeners();
  }

  void _startWaitingTimer() {
    if (widget.driverData != null && widget.driverData!.containsKey('arrivedAt') && widget.driverData!['arrivedAt'] != null) {
      try {
        final arrivedTime = DateTime.parse(widget.driverData!['arrivedAt'].toString());
        final diff = DateTime.now().difference(arrivedTime);
        _waitingSeconds = diff.inSeconds > 0 ? diff.inSeconds : 0;
      } catch (e) {
        print('Error parsing arrivedAt: $e');
        _waitingSeconds = 0;
      }
    }

    _waitingTimer?.cancel();
    _waitingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _waitingSeconds++;
      });
    });
  }

  void _setupSocketListeners() {
    print('--- [SOCKET_IO] Setting up tracking listeners for Trip ID: ${widget.tripId} ---');

    // 1. Listen to DRIVER_ARRIVED
    SocketService.to.listenTo(SocketEvents.driverArrived, (data) {
      print('--- [SOCKET_IO] Received DRIVER_ARRIVED: $data ---');
      if (!mounted) return;
      _startWaitingTimer();
      setState(() {
        _rideState = RideState.verifyOTP;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your driver has arrived at the pickup location!')),
      );
    });

    // 2. Listen to TRIP_STARTED
    SocketService.to.listenTo(SocketEvents.tripStarted, (data) {
      print('--- [SOCKET_IO] Received TRIP_STARTED: $data ---');
      if (!mounted) return;
      _waitingTimer?.cancel();
      
      Map<String, dynamic>? bookingData;
      if (data is List && data.isNotEmpty && data[0] is Map) {
         final payload = data[0] as Map;
         if (payload.containsKey('booking')) {
           bookingData = Map<String, dynamic>.from(payload['booking']);
         }
      } else if (data is Map && data.containsKey('booking')) {
         bookingData = Map<String, dynamic>.from(data['booking']);
      }

      setState(() {
        if (bookingData != null) {
          _bookingData = bookingData;
        }
        _rideState = RideState.inProgress;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your trip has started!')),
      );
    });

    // 3. Listen to TRIP_COMPLETED
    SocketService.to.listenTo(SocketEvents.tripCompleted, (data) {
      print('--- [SOCKET_IO] Received TRIP_COMPLETED: $data ---');
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => PaymentScreen(
            bookingId: widget.tripId,
            driverData: widget.driverData,
          ),
        ),
      );
    });

    // 4. Listen to DRIVER_LOCATION
    SocketService.to.listenTo(SocketEvents.driverLocation, (data) {
      print('--- [SOCKET_IO] Received DRIVER_LOCATION: $data ---');
      if (!mounted) return;
      if (data is Map && data['lat'] != null && data['lng'] != null) {
        final lat = double.tryParse(data['lat'].toString());
        final lng = double.tryParse(data['lng'].toString());
        if (lat != null && lng != null) {
          setState(() {
            _currentPosition = Position(
              latitude: lat,
              longitude: lng,
              timestamp: DateTime.now(),
              accuracy: 0.0,
              altitude: 0.0,
              heading: 0.0,
              speed: 0.0,
              speedAccuracy: 0.0,
              altitudeAccuracy: 0.0,
              headingAccuracy: 0.0,
            );
          });
          _mapController?.animateCamera(
            CameraUpdate.newCameraPosition(
              CameraPosition(target: LatLng(lat, lng), zoom: 15),
            ),
          );
        }
      }
    });

    // 5. Listen to TRIP_CANCELLED
    SocketService.to.listenTo(SocketEvents.tripCancelled, (data) {
      print('--- [SOCKET_IO] Received TRIP_CANCELLED: $data ---');
      if (!mounted) return;
      final payload = data is List ? (data.isNotEmpty ? data.first : {}) : data;
      final reason = payload?['message'] ?? 'The driver has cancelled this trip.';
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(reason),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const MainNavigationScreen()),
        (route) => false,
      );
    });

  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      if (!mounted) return;
      setState(() {
        _currentPosition = position;
      });
      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 15,
          ),
        ),
      );
    } catch (e) {
      debugPrint("Error fetching location: \$e");
    }
  }

  @override
  void dispose() {
    _waitingTimer?.cancel();
    _mapController?.dispose();
    SocketService.to.stopListening(SocketEvents.driverArrived);
    SocketService.to.stopListening(SocketEvents.tripStarted);
    SocketService.to.stopListening(SocketEvents.tripCompleted);
    SocketService.to.stopListening(SocketEvents.tripCancelled);
    SocketService.to.stopListening(SocketEvents.driverLocation);
    super.dispose();
  }

  void _showCancelPopup() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        Widget buildButton({
          required String label,
          required Color color,
          required Color textColor,
          required VoidCallback onPressed,
        }) {
          return SizedBox(
            width: double.infinity,
            height: 44.h,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.r),
                ),
              ),
              onPressed: onPressed,
              child: Text(
                label,
                style: AppFonts.buttonText.copyWith(
                  color: textColor,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        }

        return Container(
          padding: EdgeInsets.fromLTRB(
            14.w,
            10.h,
            14.w,
            MediaQuery.of(sheetContext).padding.bottom + 16.h,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(20.r),
                ),
              ),
              SizedBox(height: 26.h),
              Text(
                'Cancel Ride?',
                style: AppFonts.h2.copyWith(
                  color: Colors.black,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 8.h),
              Text(
                'Driver has already been assigned.\nCancellation charges may apply.',
                textAlign: TextAlign.center,
                style: AppFonts.captionDark.copyWith(
                  color: Colors.grey.shade500,
                  fontSize: 12.sp,
                  height: 1.25,
                ),
              ),
              SizedBox(height: 28.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1F1),
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Colors.redAccent,
                      size: 22.sp,
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        'If you cancel now, a cancellation fee may be deducted from your payment',
                        style: AppFonts.captionDark.copyWith(
                          color: Colors.black87,
                          fontSize: 11.sp,
                          height: 1.25,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 26.h),
              buildButton(
                label: 'Cancel Ride',
                color: const Color(0xFFFF2D2D),
                textColor: Colors.white,
                onPressed: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CancelRideScreen(tripId: widget.tripId ?? ''),
                    ),
                  );
                },
              ),
              SizedBox(height: 10.h),
              buildButton(
                label: 'Keep Ride',
                color: const Color(0xFFF0FBFE),
                textColor: Colors.black,
                onPressed: () => Navigator.pop(sheetContext),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: Stack(
        children: [
          // Background Map
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(28.7041, 77.1025), // Default to Delhi
                zoom: 15,
              ),
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              markers: {
                if (_currentPosition != null)
                  Marker(
                    markerId: const MarkerId('driver_vehicle'),
                    position: LatLng(
                      _currentPosition!.latitude + 0.002, // slightly offset for demo
                      _currentPosition!.longitude + 0.002,
                    ),
                    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
                    infoWindow: const InfoWindow(title: 'Driver Location'),
                  ),
              },
              onMapCreated: (controller) {
                _mapController = controller;
                if (_currentPosition != null) {
                  _mapController?.animateCamera(
                    CameraUpdate.newCameraPosition(
                      CameraPosition(
                        target: LatLng(
                          _currentPosition!.latitude,
                          _currentPosition!.longitude,
                        ),
                        zoom: 15,
                      ),
                    ),
                  );
                }
              },
            ),
          ),

          _buildMapOverlays(),
          _buildTopActionButtons(),
          _buildBottomSheet(),
        ],
      ),
    );
  }

  Widget _buildTopActionButtons() {
    return Positioned(
      top: MediaQuery.of(context).padding.top + 10.h,
      left: 20.w,
      right: 20.w,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 20.r,
                  child: const Icon(Icons.arrow_back, color: Colors.black),
                ),
              ),
              if (_rideState == RideState.inProgress) ...[
                SizedBox(height: 16.h),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 16.w,
                    vertical: 12.h,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    boxShadow: const [
                      BoxShadow(color: Colors.black12, blurRadius: 10),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${_bookingData != null ? _bookingData!['distanceKm'] : '12.4'} km left',
                        style: AppFonts.bodyText.copyWith(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        '${_bookingData != null ? _bookingData!['estimatedDurationMin'] : '15'} min',
                        style: AppFonts.captionDark.copyWith(
                          color: const Color(0xFF00ABE4),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
          if (_rideState == RideState.arriving ||
              _rideState == RideState.verifyOTP)
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
                boxShadow: const [
                  BoxShadow(color: Colors.black12, blurRadius: 10),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    'OTP',
                    style: AppFonts.captionDark.copyWith(fontSize: 10.sp),
                  ),
                  Text(
                    '5824',
                    style: AppFonts.h2.copyWith(
                      fontSize: 14.sp,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMapOverlays() {
    if (_rideState == RideState.inProgress)
      return const SizedBox(); // No center tooltips when in progress

    return Center(
      child: Container(
        margin: EdgeInsets.only(bottom: 100.h),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Center tag
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
                boxShadow: const [
                  BoxShadow(color: Colors.black12, blurRadius: 10),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _rideState == RideState.arriving ? 'Driver' : 'Arrived',
                    style: AppFonts.h2.copyWith(
                      fontSize: 14.sp,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    _rideState == RideState.arriving
                        ? 'Arriving in 3 min'
                        : '1 min',
                    style: AppFonts.captionDark.copyWith(
                      color: const Color(0xFF00ABE4),
                    ),
                  ),
                ],
              ),
            ),
            // Tooltip removed as per user request
          ],
        ),
      ),
    );
  }

  Widget _buildBottomSheet() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(15.r)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(
                    top: 10.h,
                    right: 12.w,
                    bottom: 10.h,
                    left: 12.w,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Container(
                          margin: EdgeInsets.only(bottom: 12.h),
                          width: 48.w,
                          height: 4.h,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                        ),
                      ),
                      if (_rideState == RideState.arriving)
                        _buildArrivingState(),
                      if (_rideState == RideState.verifyOTP)
                        _buildVerifyOTPState(),
                      if (_rideState == RideState.inProgress)
                        _buildInProgressState(),
                    ],
                  ),
                ),
              ),
            ),
          ),
          _buildFixedBottomAction(),
        ],
      ),
    );
  }

  Widget _buildFixedBottomAction() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: 16.h,
        left: 20.w,
        right: 20.w,
        bottom: MediaQuery.of(context).padding.bottom > 0
            ? MediaQuery.of(context).padding.bottom
            : 20.h,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: _rideState == RideState.verifyOTP
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildCancelRideButton(),
              ],
            )
          : _rideState == RideState.inProgress
              ? const SizedBox()
              : _buildEmergencySOSContent(),
    );
  }

  Widget _buildFixedCompleteTripButton() {
    return SizedBox(
      width: double.infinity,
      height: 48.h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF00ABE4),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.r),
          ),
        ),
        onPressed: () {
          _showTripCompletePopup();
        },
        child: Text(
          'Complete Trip',
          style: AppFonts.buttonText.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildEmergencySOSContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: double.infinity,
          height: 50.h,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF2FBFE),
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
                side: BorderSide(color: const Color(0xFF00ABE4).withOpacity(0.2)),
              ),
            ),
            onPressed: () {
              setState(() {
                _rideState = RideState.verifyOTP;
              });
            },
            child: Text(
              'Wait for Driver',
              style: AppFonts.buttonText.copyWith(
                color: const Color(0xFF00ABE4),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
        SizedBox(height: 16.h),
        Text(
          '24x7 Safety Support',
          style: AppFonts.captionDark.copyWith(
            color: Colors.grey.shade700,
            fontSize: 12.sp,
          ),
        ),
      ],
    );
  }

  Widget _buildCancelRideButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 12.h),
          backgroundColor: const Color(0xFF00ABE4).withOpacity(0.05), // #00ABE40D
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.r),
          ),
        ),
        onPressed: () => _showCancelPopup(),
        child: Text(
          'Cancel Ride',
          style: AppFonts.buttonText.copyWith(
            color: Colors.black,
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }


  void _showShareTripPopup() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          width: double.infinity,
          padding: EdgeInsets.only(top: 10.h),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(15.r)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.w),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Center(
                      child: Container(
                        margin: EdgeInsets.only(bottom: 16.h),
                        width: 40.w,
                        height: 4.h,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                      ),
                    ),
                    Text(
                      'Share Trip',
                      style: AppFonts.h1.copyWith(
                        fontSize: 18.sp,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      'Share your live trip details with your friends and family',
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade500,
                      ),
                    ),
                    SizedBox(height: 24.h),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
                        borderRadius: BorderRadius.circular(16.r),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(16.w),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF4F6F9),
                              borderRadius: BorderRadius.vertical(
                                top: Radius.circular(16.r),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Live Trip Tracking',
                                  style: AppFonts.bodyText.copyWith(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  'Your live location will be share unit the trip ends.',
                                  style: AppFonts.captionDark.copyWith(
                                    color: Colors.grey.shade500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(16.w),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                bottom: Radius.circular(16.r),
                              ),
                            ),
                            child: Column(
                              children: [
                                _buildShareRow(
                                  'Drive',
                                  'Raj Kumar',
                                  imageAsset: AppAssets.profileImage,
                                ),
                                SizedBox(height: 16.h),
                                _buildShareRow(
                                  'Vehicle',
                                  'White Swift Dzire',
                                  imageAsset: AppAssets.carImage,
                                ),
                                SizedBox(height: 16.h),
                                _buildShareRow(
                                  'Vehicle No',
                                  'DL 01 AB 1234',
                                  imageAsset: AppAssets.carImage,
                                ),
                                SizedBox(height: 16.h),
                                _buildShareRow(
                                  'Trip Rout',
                                  'B-52 Business Park, Sector 62\n→ Sector 62 Metro Station, Noida',
                                  icon: Icons.location_on,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildShareIcon(
                          Icons.call,
                          'WhatsApp',
                          Colors.green,
                          const Color(0xFFE8F5E9),
                        ),
                        _buildShareIcon(
                          Icons.chat,
                          'SMS',
                          Colors.white,
                          Colors.green,
                        ),
                        _buildShareIcon(
                          Icons.link,
                          'Copy Link',
                          const Color(0xFF00ABE4),
                          const Color(0xFFE6F7FD),
                        ),
                        _buildShareIcon(
                          Icons.more_horiz,
                          'More',
                          Colors.black,
                          Colors.grey.shade100,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.only(
                  top: 14.h,
                  left: 12.w,
                  right: 12.w,
                  bottom: MediaQuery.of(context).padding.bottom > 0
                      ? MediaQuery.of(context).padding.bottom + 14.h
                      : 14.h,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 17,
                      offset: const Offset(0, -13),
                    ),
                  ],
                ),
                child: SizedBox(
                  height: 50.h,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF2FBFE),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                    ),
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      'Cancel',
                      style: AppFonts.buttonText.copyWith(color: Colors.black),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildShareRow(
    String label,
    String value, {
    IconData? icon,
    String? imageAsset,
  }) {
    return Row(
      children: [
        Container(
          width: 55.w,
          height: 55.w,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6.65.r),
            border: Border.all(
              color: const Color(0xFF00ABE4).withOpacity(0.20),
              width: 0.46.w,
            ),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                const Color(0xFF00ABE4).withOpacity(0.10),
                const Color(0xFF00ABE4).withOpacity(0.0),
              ],
            ),
          ),
          child: imageAsset != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(6.65.r),
                  child: Image.asset(imageAsset, fit: BoxFit.cover),
                )
              : Icon(icon, color: const Color(0xFF00ABE4), size: 24.sp),
        ),
        SizedBox(width: 16.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppFonts.captionDark.copyWith(
                  color: Colors.grey.shade600,
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                value,
                style: AppFonts.bodyText.copyWith(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildShareIcon(
    IconData icon,
    String label,
    Color iconColor,
    Color bgColor,
  ) {
    return Column(
      children: [
        CircleAvatar(
          radius: 24.r,
          backgroundColor: bgColor,
          child: Icon(icon, color: iconColor),
        ),
        SizedBox(height: 8.h),
        Text(
          label,
          style: AppFonts.captionDark.copyWith(color: Colors.grey.shade600),
        ),
      ],
    );
  }

  // ==== STATE WIDGETS ====

  Widget _buildArrivingState() {
    return Column(
      children: [
        _buildDriverInfo(),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.only(top: 15.h, right: 15.w, bottom: 15.h, left: 20.w),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
            borderRadius: BorderRadius.circular(14.r),
          ),
          child: Column(
            children: [
              // Green Banner
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFF1F8F3),
                  borderRadius: BorderRadius.circular(4.r),
                  border: Border.all(color: const Color(0xFF16A34A).withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: const BoxDecoration(
                        color: Color(0xFFE2F0E5),
                        shape: BoxShape.circle,
                      ),
                      child: CircleAvatar(
                        backgroundColor: const Color(0xFF16A34A),
                        radius: 8.r,
                        child: Icon(Icons.check, color: Colors.white, size: 12.sp),
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Your driver is on the way to pickup location',
                            style: AppFonts.bodyText.copyWith(
                              color: const Color(0xFF16A34A),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            'Please be ready at the pickup point',
                            style: AppFonts.captionDark.copyWith(
                              color: Colors.grey.shade500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10.h),
              _buildRouteTimeline(showTime: false),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildVerifyOTPState() {
    return Column(
      children: [
        Text(
          'Verify Ride',
          style: AppFonts.h1.copyWith(fontSize: 18.sp, color: Colors.black),
        ),
        SizedBox(height: 8.h),
        Text(
          'Share this OTP with your driver to start the ride',
          style: AppFonts.captionDark.copyWith(
            color: Colors.grey.shade500,
            fontSize: 13.sp,
          ),
        ),
        SizedBox(height: 24.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'OTP: 5824',
              style: AppFonts.h1.copyWith(
                fontSize: 28.sp,
                color: const Color(0xFF00ABE4),
                letterSpacing: 2,
              ),
            ),
            SizedBox(width: 32.w),
            Column(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 40.w,
                      height: 40.w,
                      child: CircularProgressIndicator(
                        value: (_waitingSeconds % 60) / 60,
                        strokeWidth: 2.w,
                        backgroundColor: const Color(0xFFE6F7FD),
                        color: const Color(0xFF00ABE4),
                      ),
                    ),
                    Text(
                      '${(_waitingSeconds ~/ 60).toString().padLeft(2, '0')}:${(_waitingSeconds % 60).toString().padLeft(2, '0')}',
                      style: AppFonts.captionDark.copyWith(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  'Waiting Time',
                  style: AppFonts.captionDark.copyWith(
                    fontSize: 10.sp,
                    color: const Color(0xFF00ABE4),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        ),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
          decoration: BoxDecoration(
            color: const Color(0xFFF7FDFF),
            border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
            borderRadius: BorderRadius.circular(4.r),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 16.r,
                backgroundColor: const Color(0xFFD6F0FA),
                child: Icon(
                  Icons.verified,
                  color: const Color(0xFF00ABE4),
                  size: 18.sp,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Text(
                  'For your safety, never share this OTP with anyone else.',
                  style: AppFonts.captionDark.copyWith(color: Colors.black87),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 12.h),
        GestureDetector(
          onTap: () {
            setState(() {
              _rideState = RideState.inProgress;
            });
          },
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 8.w),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
              borderRadius: BorderRadius.circular(16.r),
            ),
            child: _buildDriverInfo(),
          ),
        ),
      ],
    );
  }

  Widget _buildInProgressState() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trip in Progress',
                  style: AppFonts.h1.copyWith(
                    fontSize: 18.sp,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  'Enjoy your ride! You\'ll reach soon.',
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: 13.sp,
                  ),
                ),
              ],
            ),
            GestureDetector(
              onTap: _showShareTripPopup,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Row(
                  children: [
                    Icon(Icons.share, size: 14.sp, color: Colors.grey.shade500),
                    SizedBox(width: 4.w),
                    Text(
                      'Share Trip',
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            color: const Color(0xFFF2FBFE),
            border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem(
                Icons.access_time,
                const Color(0xFF00ABE4),
                'Time Left',
                '${_bookingData != null ? _bookingData!['estimatedDurationMin'] : '--'} min',
              ),
              _buildStatItem(
                Icons.route,
                Colors.green,
                'Distance Left',
                '${_bookingData != null ? _bookingData!['distanceKm'] : '--'} km',
              ),
              _buildStatItem(
                Icons.update, 
                Colors.purple, 
                'ETA', 
                _bookingData != null && _bookingData!['estimatedDurationMin'] != null 
                    ? TimeOfDay.fromDateTime(DateTime.now().add(Duration(minutes: (_bookingData!['estimatedDurationMin'] as num).toInt()))).format(context)
                    : '--'
              ),
            ],
          ),
        ),
        SizedBox(height: 12.h),
        _buildRouteTimeline(showTime: true),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
            borderRadius: BorderRadius.circular(16.r),
          ),
          child: _buildDriverInfo(showTrips: false),
        ),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.all(12.w),
          decoration: BoxDecoration(
            color: const Color(0xFFE8F5E9),
            border: Border.all(color: const Color(0xFF16A34A).withOpacity(0.2)),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.green,
                radius: 12.r,
                child: Icon(Icons.security, color: Colors.white, size: 14.sp),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your safety is our priority',
                      style: AppFonts.bodyText.copyWith(
                        color: Colors.green.shade700,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'Emergency support is available 24x7.',
                      style: AppFonts.captionDark.copyWith(
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==== REUSABLE WIDGETS ====

  Widget _buildDriverInfo({bool showTrips = true}) {
    final driver = widget.driverData?['driver'] ?? {};
    String? driverImage = driver['profileImage'] ?? driver['image'];
    final vehicle = driver['vehicle'] ?? {};

    if (driverImage != null) {
      if (driverImage.startsWith('/')) {
        driverImage = '${ApiConstants.baseUrl}$driverImage';
      } else if (driverImage.startsWith('http://localhost') || driverImage.startsWith('http://127.0.0.1')) {
        final uri = Uri.parse(driverImage);
        driverImage = '${ApiConstants.baseUrl}${uri.path}';
      }
    }

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 60.w,
            height: 60.w,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: const Color(0xFFE5FAFF), width: 2),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10.r),
              child: driverImage != null && driverImage.startsWith('http')
                  ? Image.network(
                      driverImage,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          Image.asset(AppAssets.profileImage, fit: BoxFit.cover),
                    )
                  : Image.asset(AppAssets.profileImage, fit: BoxFit.cover),
            ),
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        driver['name'] ?? 'Driver Name',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppFonts.h1.copyWith(
                          fontSize: 18.sp,
                          color: Colors.black,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 6.w,
                        vertical: 2.h,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF7D6),
                        borderRadius: BorderRadius.circular(4.r),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.star, color: const Color(0xFFFFB300), size: 12.sp),
                          SizedBox(width: 4.w),
                          Text(
                            driver['rating']?.toString() ?? '3.8',
                            style: TextStyle(
                              fontSize: 10.sp,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),

                SizedBox(height: 2.h),
                Text(
                  vehicle['vehicleNumber'] ?? 'Vehicle No.',
                  style: AppFonts.bodyText.copyWith(
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 10.5.sp,
                  ),
                ),
                Text(
                  vehicle['vehicleName'] ?? 'Vehicle Name',
                  style: AppFonts.captionDark.copyWith(
                    color: Colors.grey.shade500,
                    fontSize: 10.5.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 56.w,
            height: 56.w,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: const Color(0xFFF2FBFD),
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: const Color(0xFFE5FAFF)),
            ),
            child: Image.asset('assets/images/car1.png', fit: BoxFit.contain),
          ),
        ],
      ),
    );
  }

  Widget _buildRouteTimeline({bool showTime = false}) {
    return Container(
      decoration: const BoxDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              SizedBox(height: 24.h),
              Container(
                width: 16.w,
                height: 16.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF22C55E), width: 4.w),
                  color: Colors.white,
                ),
              ),
              Container(width: 1.w, height: 48.h, color: Colors.grey.shade300),
              Icon(Icons.location_on, color: const Color(0xFFE33A3A), size: 20.sp),
            ],
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.only(top: 10.h, right: 10.w, bottom: 10.h, left: 14.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Pick-up Location',
                              style: AppFonts.captionDark.copyWith(
                                color: Colors.grey.shade500,
                                fontSize: 11.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'BSI Business Park H161 Noida Sector 63',
                              style: AppFonts.bodyText.copyWith(
                                color: Colors.black,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      if (showTime)
                        Text(
                          '8:55 AM',
                          style: AppFonts.captionDark.copyWith(
                            color: Colors.grey.shade500,
                          ),
                        ),
                    ],
                  ),
                ),
                SizedBox(height: 12.h),
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.only(top: 10.h, right: 10.w, bottom: 10.h, left: 14.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2)),
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Your Destination',
                              style: AppFonts.captionDark.copyWith(
                                color: Colors.grey.shade500,
                                fontSize: 11.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'A-3, District Centre, Saket, New Delhi, 110017',
                              style: AppFonts.bodyText.copyWith(
                                color: Colors.black,
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                            ),
                          ],
                        ),
                      ),
                      if (showTime)
                        Text(
                          '9:15 AM',
                          style: AppFonts.captionDark.copyWith(
                            color: Colors.grey.shade500,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutlineButton(
    IconData icon,
    String text, {
    VoidCallback? onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.only(top: 7.h, right: 10.w, bottom: 7.h, left: 14.w),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: const Color(0xFFF0F0F0), width: 1),
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16.sp, color: Colors.grey.shade400),
              SizedBox(width: 4.w),
              Text(
                text,
                style: AppFonts.bodyText.copyWith(
                  color: Colors.grey.shade600,
                  fontWeight: FontWeight.w500,
                  fontSize: 13.sp,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmergencySOS() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          height: 50.h,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFDE8E8),
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.r),
              ),
            ),
            onPressed: () {},
            child: Text(
              'Emergency SOS',
              style: AppFonts.buttonText.copyWith(
                color: const Color(0xFFE33A3A),
              ),
            ),
          ),
        ),
        SizedBox(height: 12.h),
        Text(
          '24x7 Safety Support',
          style: AppFonts.captionDark.copyWith(color: Colors.grey.shade600),
        ),
      ],
    );
  }

  Widget _buildStatItem(
    IconData icon,
    Color iconColor,
    String title,
    String value,
  ) {
    return Row(
      children: [
        CircleAvatar(
          radius: 14.r,
          backgroundColor: iconColor.withOpacity(0.1),
          child: Icon(icon, size: 14.sp, color: iconColor),
        ),
        SizedBox(width: 8.w),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: AppFonts.captionDark.copyWith(color: Colors.grey.shade600),
            ),
            Text(
              value,
              style: AppFonts.bodyText.copyWith(
                color: Colors.black,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showTripCompletePopup() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          width: double.infinity,
          padding: EdgeInsets.only(
            top: 16.h,
            left: 20.w,
            right: 20.w,
            bottom: MediaQuery.of(context).padding.bottom > 0
                ? MediaQuery.of(context).padding.bottom + 16.h
                : 20.h,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 15,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 36.w,
                  height: 4.h,
                  margin: EdgeInsets.only(bottom: 16.h),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                ),
              ),
              Container(
                width: 60.w,
                height: 60.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFF22C55E), Color(0xFF16A34A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF22C55E).withOpacity(0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Icon(
                  Icons.check,
                  color: Colors.white,
                  size: 30.sp,
                ),
              ),
              SizedBox(height: 12.h),
              Text(
                'Trip Completed!',
                style: AppFonts.h1.copyWith(
                  fontSize: 20.sp,
                  color: const Color(0xFF1A1A1A),
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(height: 4.h),
              Text(
                'Thank you for riding with us.',
                style: AppFonts.captionDark.copyWith(
                  color: Colors.grey.shade500,
                  fontSize: 13.sp,
                ),
              ),
              SizedBox(height: 16.h),
              Container(
                padding: EdgeInsets.all(16.w),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14.r),
                  border: Border.all(color: const Color(0xFF00ABE4).withOpacity(0.2), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.02),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Fare Paid',
                              style: AppFonts.captionDark.copyWith(
                                color: Colors.grey.shade500,
                                fontSize: 11.sp,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(height: 2.h),
                            Text(
                              '₹450.00',
                              style: AppFonts.h1.copyWith(
                                color: const Color(0xFF00ABE4),
                                fontSize: 22.sp,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                          decoration: BoxDecoration(
                            color: const Color(0xFF14A03F).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20.r),
                            border: Border.all(color: const Color(0xFF14A03F).withOpacity(0.3), width: 0.8.w),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.check_circle, color: const Color(0xFF14A03F), size: 12.sp),
                              SizedBox(width: 4.w),
                              Text(
                                'PAID',
                                style: AppFonts.bodyText.copyWith(
                                  color: const Color(0xFF14A03F),
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                      child: Row(
                        children: List.generate(30, (index) {
                          return Expanded(
                            child: Container(
                              height: 1.h,
                              color: index % 2 == 0 ? Colors.transparent : Colors.grey.shade400,
                            ),
                          );
                        }),
                      ),
                    ),
                    _buildPopupDetailRow('Payment Mode', 'Cash / Online', isHighlighted: true),
                    SizedBox(height: 8.h),
                    _buildPopupDetailRow('Distance Traveled', '12.5 km'),
                    SizedBox(height: 8.h),
                    _buildPopupDetailRow('Ride Duration', '24 mins'),
                  ],
                ),
              ),
              SizedBox(height: 20.h),
              SizedBox(
                width: double.infinity,
                height: 46.h,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00ABE4),
                    foregroundColor: Colors.white,
                    elevation: 3,
                    shadowColor: const Color(0xFF00ABE4).withOpacity(0.25),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                  ),
                  onPressed: () {
                    Navigator.pop(context); // Close bottom sheet
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const RideInvoiceScreen(),
                      ),
                    );
                  },
                  child: Text(
                    'Done',
                    style: AppFonts.buttonText.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15.sp,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPopupDetailRow(String label, String value, {bool isHighlighted = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: AppFonts.captionDark.copyWith(
            color: Colors.grey.shade500,
            fontSize: 13.sp,
          ),
        ),
        Text(
          value,
          style: AppFonts.bodyText.copyWith(
            color: isHighlighted ? const Color(0xFF1A1A1A) : Colors.grey.shade800,
            fontWeight: isHighlighted ? FontWeight.w700 : FontWeight.w600,
            fontSize: 13.sp,
          ),
        ),
      ],
    );
  }
}
