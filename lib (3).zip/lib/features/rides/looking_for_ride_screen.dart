import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../constants/app_fonts.dart';
import '../../core/socket/socket_service.dart';
import '../../core/socket/socket_events.dart';
import '../../core/api/api_service.dart';
import '../../core/api/api_endpoints.dart';
import 'driver_assigned_screen.dart';
import 'package:get/get.dart';
import '../home/home_screen.dart';
import '../main_navigation_screen.dart';

class LookingForRideScreen extends StatefulWidget {
  final String tripId;
  const LookingForRideScreen({super.key, required this.tripId});

  @override
  State<LookingForRideScreen> createState() => _LookingForRideScreenState();
}

class _LookingForRideScreenState extends State<LookingForRideScreen> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  final Set<Marker> _markers = {};
  BitmapDescriptor? _carIcon;
  BitmapDescriptor? _userLocationIcon;

  @override
  void initState() {
    super.initState();
    print('--- [SOCKET_IO] LookingForRideScreen started for Trip ID: ${widget.tripId} ---');
    _loadMarkerIcons();
    _getCurrentLocation();

    void handleDriverFound(dynamic data) {
      print('--- [SOCKET_IO] Received Driver Found/Accepted event in LookingForRideScreen: $data ---');
      if (!mounted) return;

      dynamic rawData = data;
      if (data is List && data.isNotEmpty) {
        rawData = data.first;
      }
      final parsedData = rawData is Map ? Map<String, dynamic>.from(rawData) : null;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DriverAssignedScreen(
            tripId: widget.tripId,
            driverData: parsedData,
          ),
        ),
      );
    }

    SocketService.to.listenTo(SocketEvents.driverFound, handleDriverFound);
    SocketService.to.listenTo(SocketEvents.tripAccepted, handleDriverFound);

    // Fallback to mock navigation after 8 seconds if no event is received, to keep it demo-friendly
    // Future.delayed(const Duration(seconds: 8), () {
    //   if (!mounted) return;
    //   print('--- [SOCKET_IO] Fallback triggered (mocking driver accept) ---');
    //   Navigator.pushReplacement(
    //     context,
    //     MaterialPageRoute(
    //       builder: (context) => DriverAssignedScreen(
    //         tripId: widget.tripId,
    //         driverData: const {
    //           'driverName': 'Raj Kumar',
    //           'rating': '3.8',
    //           'trips': '1250',
    //           'vehicleNo': 'DL 01 AB 123',
    //           'vehicleName': 'SUV White',
    //           'otp': '5824'
    //         },
    //       ),
    //     ),
    //   );
    // });
  }

  Future<void> _loadMarkerIcons() async {
    try {
      // 1. Load and scale car icon
      final ByteData carData = await rootBundle.load('assets/images/car1.png');
      final ui.Codec carCodec = await ui.instantiateImageCodec(
        carData.buffer.asUint8List(),
        targetWidth: 80,
      );
      final ui.FrameInfo carFi = await carCodec.getNextFrame();
      final ByteData? carByteData = await carFi.image.toByteData(format: ui.ImageByteFormat.png);

      // 2. Generate custom user location icon on canvas
      final ui.PictureRecorder pictureRecorder = ui.PictureRecorder();
      final Canvas canvas = Canvas(pictureRecorder);
      const Size size = Size(100, 100);
      final double centerX = size.width / 2;
      final double centerY = size.height / 2;

      // Draw translucent outer ripple
      final Paint ripplePaint = Paint()
        ..color = const Color(0xFF00ABE4).withOpacity(0.25)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(centerX, centerY), 45, ripplePaint);

      // Draw white border circle
      final Paint borderPaint = Paint()
        ..color = Colors.white
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(centerX, centerY), 22, borderPaint);

      // Draw solid blue inner circle
      final Paint innerPaint = Paint()
        ..color = const Color(0xFF00ABE4)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(centerX, centerY), 18, innerPaint);

      // Draw white arrowhead (pointing up-right / 45 degrees)
      final Paint arrowPaint = Paint()
        ..color = Colors.white
        ..style = PaintingStyle.fill;
      
      canvas.save();
      canvas.translate(centerX, centerY);
      canvas.rotate(45 * math.pi / 180);
      
      final Path arrowPath = Path();
      arrowPath.moveTo(0, -9);
      arrowPath.lineTo(-7, 7);
      arrowPath.lineTo(0, 3);
      arrowPath.lineTo(7, 7);
      arrowPath.close();
      
      canvas.drawPath(arrowPath, arrowPaint);
      canvas.restore();

      final userImg = await pictureRecorder.endRecording().toImage(
        size.width.toInt(),
        size.height.toInt(),
      );
      final ByteData? userByteData = await userImg.toByteData(format: ui.ImageByteFormat.png);

      if (!mounted) return;
      setState(() {
        if (carByteData != null) {
          _carIcon = BitmapDescriptor.fromBytes(carByteData.buffer.asUint8List());
        }
        if (userByteData != null) {
          _userLocationIcon = BitmapDescriptor.fromBytes(userByteData.buffer.asUint8List());
        }
        _updateMarkers();
      });
    } catch (e) {
      debugPrint("Error loading marker icons: $e");
    }
  }

  double _calculateBearing(LatLng from, LatLng to) {
    final double lat1 = from.latitude * (math.pi / 180.0);
    final double lon1 = from.longitude * (math.pi / 180.0);
    final double lat2 = to.latitude * (math.pi / 180.0);
    final double lon2 = to.longitude * (math.pi / 180.0);

    final double dLon = lon2 - lon1;

    final double y = math.sin(dLon) * math.cos(lat2);
    final double x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLon);

    final double radians = math.atan2(y, x);
    final double degrees = radians * (180.0 / math.pi);
    return (degrees + 360.0) % 360.0;
  }

  void _updateMarkers() {
    if (_currentPosition == null) return;

    setState(() {
      _markers.clear();
      
      final LatLng userLatLng = LatLng(
        _currentPosition!.latitude,
        _currentPosition!.longitude,
      );

      // User location marker
      _markers.add(
        Marker(
          markerId: const MarkerId('user_location'),
          position: userLatLng,
          icon: _userLocationIcon ?? BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          anchor: const Offset(0.5, 0.5),
          infoWindow: const InfoWindow(title: 'Your Location'),
        ),
      );

      // Dummy cars around user location (aligned to quadrants like the reference screenshot)
      if (_carIcon != null) {
        final LatLng car1Pos = LatLng(
          _currentPosition!.latitude + 0.0018,
          _currentPosition!.longitude - 0.0018,
        );
        final LatLng car2Pos = LatLng(
          _currentPosition!.latitude + 0.0018,
          _currentPosition!.longitude + 0.0018,
        );
        final LatLng car3Pos = LatLng(
          _currentPosition!.latitude + 0.0005,
          _currentPosition!.longitude + 0.0022,
        );
        final LatLng car4Pos = LatLng(
          _currentPosition!.latitude - 0.0015,
          _currentPosition!.longitude + 0.0012,
        );
        final LatLng car5Pos = LatLng(
          _currentPosition!.latitude - 0.0018,
          _currentPosition!.longitude - 0.0018,
        );

        _markers.add(
          Marker(
            markerId: const MarkerId('car1'),
            position: car1Pos,
            icon: _carIcon!,
            rotation: _calculateBearing(car1Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car2'),
            position: car2Pos,
            icon: _carIcon!,
            rotation: _calculateBearing(car2Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car3'),
            position: car3Pos,
            icon: _carIcon!,
            rotation: _calculateBearing(car3Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car4'),
            position: car4Pos,
            icon: _carIcon!,
            rotation: _calculateBearing(car4Pos, userLatLng) + 90,
          ),
        );
        _markers.add(
          Marker(
            markerId: const MarkerId('car5'),
            position: car5Pos,
            icon: _carIcon!,
            rotation: _calculateBearing(car5Pos, userLatLng) + 90,
          ),
        );
      }
    });
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      if (!mounted) return;
      setState(() {
        _currentPosition = position;
        _updateMarkers();
      });
      _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: 15,
          ),
        ),
      );
    } catch (e) {
      debugPrint("Error fetching location: $e");
    }
  }

  @override
  void dispose() {
    SocketService.to.stopListening(SocketEvents.driverFound);
    SocketService.to.stopListening(SocketEvents.tripAccepted);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8FD),
      body: Stack(
        children: [
          // Background Map
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(28.7041, 77.1025), // Default to Delhi
                zoom: 15,
              ),
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              markers: _markers,
              onMapCreated: (controller) {
                _mapController = controller;
                if (_currentPosition != null) {
                  _mapController?.animateCamera(
                    CameraUpdate.newCameraPosition(
                      CameraPosition(
                        target: LatLng(
                          _currentPosition!.latitude,
                          _currentPosition!.longitude,
                        ),
                        zoom: 15,
                      ),
                    ),
                  );
                }
              },
            ),
          ),

          // Bottom Sheet
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.only(
                top: 24.h,
                left: 24.w,
                right: 24.w,
                bottom: MediaQuery.of(context).padding.bottom + 20.h,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Looking for a car nearby...',
                        style: AppFonts.h2.copyWith(
                          fontSize: 18.sp,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(
                        width: 24.w,
                        height: 24.w,
                        child: const CircularProgressIndicator(
                          color: Color(0xFF00ABE4),
                          strokeWidth: 3,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  SizedBox(
                    width: double.infinity,
                    height: 50.h,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(
                          color: Color(0xFF00ABE4),
                          width: 1.5,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                      ),
                      onPressed: () {
                        print('--- [SOCKET_IO] Cancelling ride Trip ID: ${widget.tripId} ---');
                        // Navigate immediately for direct response
                        Get.offAll(() => const MainNavigationScreen());
                        
                        // Run API call in the background
                        try {
                          ApiService.to.post(
                            '/api/user/trips/${widget.tripId}/cancel',
                            body: {'reason': 'User cancelled before ride start'},
                          ).catchError((e) {
                            print('--- [SOCKET_IO] Cancel ride API failed: $e ---');
                            return null;
                          });
                        } catch (e) {
                          print('--- [SOCKET_IO] Cancel ride API failed: $e ---');
                        }
                      },
                      child: Text(
                        'Cancel Ride',
                        style: AppFonts.buttonText.copyWith(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
